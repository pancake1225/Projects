/**
 * Protected Route Component
 *
 * Route wrapper that requires user authentication.
 * Redirects unauthenticated users to the login page.
 *
 * Usage:
 * ------
 * Wrap any route that requires login:
 *
 * <Route
 *   path="/profile"
 *   element={
 *     <ProtectedRoute>
 *       <Profile />
 *     </ProtectedRoute>
 *   }
 * />
 *
 * Behavior:
 * ---------
 * - If user is authenticated: renders children components
 * - If user is NOT authenticated: redirects to /login
 *
 * Note: This checks authentication only, not specific roles.
 * For role-based access, see AdminRoute and WriterRoute.
 *
 * @param {Object} props
 * @param {React.ReactNode} props.children - Components to render when authenticated
 */

import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function ProtectedRoute({ children }) {
  const { isAuthenticated } = useAuth();

  // Redirect to login if not authenticated
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // User is authenticated - render the protected content
  return children;
}

export default ProtectedRoute;