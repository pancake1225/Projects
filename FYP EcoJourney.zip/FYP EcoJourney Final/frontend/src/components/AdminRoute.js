/**
 * Admin Route Component
 *
 * Route wrapper that requires Admin role for access.
 * Used for admin-only pages like user management and score management.
 *
 * Usage:
 * ------
 * Wrap admin-only routes:
 *
 * <Route
 *   path="/admin"
 *   element={
 *     <AdminRoute>
 *       <Admin />
 *     </AdminRoute>
 *   }
 * />
 *
 * Behavior:
 * ---------
 * - If NOT authenticated: redirect to /login
 * - If authenticated but NOT admin: redirect to /profile
 * - If authenticated AND admin: render children
 *
 * Admin Detection:
 * ----------------
 * Uses isAdmin from AuthContext which checks user.role.type === 'admin'
 *
 * @param {Object} props
 * @param {React.ReactNode} props.children - Components to render when authorized
 */

import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function AdminRoute({ children }) {
  const { isAuthenticated, isAdmin } = useAuth();

  // First check: must be logged in
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  // Second check: must be admin
  if (!isAdmin) {
    // Non-admin authenticated users go to profile
    return <Navigate to="/profile" replace />;
  }

  // User is authenticated admin - render the content
  return children;
}

export default AdminRoute;
