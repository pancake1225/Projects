/**
 * Admin Navigation Component
 *
 * Side navigation bar displayed on all admin dashboard pages.
 * Provides links to all admin management features.
 *
 * Navigation Links:
 * -----------------
 * 1. User Management (/admin) - View/edit/delete users
 * 2. Leaderboard (/admin/leaderboard) - Score management
 * 3. Article Management (/admin/articles) - Create/edit articles
 * 4. Quiz Management (/admin/quizzes) - Create/edit quizzes
 * 5. Question Bank (/admin/questions) - Manage quiz questions
 * 6. Categories & Tags (/admin/categories) - Manage taxonomy
 *
 * Features:
 * ---------
 * - Active state highlighting using NavLink
 * - "Exit Admin" button to return to public site
 * - SVG icons for each navigation item
 *
 * Usage:
 * ------
 * Rendered at the top of admin pages (Admin, ManageArticles, etc.)
 * Writers use WriterNav instead (same styling, fewer links)
 */

import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import './AdminNav.css';

function AdminNav() {
  return (
    <nav className="admin-nav">
      <div className="admin-nav-container">
        <div className="admin-nav-header">
          <h2 className="admin-nav-title">Admin Panel</h2>
          <Link to="/articles" className="exit-admin-btn">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Exit Admin
          </Link>
        </div>
        <div className="admin-nav-links">
          <NavLink
            to="/admin"
            end
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
              <circle cx="9" cy="7" r="4"></circle>
              <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
              <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
            </svg>
            User Management
          </NavLink>
          <NavLink
            to="/admin/leaderboard"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"></path>
              <path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"></path>
              <path d="M4 22h16"></path>
              <path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"></path>
              <path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"></path>
              <path d="M18 2H6v7a6 6 0 0 0 12 0V2Z"></path>
            </svg>
            Leaderboard
          </NavLink>
          <NavLink
            to="/admin/articles"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="16" y1="13" x2="8" y2="13"></line>
              <line x1="16" y1="17" x2="8" y2="17"></line>
              <line x1="10" y1="9" x2="8" y2="9"></line>
            </svg>
            Article Management
          </NavLink>
          <NavLink
            to="/admin/quizzes"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            Quiz Management
          </NavLink>
          <NavLink
            to="/admin/questions"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
              <line x1="10" y1="6" x2="16" y2="6"></line>
              <line x1="10" y1="10" x2="16" y2="10"></line>
              <line x1="10" y1="14" x2="16" y2="14"></line>
            </svg>
            Question Bank
          </NavLink>
          <NavLink
            to="/admin/categories"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
            </svg>
            Categories & Tags
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

export default AdminNav;
