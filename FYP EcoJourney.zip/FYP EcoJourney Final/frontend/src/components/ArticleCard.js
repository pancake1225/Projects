import React from 'react';
import { Link } from 'react-router-dom';
import './Card.css';

function ArticleCard({ article }) {
  // Safety check - if article is invalid, don't render
  if (!article || !article.attributes) {
    console.warn('Invalid article data:', article);
    return null;
  }

  const attrs = article.attributes || article;
  const title = attrs.title || 'Untitled Article';
  const description = attrs.description || 'No description available';
  const slug = attrs.slug || '';
  const documentId = article.documentId || '';

  console.log('ArticleCard data:', { title, slug, documentId, article });

  // Get thumbnail URL if exists
  let imageUrl = 'https://via.placeholder.com/400x250?text=Article';
  if (attrs.thumbnail && attrs.thumbnail.data && attrs.thumbnail.data.attributes) {
    imageUrl = `http://localhost:1337${attrs.thumbnail.data.attributes.url}`;
  }

  // Get category name if exists
  let categoryName = null;
  if (attrs.category && attrs.category.data && attrs.category.data.attributes) {
    categoryName = attrs.category.data.attributes.name;
  }

  // Use slug if available, otherwise use documentId
  const articleLink = slug ? `/articles/${slug}` : documentId ? `/articles/${documentId}` : null;

  return (
    <div className="card article-card">
      <div className="card-image">
        <img src={imageUrl} alt={title} />
      </div>
      <div className="card-content">
        {categoryName && (
          <span className="card-category">{categoryName}</span>
        )}
        <h3 className="card-title">{title}</h3>
        <p className="card-description">
          {description.length > 120 ? `${description.substring(0, 120)}...` : description}
        </p>
        {articleLink && (
          <Link to={articleLink} className="card-link">
            Read More →
          </Link>
        )}
        {!articleLink && (
          <p className="card-link-disabled" style={{color: '#999'}}>
            No link available
          </p>
        )}
      </div>
    </div>
  );
}

export default ArticleCard;