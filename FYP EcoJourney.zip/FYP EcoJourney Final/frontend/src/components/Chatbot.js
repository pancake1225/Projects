/**
 * Chatbot Component - EcoBot UI
 *
 * This component provides the user interface for the EcoBot chatbot.
 * It displays as a floating button that expands into a chat window.
 *
 * Features:
 * ---------
 * - Floating toggle button with pulse animation
 * - Expandable chat window with message history
 * - Admin-only settings panel for API key configuration
 * - Markdown link parsing for clickable article/quiz links
 * - Auto-scroll to latest message
 * - Loading animation while waiting for AI response
 * - Error display for API issues
 *
 * Component Architecture:
 * -----------------------
 * - Uses chatbot.js service for API communication
 * - Uses AuthContext to check if user is admin (for settings access)
 * - Uses React Router's Link for internal navigation
 * - Stores conversation in sessionStorage (via service)
 * - Stores API key in localStorage (persists across sessions)
 *
 * Visibility Rules:
 * -----------------
 * - Hidden on Home page (/) to avoid clutter on landing page
 * - Visible on all other pages
 */

import React, { useState, useEffect, useRef } from 'react';
import { useLocation, Link } from 'react-router-dom';
import { sendMessage, getChatHistory, clearChat, getStoredApiKey, storeApiKey } from '../services/chatbot';
import { useAuth } from '../context/AuthContext';
import './Chatbot.css';

/**
 * Render Message Content with Clickable Links
 *
 * Parses message content for markdown-style links [text](url)
 * and renders them as clickable React Router Links (for internal)
 * or regular <a> tags (for external URLs).
 *
 * Why this is needed:
 * - The AI returns links in markdown format: [Article Title](/articles/slug)
 * - We need to convert these to actual clickable links
 * - Internal links should use React Router (no page reload)
 * - External links should open in new tab
 *
 * @param {string} content - Message content potentially containing markdown links
 * @returns {Array|string} Array of text and Link components, or original string if no links
 */
const renderMessageContent = (content) => {
  // Handle null/undefined content
  if (!content) return null;

  // Regex to match markdown links: [text](url)
  // Captures: [1] = link text, [2] = URL
  const linkRegex = /\[([^\]]+)\]\(([^)]+)\)/g;

  const parts = [];       // Array to hold text segments and Link components
  let lastIndex = 0;      // Track position in string
  let match;              // Current regex match
  let keyIndex = 0;       // Unique key for React elements

  // Find all markdown links in the content
  while ((match = linkRegex.exec(content)) !== null) {
    // Add plain text before this link (if any)
    if (match.index > lastIndex) {
      parts.push(content.slice(lastIndex, match.index));
    }

    const linkText = match[1];  // The display text
    const linkUrl = match[2];   // The URL

    // Determine if internal or external link
    if (linkUrl.startsWith('/')) {
      // Internal link - use React Router Link component
      // This enables client-side navigation (no page reload)
      parts.push(
        <Link key={keyIndex++} to={linkUrl} className="chatbot-link">
          {linkText}
        </Link>
      );
    } else {
      // External link - use regular <a> tag
      // Opens in new tab with security attributes
      parts.push(
        <a key={keyIndex++} href={linkUrl} target="_blank" rel="noopener noreferrer" className="chatbot-link">
          {linkText}
        </a>
      );
    }

    // Update position to after this match
    lastIndex = match.index + match[0].length;
  }

  // Add any remaining text after the last link
  if (lastIndex < content.length) {
    parts.push(content.slice(lastIndex));
  }

  // If no links were found, return the original content
  if (parts.length === 0) {
    return content;
  }

  return parts;
};

/**
 * Chatbot Component
 *
 * Main chatbot UI component with toggle button and chat window.
 */
function Chatbot() {
  // =========================================================================
  // HOOKS AND CONTEXT
  // =========================================================================

  // Get current user from AuthContext (for admin check)
  const { user } = useAuth();

  // Get current URL path (for home page hiding logic)
  const location = useLocation();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  const [isOpen, setIsOpen] = useState(false);           // Chat window open/closed
  const [messages, setMessages] = useState([]);          // Chat message history
  const [inputValue, setInputValue] = useState('');      // Current input text
  const [isLoading, setIsLoading] = useState(false);     // Waiting for AI response
  const [error, setError] = useState('');                // Error message to display
  const [showSettings, setShowSettings] = useState(false); // Settings panel visibility
  const [apiKey, setApiKey] = useState('');              // Current API key
  const [tempApiKey, setTempApiKey] = useState('');      // API key in settings input

  // =========================================================================
  // REFS
  // =========================================================================

  const messagesEndRef = useRef(null);   // For auto-scroll to bottom
  const inputRef = useRef(null);          // For auto-focus on input
  const previousUserIdRef = useRef(null); // Track user changes for history clearing

  // =========================================================================
  // COMPUTED VALUES
  // =========================================================================

  // Check if we're on the home page (chatbot hidden there)
  const isHomePage = location.pathname === '/';

  // Check if current user is an admin (can access settings)
  // Handles both role.type and role.name formats
  const isAdmin = user?.role?.type === 'admin' || user?.role?.name === 'Admin';

  // =========================================================================
  // EFFECTS
  // =========================================================================

  /**
   * Effect: Clear Chat History on User Change
   *
   * When user logs in, logs out, or switches accounts,
   * clear the chat history to prevent context confusion.
   */
  useEffect(() => {
    const currentUserId = user?.id || null;

    // Only clear if user actually changed (not on initial load)
    if (previousUserIdRef.current !== null && previousUserIdRef.current !== currentUserId) {
      clearChat();              // Clear history in sessionStorage
      setMessages([]);          // Clear local state
      setIsOpen(false);         // Close chat window
      setError('');             // Clear any errors
    }

    // Update ref for next comparison
    previousUserIdRef.current = currentUserId;
  }, [user?.id]);

  /**
   * Effect: Load Chat History and API Key on Mount
   *
   * Restores previous conversation and API key when component mounts.
   */
  useEffect(() => {
    // Load chat history from sessionStorage
    const history = getChatHistory();
    setMessages(history);

    // Load API key from localStorage
    const storedKey = getStoredApiKey();
    setApiKey(storedKey);
    setTempApiKey(storedKey);
  }, []);

  /**
   * Effect: Auto-scroll to Bottom on New Messages
   *
   * Ensures the latest message is always visible.
   */
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages]);

  /**
   * Effect: Auto-focus Input When Chat Opens
   *
   * Better UX - user can start typing immediately.
   */
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);

  // =========================================================================
  // EVENT HANDLERS
  // =========================================================================

  /**
   * Handle Send Message
   *
   * Called when user submits the message form.
   * Sends message to AI and updates UI with response.
   *
   * @param {Event} e - Form submit event
   */
  const handleSendMessage = async (e) => {
    e.preventDefault();  // Prevent form from reloading page

    // Validate: don't send empty messages or while loading
    if (!inputValue.trim() || isLoading) return;

    // Check if API key is configured
    if (!apiKey) {
      setError('EcoBot is not configured yet. Please contact an administrator.');
      return;
    }

    const userMessage = inputValue.trim();
    setInputValue('');  // Clear input immediately
    setError('');       // Clear any previous errors

    // Optimistically add user message to UI (before API response)
    // This provides immediate feedback to the user
    setMessages(prev => [...prev, { role: 'user', content: userMessage }]);
    setIsLoading(true);

    try {
      // Call chatbot service to send message and get AI response
      const response = await sendMessage(userMessage, apiKey);
      // Update messages with full history (includes AI response)
      setMessages(response.history);
    } catch (err) {
      // Show error to user
      setError(err.message);
      // Revert to saved history (removes optimistically added message)
      setMessages(getChatHistory());
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handle Save API Key
   *
   * Called when admin saves API key in settings panel.
   */
  const handleSaveApiKey = () => {
    storeApiKey(tempApiKey);      // Save to localStorage
    setApiKey(tempApiKey);        // Update current state
    setShowSettings(false);       // Close settings panel
    setError('');                 // Clear any errors
  };

  /**
   * Toggle Chat Window
   *
   * Opens/closes the chat window and hides settings when closing.
   */
  const toggleChat = () => {
    setIsOpen(!isOpen);
    setShowSettings(false);  // Always hide settings when toggling
  };

  // =========================================================================
  // CONDITIONAL RENDERING: HIDE ON HOME PAGE
  // =========================================================================

  if (isHomePage) {
    return null;  // Don't render anything on home page
  }

  // =========================================================================
  // RENDER
  // =========================================================================

  return (
    <div className="chatbot-container">
      {/* ================================================================
          TOGGLE BUTTON
          Large floating button to open/close chat
          Shows different content based on open/closed state
          ================================================================ */}
      <button
        className={`chatbot-toggle ${isOpen ? 'open' : ''}`}
        onClick={toggleChat}
        aria-label={isOpen ? 'Close chat' : 'Open chat'}
      >
        {/* Content shown when chat is CLOSED */}
        <div className="chatbot-toggle-content">
          <div className="chatbot-toggle-icon">
            🌱
          </div>
          <div className="chatbot-toggle-text">
            <span className="chatbot-toggle-title">Ask EcoBot</span>
            <span className="chatbot-toggle-subtitle">Your sustainability assistant</span>
          </div>
        </div>

        {/* Close icon (X) shown when chat is OPEN */}
        <svg className="close-icon" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      {/* ================================================================
          CHAT WINDOW
          Only rendered when isOpen is true
          Contains: Header, Settings (admin), Messages, Input
          ================================================================ */}
      {isOpen && (
        <div className="chatbot-window">
          {/* --------------------------------------------------------------
              HEADER
              Shows EcoBot title and settings button (admin only)
              -------------------------------------------------------------- */}
          <div className="chatbot-header">
            <div className="chatbot-title">
              <span className="chatbot-icon">🌱</span>
              <span>EcoBot</span>
            </div>

            {/* Settings button - Only visible to admin users */}
            {isAdmin && (
              <button
                className="chatbot-action-btn"
                onClick={() => setShowSettings(!showSettings)}
                title="Settings (Admin)"
              >
                {/* Gear icon SVG */}
                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
              </button>
            )}
          </div>

          {/* --------------------------------------------------------------
              SETTINGS PANEL (Admin Only)
              Allows admin to configure Groq API key
              -------------------------------------------------------------- */}
          {showSettings && isAdmin && (
            <div className="chatbot-settings">
              <label htmlFor="api-key">Groq API Key:</label>
              <input
                type="password"
                id="api-key"
                value={tempApiKey}
                onChange={(e) => setTempApiKey(e.target.value)}
                placeholder="Enter your Groq API key"
              />
              <p className="settings-hint">
                Get your free API key at <a href="https://console.groq.com/keys" target="_blank" rel="noopener noreferrer">console.groq.com</a>
              </p>
              <button onClick={handleSaveApiKey} className="save-key-btn">
                Save Key
              </button>
            </div>
          )}

          {/* --------------------------------------------------------------
              MESSAGES AREA
              Displays chat history and loading/error states
              -------------------------------------------------------------- */}
          <div className="chatbot-messages">
            {/* Welcome message - shown when no messages yet */}
            {messages.length === 0 && !showSettings && (
              <div className="chatbot-welcome">
                <span className="welcome-icon">🌱</span>
                <h3>Hi! I'm EcoBot</h3>
                <p>Your sustainability assistant. Ask me about eco-friendly practices, environmental topics, or help navigating EcoJourney!</p>
              </div>
            )}

            {/* Message list */}
            {messages.map((msg, index) => (
              <div
                key={index}
                className={`chatbot-message ${msg.role}`}
              >
                {/* Avatar for assistant messages */}
                {msg.role === 'assistant' && <span className="message-avatar">🌱</span>}

                {/* Message content - parse links for assistant messages */}
                <div className="message-content">
                  {msg.role === 'assistant' ? renderMessageContent(msg.content) : msg.content}
                </div>
              </div>
            ))}

            {/* Loading indicator - shown while waiting for AI response */}
            {isLoading && (
              <div className="chatbot-message assistant">
                <span className="message-avatar">🌱</span>
                <div className="message-content loading">
                  <span className="dot"></span>
                  <span className="dot"></span>
                  <span className="dot"></span>
                </div>
              </div>
            )}

            {/* Error message display */}
            {error && (
              <div className="chatbot-error">
                {error}
              </div>
            )}

            {/* Invisible element at bottom for auto-scroll targeting */}
            <div ref={messagesEndRef} />
          </div>

          {/* --------------------------------------------------------------
              INPUT FORM
              Text input and send button
              -------------------------------------------------------------- */}
          <form className="chatbot-input-form" onSubmit={handleSendMessage}>
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Ask about sustainability..."
              disabled={isLoading}  // Disable while waiting for response
            />
            <button
              type="submit"
              disabled={isLoading || !inputValue.trim()}  // Disable if loading or empty
              aria-label="Send message"
            >
              {/* Send arrow icon */}
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="22" y1="2" x2="11" y2="13"></line>
                <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
              </svg>
            </button>
          </form>
        </div>
      )}
    </div>
  );
}

export default Chatbot;
