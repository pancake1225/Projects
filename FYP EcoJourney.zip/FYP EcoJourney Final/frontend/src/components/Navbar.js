/**
 * Navbar Component
 *
 * Main navigation bar displayed on all pages except the landing page (Home).
 * Provides navigation links, user authentication status, and role-based menus.
 *
 * Features:
 * ---------
 * 1. Sticky header with scroll effect (adds shadow when scrolled)
 * 2. Responsive design with mobile hamburger menu
 * 3. Active link highlighting based on current route
 * 4. Role-based navigation links (Admin, Writer panels)
 * 5. Authentication-aware (shows login/signup or profile/logout)
 *
 * Navigation Links:
 * -----------------
 * Public (always shown):
 * - Articles, Quizzes, Leaderboard
 *
 * Authenticated users:
 * - Profile, Logout button
 *
 * Writer role:
 * - Writer Panel link
 *
 * Admin role:
 * - Admin link
 *
 * Mobile Menu:
 * ------------
 * - Hamburger icon transforms to X when open
 * - Auto-closes on route change
 * - Same links as desktop navigation
 */

import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Navbar.css';
import rpLogo from '../assets/rp.jpg';

function Navbar() {
  // Get user info and auth functions from context
  const { user, logout, isAdmin } = useAuth();
  const location = useLocation();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);  // Mobile menu visibility
  const [scrolled, setScrolled] = useState(false);  // Scroll state for shadow effect

  // Check if user has Writer role
  const isWriter = user?.role?.type === 'writer';

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleLogout = () => {
    logout();
    setMobileMenuOpen(false);
  };

  return (
    <header className={`navbar ${scrolled ? 'navbar-scrolled' : ''}`}>
      <div className="navbar-container">
        {/* Left side: Logo + Nav links */}
        <div className="navbar-left">
          <Link to="/" className="navbar-logo-link">
            <img src={rpLogo} alt="RP Logo" className="navbar-logo" />
            <span className="navbar-title">Republic Polytechnic ESGC</span>
          </Link>

          <nav className="navbar-nav">
            <Link to="/articles" className={`navbar-link ${location.pathname.startsWith('/articles') ? 'active' : ''}`}>
              Articles
            </Link>
            <Link to="/quizzes" className={`navbar-link ${location.pathname === '/quizzes' ? 'active' : ''}`}>
              Quizzes
            </Link>
            <Link to="/leaderboard" className={`navbar-link ${location.pathname === '/leaderboard' ? 'active' : ''}`}>
              Leaderboard
            </Link>
            {user && (
              <>
                <Link to="/profile" className={`navbar-link ${location.pathname === '/profile' ? 'active' : ''}`}>
                  Profile
                </Link>
                {isWriter && (
                  <Link to="/writer" className={`navbar-link ${location.pathname.startsWith('/writer') ? 'active' : ''}`}>
                    Writer Panel
                  </Link>
                )}
                {isAdmin && (
                  <Link to="/admin" className={`navbar-link ${location.pathname.startsWith('/admin') ? 'active' : ''}`}>
                    Admin
                  </Link>
                )}
              </>
            )}
          </nav>
        </div>

        {/* Right side: Welcome + Auth buttons */}
        <div className="navbar-right">
          {user ? (
            <>
              <span className="navbar-welcome">Welcome, {user.username}</span>
              <button onClick={handleLogout} className="navbar-button navbar-logout">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="navbar-link">Sign In</Link>
              <Link to="/register" className="navbar-button">Sign Up</Link>
            </>
          )}
        </div>

        <button 
          className={`mobile-menu-button ${mobileMenuOpen ? 'active' : ''}`}
          onClick={toggleMobileMenu}
          aria-label="Toggle menu"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </div>

      {mobileMenuOpen && (
        <div className="mobile-menu mobile-menu-open">
          <Link to="/articles" className={`mobile-link ${location.pathname.startsWith('/articles') ? 'active' : ''}`}>
            Articles
          </Link>
          <Link to="/quizzes" className={`mobile-link ${location.pathname === '/quizzes' ? 'active' : ''}`}>
            Quizzes
          </Link>
          <Link to="/leaderboard" className={`mobile-link ${location.pathname === '/leaderboard' ? 'active' : ''}`}>
            Leaderboard
          </Link>

          {user ? (
            <>
              <div className="mobile-welcome">Welcome, {user.username}</div>
              <Link to="/profile" className={`mobile-link ${location.pathname === '/profile' ? 'active' : ''}`}>
                Profile
              </Link>
              {isWriter && (
                <Link to="/writer" className={`mobile-link ${location.pathname.startsWith('/writer') ? 'active' : ''}`}>
                  Writer Panel
                </Link>
              )}
              {isAdmin && (
                <Link to="/admin" className={`mobile-link ${location.pathname.startsWith('/admin') ? 'active' : ''}`}>
                  Admin
                </Link>
              )}
              <button onClick={handleLogout} className="mobile-link mobile-logout">
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="mobile-link">Sign In</Link>
              <Link to="/register" className="mobile-link mobile-signup">Sign Up</Link>
            </>
          )}
        </div>
      )}
    </header>
  );
}

export default Navbar;
