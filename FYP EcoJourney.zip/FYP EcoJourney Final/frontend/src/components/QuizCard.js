import React from 'react';
import { Link } from 'react-router-dom';
import { isQuizCompleted } from '../utils/storage';
import './Card.css';

function QuizCard({ quiz }) {
  if (!quiz || !quiz.attributes) {
    return null;
  }

  const { title, description, slug, difficulty, questions, category } = quiz.attributes;
  const completed = isQuizCompleted(quiz.id);
  const questionCount = questions?.length || 0;

  return (
    <div className={`card quiz-card ${completed ? 'completed' : ''}`}>
      <div className="card-content">
        {category?.data?.attributes?.name && (
          <span className="card-category">{category.data.attributes.name}</span>
        )}
        <h3 className="card-title">{title || 'Untitled Quiz'}</h3>
        <p className="card-description">
          {description ? `${description.substring(0, 120)}...` : 'Test your knowledge!'}
        </p>
        <div className="quiz-meta">
          <span className={`difficulty ${difficulty?.toLowerCase() || 'medium'}`}>
            {difficulty || 'Medium'}
          </span>
          <span className="question-count">
            📝 {questionCount} Questions
          </span>
        </div>
        {completed && (
          <div className="completed-badge">✓ Completed</div>
        )}
        <Link to={`/quizzes/${slug}`} className="card-link">
          {completed ? 'Retake Quiz' : 'Start Quiz'} →
        </Link>
      </div>
    </div>
  );
}

export default QuizCard;