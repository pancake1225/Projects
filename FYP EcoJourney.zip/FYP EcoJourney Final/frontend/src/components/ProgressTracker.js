import React from 'react';
import { getUserStats } from '../utils/storage';
import './ProgressTracker.css';

function ProgressTracker() {
  const stats = getUserStats();

  return (
    <div className="progress-tracker">
      <div className="stat">
        <div className="stat-value">{stats.totalQuizzes}</div>
        <div className="stat-label">Quizzes</div>
      </div>
      <div className="stat">
        <div className="stat-value">{stats.averageScore}%</div>
        <div className="stat-label">Avg Score</div>
      </div>
      <div className="stat">
        <div className="stat-value">{stats.totalPoints}</div>
        <div className="stat-label">Points</div>
      </div>
    </div>
  );
}

export default ProgressTracker;