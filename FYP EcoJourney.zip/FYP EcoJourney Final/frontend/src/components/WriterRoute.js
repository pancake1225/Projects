/**
 * Writer Route Component
 *
 * Route wrapper that requires Writer (or higher) role for access.
 * Used for content management pages accessible to Writers.
 *
 * Usage:
 * ------
 * Wrap writer-accessible routes:
 *
 * <Route
 *   path="/writer/articles"
 *   element={
 *     <WriterRoute>
 *       <ManageArticles />
 *     </WriterRoute>
 *   }
 * />
 *
 * Authorized Roles:
 * -----------------
 * - writer: Content creators
 * - admin: Full access (admins can do everything writers can)
 * - authenticated: Regular users (for future expansion)
 *
 * Note: While 'authenticated' is included, the actual pages may have
 * additional permission checks (e.g., canDelete only for admins).
 *
 * Behavior:
 * ---------
 * - Shows loading indicator while auth state is being determined
 * - If authorized: render children
 * - If NOT authorized: redirect to /login
 *
 * @param {Object} props
 * @param {React.ReactNode} props.children - Components to render when authorized
 */

import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

function WriterRoute({ children }) {
  const { user, loading } = useAuth();

  // Show loading state while determining auth status
  if (loading) {
    return <div>Loading...</div>;
  }

  // Check if user has an authorized role
  // Writers, Admins, and Authenticated users can access
  const isAuthorized = user && (
    user.role?.type === 'writer' ||
    user.role?.type === 'admin' ||
    user.role?.type === 'authenticated'
  );

  // Render children if authorized, otherwise redirect to login
  return isAuthorized ? children : <Navigate to="/login" replace />;
}

export default WriterRoute;
