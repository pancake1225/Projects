/**
 * Writer Navigation Component
 *
 * Side navigation bar displayed on Writer dashboard pages.
 * Similar to AdminNav but with fewer options (no user management or leaderboard).
 *
 * Navigation Links:
 * -----------------
 * 1. Article Management (/writer/articles) - Create/edit articles
 * 2. Quiz Management (/writer/quizzes) - Create/edit quizzes
 * 3. Question Bank (/writer/questions) - Manage quiz questions
 * 4. Categories & Tags (/writer/categories) - Manage taxonomy
 *
 * Differences from AdminNav:
 * --------------------------
 * - No User Management (Admin only)
 * - No Leaderboard/Score Management (Admin only)
 * - Uses /writer/* routes instead of /admin/*
 *
 * Note: Writers can create/edit content but cannot delete.
 * Delete buttons are hidden via canDelete permission check in pages.
 *
 * Styling:
 * --------
 * Reuses AdminNav.css for consistent look and feel.
 */

import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import './AdminNav.css';  // Reuse admin nav styles

function WriterNav() {
  return (
    <nav className="admin-nav">
      <div className="admin-nav-container">
        <div className="admin-nav-header">
          <h2 className="admin-nav-title">Writer Panel</h2>
          <Link to="/articles" className="exit-admin-btn">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
              <polyline points="16 17 21 12 16 7"></polyline>
              <line x1="21" y1="12" x2="9" y2="12"></line>
            </svg>
            Exit Writer Panel
          </Link>
        </div>
        <div className="admin-nav-links">
          <NavLink
            to="/writer/articles"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M14.5 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7.5L14.5 2z"></path>
              <polyline points="14 2 14 8 20 8"></polyline>
              <line x1="16" y1="13" x2="8" y2="13"></line>
              <line x1="16" y1="17" x2="8" y2="17"></line>
              <line x1="10" y1="9" x2="8" y2="9"></line>
            </svg>
            Article Management
          </NavLink>
          <NavLink
            to="/writer/quizzes"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="10"></circle>
              <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
              <line x1="12" y1="17" x2="12.01" y2="17"></line>
            </svg>
            Quiz Management
          </NavLink>
          <NavLink
            to="/writer/questions"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path>
              <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"></path>
              <line x1="10" y1="6" x2="16" y2="6"></line>
              <line x1="10" y1="10" x2="16" y2="10"></line>
              <line x1="10" y1="14" x2="16" y2="14"></line>
            </svg>
            Question Bank
          </NavLink>
          <NavLink
            to="/writer/categories"
            className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path>
            </svg>
            Categories & Tags
          </NavLink>
        </div>
      </div>
    </nav>
  );
}

export default WriterNav;
