import React from 'react';
import { Link } from 'react-router-dom';
import './Footer.css';

// Import RP logo
import rpLogo from '../assets/rp.jpg';

function Footer() {
  return (
    <footer className="footer">
      <div className="footer-container">
        <div className="footer-content">
          {/* Brand Section */}
          <div className="footer-brand">
            <div className="footer-logo">
              <div className="footer-logo-circle">
                <img src={rpLogo} alt="Republic Polytechnic ESGC" />
              </div>
              <span className="footer-title">Republic Polytechnic ESGC</span>
            </div>
            <p className="footer-description">
              Learn sustainable living habits through interactive content
            </p>
          </div>

          {/* Quick Links */}
          <div className="footer-section">
            <h3 className="footer-heading">Quick Links</h3>
            <nav className="footer-links">
              <Link to="/articles" className="footer-link">Articles</Link>
              <Link to="/quizzes" className="footer-link">Quizzes</Link>
              <Link to="/profile" className="footer-link">My Progress</Link>
            </nav>
          </div>

          {/* About */}
          <div className="footer-section">
            <h3 className="footer-heading">About</h3>
            <div className="footer-links">
              <p className="footer-text">Final Year Project 2025-2026</p>
              <p className="footer-text">Sustainability Awareness Platform</p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="footer-bottom">
          <p className="footer-copyright">
            © {new Date().getFullYear()} Republic Polytechnic ESGC. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;