/**
 * Storage Utility - Progress Tracking Service
 *
 * This module handles quiz progress tracking using a hybrid storage approach:
 * 1. localStorage - For immediate offline access and fast reads
 * 2. Strapi Backend - For persistent server-side storage and leaderboard
 *
 * Why Hybrid Storage?
 * -------------------
 * - localStorage provides instant access without network requests
 * - Backend storage persists across devices and enables leaderboard
 * - If backend fails, localStorage still works (graceful degradation)
 *
 * Data Flow:
 * ----------
 * When user completes quiz:
 * 1. Save to localStorage (immediate, always works)
 * 2. Send to Strapi backend (for leaderboard, may fail)
 *
 * When loading progress:
 * - Profile page fetches from backend (authoritative source)
 * - Falls back to localStorage if backend fails
 */

// Prefix for localStorage keys - ensures our data doesn't conflict with other apps
const STORAGE_KEY_PREFIX = 'ecojourney_progress';

// Strapi API base URL - change this for production deployment
const API_URL = 'http://localhost:1337/api';

/**
 * Get Storage Key for Current User
 *
 * Creates a unique localStorage key based on the user's ID.
 * This ensures different users on the same device have separate progress.
 *
 * Examples:
 * - Logged in user (id: 5): "ecojourney_progress_5"
 * - Not logged in: "ecojourney_progress" (shared/guest progress)
 *
 * @returns {string} The localStorage key for the current user
 */
const getUserStorageKey = () => {
  // Try to get user from localStorage (set during login)
  const user = JSON.parse(localStorage.getItem('user') || '{}');
  // If user has an ID, create user-specific key; otherwise use shared key
  return user.id ? `${STORAGE_KEY_PREFIX}_${user.id}` : STORAGE_KEY_PREFIX;
};

/**
 * Get Completed Quizzes from localStorage
 *
 * Retrieves all quiz completion records for the current user.
 *
 * @returns {Array} Array of quiz completion objects, or empty array if none
 *
 * Each completion object contains:
 * {
 *   quizId: number,          // ID of the completed quiz
 *   score: number,           // Number of correct answers
 *   totalQuestions: number,  // Total questions in quiz
 *   percentage: number,      // Score as percentage (0-100)
 *   completedAt: string      // ISO timestamp of completion
 * }
 */
export const getCompletedQuizzes = () => {
  const storageKey = getUserStorageKey();
  const data = window.localStorage.getItem(storageKey);
  // Parse JSON if data exists, otherwise return empty array
  return data ? JSON.parse(data) : [];
};

/**
 * Save Quiz Completion
 *
 * Saves a quiz result to both localStorage AND the Strapi backend.
 * This is the main function called when a user finishes a quiz.
 *
 * Important: Only updates existing score if new score is HIGHER (high score tracking)
 *
 * @param {number|string} quizId - The ID of the completed quiz
 * @param {number} score - Number of correct answers
 * @param {number} totalQuestions - Total questions in the quiz
 * @param {number} earnedPoints - Points earned (based on difficulty multiplier)
 * @param {number} maxPossiblePoints - Maximum possible points for this quiz
 * @param {string} difficulty - Quiz difficulty ('easy', 'medium', 'hard')
 * @returns {Object} The saved quiz completion entry
 */
export const saveQuizCompletion = async (quizId, score, totalQuestions, earnedPoints, maxPossiblePoints, difficulty) => {
  // Get existing completed quizzes from localStorage
  const completed = getCompletedQuizzes();

  // Check if user has already completed this quiz
  const existingIndex = completed.findIndex(q => q.quizId === quizId);

  // Create the new completion entry
  const newEntry = {
    quizId,
    score,
    totalQuestions,
    percentage: Math.round((score / totalQuestions) * 100),  // Calculate percentage
    completedAt: new Date().toISOString()  // Current timestamp in ISO format
  };

  // Update or add entry in local array
  if (existingIndex >= 0) {
    // Quiz was completed before - only update if new score is higher
    // This implements "high score" tracking
    if (score > completed[existingIndex].score) {
      completed[existingIndex] = newEntry;
    }
    // If new score is lower or equal, don't update (keep the high score)
  } else {
    // First time completing this quiz - add to array
    completed.push(newEntry);
  }

  // -------------------------------------------------------------------------
  // STEP 1: Save to localStorage (always works, instant)
  // -------------------------------------------------------------------------
  const storageKey = getUserStorageKey();
  window.localStorage.setItem(storageKey, JSON.stringify(completed));

  // -------------------------------------------------------------------------
  // STEP 2: Save to Strapi backend (for leaderboard)
  // -------------------------------------------------------------------------
  // This step may fail (network issues, server down) but that's OK
  // The try-catch ensures localStorage save still succeeds
  try {
    // Get authentication token (set during login)
    const token = localStorage.getItem('token');
    // Get user object to check if logged in
    const user = JSON.parse(localStorage.getItem('user') || '{}');

    // Only save to backend if user is authenticated
    // (needs both token for API auth and user.id for association)
    if (token && user.id) {
      // Use our custom submit endpoint (not Strapi's default POST /quiz-results)
      // The custom endpoint sets userId server-side for security
      const response = await fetch(`${API_URL}/quiz-results/submit`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // JWT token for authentication
        },
        body: JSON.stringify({
          // Strapi expects data wrapped in 'data' object
          data: {
            score: score,
            totalQuestions: totalQuestions,
            percentage: newEntry.percentage,
            points: earnedPoints || score,           // Use earned points or fallback to score
            maxPoints: maxPossiblePoints || totalQuestions,  // Max possible or fallback
            difficulty: difficulty || 'medium',      // Difficulty level or default
            quiz: quizId,                            // Foreign key to Quiz content-type
            completedAt: newEntry.completedAt        // Completion timestamp
          }
        })
      });

      // Log result for debugging
      if (!response.ok) {
        const errorData = await response.json();
        console.error('Failed to save quiz result to backend:', errorData);
      } else {
        console.log('Quiz result saved successfully to backend');
      }
    }
  } catch (err) {
    // Log error but don't throw - localStorage save already succeeded
    // The quiz result is safe locally even if backend save failed
    console.error('Error saving to backend:', err);
    // Still return success since localStorage worked
  }

  return newEntry;
};

/**
 * Get User Statistics
 *
 * Calculates aggregate statistics from localStorage data.
 * Used as a fallback when backend data isn't available.
 *
 * Note: Profile page prefers backend data (more accurate points calculation)
 * but falls back to this if backend fails.
 *
 * @returns {Object} User statistics object
 * {
 *   totalQuizzes: number,      // Number of quizzes completed
 *   averageScore: number,      // Average score as percentage (0-100)
 *   totalPoints: number,       // Sum of all scores (raw points)
 *   completedQuizzes: Array    // Array of completion records
 * }
 */
export const getUserStats = () => {
  const completed = getCompletedQuizzes();

  // Handle case where no quizzes completed
  if (completed.length === 0) {
    return {
      totalQuizzes: 0,
      averageScore: 0,
      totalPoints: 0,
      completedQuizzes: []
    };
  }

  // Calculate totals using reduce
  // totalPoints = sum of all scores (correct answers)
  const totalPoints = completed.reduce((sum, q) => sum + q.score, 0);
  // totalPossible = sum of all totalQuestions (for average calculation)
  const totalPossible = completed.reduce((sum, q) => sum + q.totalQuestions, 0);

  return {
    totalQuizzes: completed.length,
    // averageScore = (total correct / total questions) * 100
    // Guard against division by zero
    averageScore: totalPossible > 0 ? Math.round((totalPoints / totalPossible) * 100) : 0,
    totalPoints,
    completedQuizzes: completed
  };
};

/**
 * Check if Quiz is Completed
 *
 * Quick check to see if a specific quiz has been completed.
 * Used to show completion badges/indicators on quiz cards.
 *
 * @param {number|string} quizId - The quiz ID to check
 * @returns {boolean} True if quiz has been completed, false otherwise
 */
export const isQuizCompleted = (quizId) => {
  const completed = getCompletedQuizzes();
  // some() returns true if any element matches the condition
  return completed.some(q => q.quizId === quizId);
};

/**
 * Reset All Progress
 *
 * Clears all quiz completion data from localStorage.
 * Used by the "Reset Progress" button on Profile page.
 *
 * WARNING: This only clears localStorage!
 * Backend data is cleared separately via resetUserProgress() in api.js
 *
 * @returns {void}
 */
export const resetProgress = () => {
  const storageKey = getUserStorageKey();
  window.localStorage.removeItem(storageKey);
};
