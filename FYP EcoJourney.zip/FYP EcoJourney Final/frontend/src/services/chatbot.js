/**
 * Chatbot Service - Groq AI Integration with RAG (Retrieval-Augmented Generation)
 *
 * This service powers the EcoBot chatbot feature. It integrates with the Groq API
 * (which provides access to the Llama 3.3 70B model) and implements RAG by loading
 * platform content (articles, quizzes, categories) into the AI's context.
 *
 * Key Features:
 * -------------
 * 1. RAG Implementation - Loads all platform content into AI's system prompt
 * 2. Conversation History - Maintains chat history in sessionStorage
 * 3. Content Caching - 5-minute cache for platform content to reduce API calls
 * 4. Anti-hallucination - Strict system prompt to prevent AI from making up content
 *
 * How RAG Works Here:
 * -------------------
 * 1. On each message, we fetch all articles, quizzes, categories from Strapi
 * 2. This content is formatted and included in the system prompt
 * 3. The AI can then answer questions about specific platform content
 * 4. The AI is instructed to ONLY mention content that exists in the lists
 *
 * API Used:
 * ---------
 * - Groq API (https://api.groq.com/openai/v1/chat/completions)
 * - Model: llama-3.3-70b-versatile
 * - Groq provides fast inference for open-source LLMs
 *
 * Limitations:
 * ------------
 * - No web search capability (only knows platform content + training data)
 * - Requires API key to be configured by admin
 * - Limited to text-based responses
 */

// Groq API endpoint (OpenAI-compatible format)
const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

// Strapi backend URL for fetching content
const STRAPI_URL = 'http://localhost:1337';

// =========================================================================
// CONTENT CACHING
// Cache platform content to avoid fetching on every message
// =========================================================================
let platformContentCache = null;  // Stores { articles, quizzes, categories }
let cacheTimestamp = 0;           // When cache was last updated
const CACHE_DURATION = 5 * 60 * 1000;  // 5 minutes in milliseconds

// =========================================================================
// CONVERSATION HISTORY MANAGEMENT
// Uses sessionStorage to persist history during browser session
// =========================================================================

/**
 * Get Conversation History
 * Retrieves chat history from sessionStorage
 *
 * Why sessionStorage instead of localStorage?
 * - sessionStorage clears when tab/browser closes
 * - This gives users a fresh start each session
 * - Prevents stale context from affecting conversations
 *
 * @returns {Array} Array of message objects { role: 'user'|'assistant', content: string }
 */
const getConversationHistory = () => {
  const history = sessionStorage.getItem('chatbot_history');
  return history ? JSON.parse(history) : [];
};

/**
 * Save Conversation History
 * Persists chat history to sessionStorage
 *
 * @param {Array} history - Array of message objects
 */
const saveConversationHistory = (history) => {
  sessionStorage.setItem('chatbot_history', JSON.stringify(history));
};

/**
 * Clear Conversation History
 * Removes chat history from sessionStorage
 * Called when user clicks "New Chat" or when user logs out
 */
const clearConversationHistory = () => {
  sessionStorage.removeItem('chatbot_history');
};

// =========================================================================
// PLATFORM CONTENT FETCHING (RAG Data Source)
// =========================================================================

/**
 * Fetch Platform Content
 *
 * Retrieves all articles, quizzes, and categories from Strapi.
 * This content is used to "teach" the AI about what's on the platform.
 *
 * Implements caching to reduce unnecessary API calls:
 * - Returns cached data if less than 5 minutes old
 * - Fetches fresh data if cache is stale or empty
 *
 * @returns {Object} { articles: [], quizzes: [], categories: [] }
 */
const fetchPlatformContent = async () => {
  // Check if cached data is still valid
  if (platformContentCache && Date.now() - cacheTimestamp < CACHE_DURATION) {
    return platformContentCache;
  }

  try {
    // Fetch all three content types in parallel for efficiency
    // Promise.all waits for all requests to complete before continuing
    const [articlesRes, quizzesRes, categoriesRes] = await Promise.all([
      fetch(`${STRAPI_URL}/api/articles?populate=*`),   // Include all relations
      fetch(`${STRAPI_URL}/api/quizzes?populate=*`),    // Include category, tags
      fetch(`${STRAPI_URL}/api/categories`)             // Just category list
    ]);

    // Initialize empty arrays for each content type
    let articles = [];
    let quizzes = [];
    let categories = [];

    // Process articles response
    if (articlesRes.ok) {
      const data = await articlesRes.json();
      articles = data.data || [];
      console.log('Chatbot: Fetched', articles.length, 'articles');
    } else {
      console.error('Chatbot: Failed to fetch articles', articlesRes.status);
    }

    // Process quizzes response
    if (quizzesRes.ok) {
      const data = await quizzesRes.json();
      quizzes = data.data || [];
      console.log('Chatbot: Fetched', quizzes.length, 'quizzes');
    } else {
      console.error('Chatbot: Failed to fetch quizzes', quizzesRes.status);
    }

    // Process categories response
    if (categoriesRes.ok) {
      const data = await categoriesRes.json();
      categories = data.data || [];
      console.log('Chatbot: Fetched', categories.length, 'categories');
    } else {
      console.error('Chatbot: Failed to fetch categories', categoriesRes.status);
    }

    // Update cache with fresh data
    platformContentCache = { articles, quizzes, categories };
    cacheTimestamp = Date.now();

    console.log('Chatbot: Platform content cached', {
      articles: articles.length,
      quizzes: quizzes.length,
      categories: categories.length
    });

    return platformContentCache;
  } catch (error) {
    console.warn('Error fetching platform content:', error);
    // Return empty data on error - chatbot will still work with general knowledge
    return { articles: [], quizzes: [], categories: [] };
  }
};

// =========================================================================
// SYSTEM PROMPT BUILDING
// =========================================================================

/**
 * Format Content for System Prompt
 *
 * Transforms the raw platform content into a readable format
 * for inclusion in the AI's system prompt.
 *
 * @param {Object} content - { articles, quizzes, categories }
 * @returns {string} Formatted content string
 */
const formatContentForPrompt = (content) => {
  const { articles, quizzes, categories } = content;

  let prompt = '';

  // Format categories section
  if (categories.length > 0) {
    prompt += '\n\n=== CATEGORIES ON ECOJOURNEY ===\n';
    categories.forEach(cat => {
      // Include name and description if available
      prompt += `- ${cat.name}${cat.description ? `: ${cat.description}` : ''}\n`;
    });
  }

  // Format articles section
  if (articles.length > 0) {
    prompt += '\n\n=== ARTICLES ON ECOJOURNEY ===\n';
    articles.forEach(article => {
      const category = article.category?.name || 'Uncategorized';
      // Include title, category, and slug for linking
      prompt += `- "${article.title}" (Category: ${category}, slug: ${article.slug})\n`;
    });
  }

  // Format quizzes section
  if (quizzes.length > 0) {
    prompt += '\n\n=== QUIZZES ON ECOJOURNEY ===\n';
    quizzes.forEach(quiz => {
      const category = quiz.category?.name || 'Uncategorized';
      prompt += `- "${quiz.title}" (Category: ${category}, slug: ${quiz.slug})\n`;
    });
  }

  return prompt;
};

/**
 * Build System Prompt
 *
 * Creates the full system prompt that instructs the AI on how to behave.
 * This is the most critical part of the RAG implementation.
 *
 * Key elements:
 * 1. Role definition - What EcoBot is and what it should do
 * 2. CRITICAL RULES - Anti-hallucination instructions
 * 3. Explicit content lists - Only these titles exist
 * 4. Formatted content details - For context
 *
 * @param {Object} platformContent - { articles, quizzes, categories }
 * @returns {string} Complete system prompt
 */
const buildSystemPrompt = (platformContent) => {
  // Get formatted content for detailed sections
  const contentSection = formatContentForPrompt(platformContent);
  const { articles, quizzes } = platformContent;

  // Create explicit lists of valid titles (for anti-hallucination)
  // These are shown separately from the detailed list to emphasize boundaries
  const articleTitles = articles.map(a => `"${a.title}"`).join(', ') || 'None available';
  const quizTitles = quizzes.map(q => `"${q.title}"`).join(', ') || 'None available';

  // Build and return the complete system prompt
  return `You are EcoBot, a friendly assistant for EcoJourney - a sustainability education platform at the RP ESG Centre.

YOUR ROLE:
- Answer questions about sustainability and eco-friendly practices
- Help users find articles and quizzes on the platform
- Provide general tips on environmental topics

CRITICAL RULES - YOU MUST FOLLOW THESE:
1. NEVER invent or make up article or quiz names. ONLY mention content that exists in the lists below.
2. If the user asks about a topic and there is NO matching article/quiz in the lists below, say "We don't have specific content on that topic yet, but here's what I know..." and provide general information.
3. When recommending content, use EXACT titles from the lists and format as: [Exact Title](/articles/exact-slug) or [Exact Title](/quizzes/exact-slug)
4. Do NOT mention difficulty levels, points, or URLs as plain text.
5. If there are no articles or quizzes available, tell the user honestly.

AVAILABLE ARTICLES (ONLY THESE EXIST - use exact titles):
${articleTitles}

AVAILABLE QUIZZES (ONLY THESE EXIST - use exact titles):
${quizTitles}

${contentSection}

REMEMBER: If a title is not in the lists above, it DOES NOT EXIST. Never make up content names.`;
};

// =========================================================================
// MAIN API FUNCTIONS
// =========================================================================

/**
 * Send Message to Chatbot
 *
 * Main function called when user sends a message.
 * Handles the full flow: fetch content -> build prompt -> call API -> save history
 *
 * @param {string} userMessage - The user's message text
 * @param {string} apiKey - Groq API key (stored by admin)
 * @returns {Object} { message: string, history: Array }
 * @throws {Error} If API key missing or API call fails
 */
export const sendMessage = async (userMessage, apiKey) => {
  // Validate API key is provided
  if (!apiKey) {
    throw new Error('Groq API key is required. Please add your API key in settings.');
  }

  // Fetch platform content for RAG (uses cache if available)
  const platformContent = await fetchPlatformContent();

  // Get existing conversation history
  const history = getConversationHistory();

  // Add user's new message to history
  const updatedHistory = [
    ...history,
    { role: 'user', content: userMessage }
  ];

  // Build system prompt with full platform knowledge
  const systemPrompt = buildSystemPrompt(platformContent);

  // Prepare messages array for API
  // Format: system message first, then conversation history
  const messages = [
    { role: 'system', content: systemPrompt },
    ...updatedHistory.slice(-20)  // Keep last 20 messages to avoid token limits
  ];

  try {
    // Call Groq API
    const response = await fetch(GROQ_API_URL, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,  // API key authentication
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',  // Llama 3.3 70B model via Groq
        messages: messages,
        temperature: 0.7,    // Moderate creativity (0 = deterministic, 1 = very creative)
        max_tokens: 1024,    // Maximum response length
        top_p: 1,            // Nucleus sampling (1 = consider all tokens)
        stream: false,       // Get complete response (not streaming)
      }),
    });

    // Handle API errors
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));

      // Provide helpful error messages for common issues
      if (response.status === 401) {
        throw new Error('Invalid API key. Please check your Groq API key.');
      }
      if (response.status === 429) {
        throw new Error('Rate limit exceeded. Please wait a moment and try again.');
      }
      throw new Error(errorData.error?.message || `API error: ${response.status}`);
    }

    // Parse successful response
    const data = await response.json();
    const assistantMessage = data.choices[0]?.message?.content || 'Sorry, I could not generate a response.';

    // Save complete history with assistant's response
    const finalHistory = [
      ...updatedHistory,
      { role: 'assistant', content: assistantMessage }
    ];
    saveConversationHistory(finalHistory);

    // Return response and updated history
    return {
      message: assistantMessage,
      history: finalHistory,
    };
  } catch (error) {
    // Even on error, save the user's message to history
    // This preserves context if they retry
    saveConversationHistory(updatedHistory);
    throw error;  // Re-throw for UI to handle
  }
};

/**
 * Get Chat History
 * Returns the current conversation history for display
 *
 * @returns {Array} Array of message objects
 */
export const getChatHistory = () => {
  return getConversationHistory();
};

/**
 * Clear Chat
 * Starts a new conversation by clearing history
 */
export const clearChat = () => {
  clearConversationHistory();
};

/**
 * Refresh Content Cache
 * Forces a fresh fetch of platform content
 * Useful if admin has added new content and wants immediate update
 *
 * @returns {Object} Fresh platform content
 */
export const refreshContentCache = async () => {
  platformContentCache = null;  // Clear cache
  cacheTimestamp = 0;           // Reset timestamp
  return await fetchPlatformContent();  // Fetch fresh data
};

/**
 * Get Stored API Key
 * Retrieves the Groq API key from localStorage
 *
 * Note: API key is stored in localStorage (persists across sessions)
 * Only admins can set/view this key via the settings panel
 *
 * @returns {string} API key or empty string if not set
 */
export const getStoredApiKey = () => {
  return localStorage.getItem('groq_api_key') || '';
};

/**
 * Store API Key
 * Saves or removes the Groq API key in localStorage
 *
 * @param {string} key - API key to store, or empty/null to remove
 */
export const storeApiKey = (key) => {
  if (key) {
    localStorage.setItem('groq_api_key', key);
  } else {
    localStorage.removeItem('groq_api_key');
  }
};

// Default export with all public functions
export default {
  sendMessage,
  getChatHistory,
  clearChat,
  refreshContentCache,
  getStoredApiKey,
  storeApiKey,
};
