/**
 * API Service
 *
 * Centralized module for all API calls to the Strapi backend.
 * Uses axios for HTTP requests with consistent configuration.
 *
 * Organization:
 * -------------
 * - Categories: CRUD operations for quiz/article categories
 * - Tags: Fetch tags for filtering
 * - Articles: CRUD operations for educational articles
 * - Quizzes: CRUD operations for quizzes
 * - Quiz Results: Score submission, leaderboard, and progress tracking
 * - Admin: User management, score management
 *
 * Authentication:
 * ---------------
 * Most read operations are public (no token needed).
 * Write operations (create, update, delete) require JWT token.
 * Token is passed in Authorization header as "Bearer {token}".
 *
 * Strapi v5 Notes:
 * ----------------
 * - Uses documentId for updates/deletes (not numeric id)
 * - Nested data is accessed via populate parameter
 * - Response format: { data: [...], meta: {...} }
 */

import axios from 'axios';

// Base URL for all API calls - change for production
const API_URL = 'http://localhost:1337/api';

// Create axios instance with base configuration
const api = axios.create({
  baseURL: API_URL,
});

// =============================================================================
// CATEGORIES
// Categories organize articles and quizzes by topic (e.g., "Energy", "Waste")
// =============================================================================

/**
 * Get All Categories
 * @returns {Promise} Axios response with categories array
 */
export const getCategories = () => api.get('/categories?populate=*');

/**
 * Get Single Category by ID
 * @param {string} id - Category ID or documentId
 * @returns {Promise} Axios response with category object
 */
export const getCategory = (id) => api.get(`/categories/${id}?populate=*`);

// =============================================================================
// TAGS
// Tags provide more specific filtering within categories
// =============================================================================

/**
 * Get All Tags
 * @returns {Promise} Axios response with tags array
 */
export const getTags = () => api.get('/tags?populate=*');

// =============================================================================
// ARTICLES
// Educational content about sustainability topics
// =============================================================================

/**
 * Get All Articles
 * @param {Object} params - Optional query parameters for filtering
 * @returns {Promise} Axios response with articles array
 */
export const getArticles = (params = {}) => {
  const query = new URLSearchParams({
    'populate': '*',  // Include all relations (category, tags, cover image)
    ...params
  });
  return api.get(`/articles?${query}`);
};

/**
 * Get Single Article by ID
 * @param {string} id - Article ID or documentId
 * @returns {Promise} Axios response with article object
 */
export const getArticle = (id) => api.get(`/articles/${id}?populate=*`);

/**
 * Get Article by Slug
 * Used for SEO-friendly URLs (e.g., /articles/sustainable-living)
 * @param {string} slug - URL-friendly article identifier
 * @returns {Promise} Axios response with article object
 */
export const getArticleBySlug = (slug) =>
  api.get(`/articles?filters[slug][$eq]=${slug}&populate=*`);

// =============================================================================
// ARTICLES - ADMIN OPERATIONS
// Requires authentication token
// =============================================================================

/**
 * Create New Article
 * @param {Object} data - Article data (title, content, category, etc.)
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with created article
 */
export const createArticle = (data, token) =>
  api.post('/articles', { data }, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Update Existing Article
 * @param {string} documentId - Article's documentId (Strapi v5)
 * @param {Object} data - Updated article data
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with updated article
 */
export const updateArticle = (documentId, data, token) =>
  api.put(`/articles/${documentId}`, { data }, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Delete Article
 * @param {string} documentId - Article's documentId (Strapi v5)
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response confirming deletion
 */
export const deleteArticle = (documentId, token) =>
  api.delete(`/articles/${documentId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });

// =============================================================================
// QUIZZES
// Interactive quizzes to test sustainability knowledge
// =============================================================================

/**
 * Get All Quizzes
 * @param {Object} params - Optional query parameters for filtering
 * @returns {Promise} Axios response with quizzes array
 */
export const getQuizzes = (params = {}) => {
  const query = new URLSearchParams({
    'populate': '*',  // Include category, tags, questions
    ...params
  });
  return api.get(`/quizzes?${query}`);
};

/**
 * Get Single Quiz by ID
 * @param {string} id - Quiz ID or documentId
 * @returns {Promise} Axios response with quiz object
 */
export const getQuiz = (id) => api.get(`/quizzes/${id}?populate=*`);

/**
 * Get Quiz by Slug
 * Used for SEO-friendly URLs (e.g., /quizzes/energy-basics)
 * @param {string} slug - URL-friendly quiz identifier
 * @returns {Promise} Axios response with quiz object
 */
export const getQuizBySlug = (slug) =>
  api.get(`/quizzes?filters[slug][$eq]=${slug}&populate=*`);

/**
 * Get Quiz Questions from Question Bank
 * Fetches questions dynamically based on quiz configuration and difficulty.
 * Uses custom endpoint that selects questions from the question bank.
 *
 * @param {string} quizId - Quiz ID to get questions for
 * @param {string} difficulty - Optional difficulty filter ('easy', 'medium', 'hard')
 * @returns {Promise} Axios response with questions array
 */
export const getQuizQuestions = (quizId, difficulty) => {
  const params = difficulty ? `?difficulty=${difficulty}` : '';
  return api.get(`/quizzes/${quizId}/questions${params}`);
};

// =============================================================================
// QUIZZES - ADMIN OPERATIONS
// Requires authentication token
// =============================================================================

/**
 * Create New Quiz
 * @param {Object} data - Quiz data (title, description, category, etc.)
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with created quiz
 */
export const createQuiz = (data, token) =>
  api.post('/quizzes', { data }, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Update Existing Quiz
 * @param {string} documentId - Quiz's documentId (Strapi v5)
 * @param {Object} data - Updated quiz data
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with updated quiz
 */
export const updateQuiz = (documentId, data, token) =>
  api.put(`/quizzes/${documentId}`, { data }, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Delete Quiz
 * @param {string} documentId - Quiz's documentId (Strapi v5)
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response confirming deletion
 */
export const deleteQuiz = (documentId, token) =>
  api.delete(`/quizzes/${documentId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Update Quiz Tags
 * Specialized endpoint for updating quiz tag associations
 * @param {string} documentId - Quiz's documentId
 * @param {Array} tags - Array of tag IDs
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with updated quiz
 */
export const updateQuizTags = (documentId, tags, token) =>
  api.put(`/quizzes/${documentId}/tags`, { tags }, {
    headers: { Authorization: `Bearer ${token}` }
  });

// =============================================================================
// ADMIN - USER MANAGEMENT
// Administrative functions for managing users
// =============================================================================

/**
 * Get All Users (Admin Only)
 * @param {string} token - JWT authentication token (must be admin)
 * @returns {Promise} Axios response with users array
 */
export const getAllUsers = (token) =>
  api.get('/admin-panel/users', {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Get All Roles (Admin Only)
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with roles array
 */
export const getAllRoles = (token) =>
  api.get('/admin-panel/roles', {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Change User Password (Admin Only)
 * Allows admin to reset a user's password
 * @param {number} userId - User's ID
 * @param {string} newPassword - New password to set
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response confirming update
 */
export const changeUserPassword = (userId, newPassword, token) =>
  api.put(`/admin-panel/users/${userId}/password`,
    { newPassword },
    { headers: { Authorization: `Bearer ${token}` } }
  );

/**
 * Update User Details (Admin Only)
 * @param {number} userId - User's ID
 * @param {Object} data - Updated user data
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with updated user
 */
export const updateUser = (userId, data, token) =>
  api.put(`/admin-panel/users/${userId}`,
    data,
    { headers: { Authorization: `Bearer ${token}` } }
  );

/**
 * Update User Role (Admin Only)
 * Changes a user's role (e.g., promote to writer/admin)
 * @param {number} userId - User's ID
 * @param {number} roleId - New role's ID
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response confirming update
 */
export const updateUserRole = (userId, roleId, token) =>
  api.put(`/admin-panel/users/${userId}/role`,
    { roleId },
    { headers: { Authorization: `Bearer ${token}` } }
  );

/**
 * Delete User (Admin Only)
 * @param {number} userId - User's ID
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response confirming deletion
 */
export const deleteUser = (userId, token) =>
  api.delete(`/admin-panel/users/${userId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });

// =============================================================================
// QUIZ RESULTS - ADMIN OPERATIONS
// Managing quiz scores for leaderboard
// =============================================================================

/**
 * Get All Quiz Results (Admin Only)
 * Used for score management in admin panel
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with all quiz results
 */
export const getQuizResults = (token) =>
  api.get('/quiz-results?populate=*&pagination[limit]=1000&sort=createdAt:desc', {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Update Quiz Result (Admin Only)
 * Allows admin to modify a user's score
 * @param {string} documentId - Quiz result's documentId
 * @param {Object} data - Updated result data
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with updated result
 */
export const updateQuizResultAdmin = (documentId, data, token) =>
  api.put(`/quiz-results/${documentId}`,
    { data },
    { headers: { Authorization: `Bearer ${token}` } }
  );

/**
 * Delete Quiz Result (Admin Only)
 * Removes a quiz result from the leaderboard
 * @param {string} documentId - Quiz result's documentId
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response confirming deletion
 */
export const deleteQuizResultAdmin = (documentId, token) =>
  api.delete(`/quiz-results/${documentId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });

// =============================================================================
// QUIZ RESULTS - USER OPERATIONS
// Submitting and viewing quiz scores
// =============================================================================

/**
 * Submit Quiz Result
 * Called when a user completes a quiz to save their score
 *
 * @param {Object} resultData - Quiz result data
 * @param {number} resultData.quizId - ID of the completed quiz
 * @param {number} resultData.userId - User's ID
 * @param {string} resultData.username - User's username
 * @param {number} resultData.score - Number of correct answers
 * @param {number} resultData.totalQuestions - Total questions in quiz
 * @param {number} resultData.points - Points earned (with difficulty multiplier)
 * @param {number} resultData.maxPoints - Maximum possible points
 * @param {string} resultData.difficulty - Difficulty level
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with created result
 */
export const submitQuizResult = (resultData, token) => {
  return api.post('/quiz-results', {
    data: {
      quiz: resultData.quizId,
      user: resultData.userId,
      userId: resultData.userId,
      username: resultData.username,
      score: resultData.score,
      totalQuestions: resultData.totalQuestions,
      points: resultData.points || resultData.score,
      maxPoints: resultData.maxPoints || resultData.totalQuestions,
      difficulty: resultData.difficulty || 'medium',
      percentage: Math.round((resultData.score / resultData.totalQuestions) * 100),
      completedAt: new Date().toISOString()
    }
  }, {
    headers: { Authorization: `Bearer ${token}` }
  });
};

/**
 * Get User's Quiz Results
 * Fetches all quiz results for a specific user
 * @param {number} userId - User's ID
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with user's results
 */
export const getUserQuizResults = (userId, token) =>
  api.get(`/quiz-results?filters[user][id][$eq]=${userId}&populate=*&sort=completedAt:desc`, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Get Quiz Results by Quiz
 * Fetches all results for a specific quiz (for quiz-specific leaderboard)
 * @param {number} quizId - Quiz's ID
 * @param {string} token - JWT authentication token
 * @returns {Promise} Axios response with quiz results
 */
export const getQuizResultsByQuiz = (quizId, token) =>
  api.get(`/quiz-results?filters[quiz][id][$eq]=${quizId}&populate=*&sort=points:desc`, {
    headers: { Authorization: `Bearer ${token}` }
  });

/**
 * Get Leaderboard
 * Fetches top scores for the public leaderboard
 * @param {number} limit - Maximum number of results (default: 10)
 * @returns {Promise} Axios response with top scores
 */
export const getLeaderboard = (limit = 10) =>
  api.get(`/quiz-results?sort=points:desc&pagination[limit]=${limit}`);

/**
 * Get All Quiz Results (Public)
 * Used by the leaderboard page to get all results
 * @returns {Promise} Axios response with all results
 */
export const getAllQuizResults = () => {
  const token = localStorage.getItem('token');
  return api.get('/quiz-results?populate=quiz&pagination[limit]=1000&sort=createdAt:desc', {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
};

/**
 * Update Quiz Result
 * General update function (auto-gets token from localStorage)
 * @param {string} documentId - Quiz result's documentId
 * @param {Object} data - Updated result data
 * @returns {Promise} Axios response with updated result
 */
export const updateQuizResult = (documentId, data) => {
  const token = localStorage.getItem('token');
  return api.put(`/quiz-results/${documentId}`, { data }, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
};

/**
 * Delete Quiz Result
 * General delete function (auto-gets token from localStorage)
 * @param {string} documentId - Quiz result's documentId
 * @returns {Promise} Axios response confirming deletion
 */
export const deleteQuizResult = (documentId) => {
  const token = localStorage.getItem('token');
  return api.delete(`/quiz-results/${documentId}`, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
};

/**
 * Reset User Progress
 * Deletes all quiz results for the current user
 * Used by the "Reset Progress" button in Profile
 * @returns {Promise} Axios response confirming reset
 */
export const resetUserProgress = () => {
  const token = localStorage.getItem('token');
  return api.post('/admin-panel/reset-progress', {}, {
    headers: token ? { Authorization: `Bearer ${token}` } : {}
  });
};

// Export the axios instance for direct use if needed
export default api;
