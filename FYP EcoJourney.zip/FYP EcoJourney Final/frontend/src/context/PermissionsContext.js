/**
 * Permissions Context
 *
 * This context provides role-based permission checks to the application.
 * It determines what actions a user can perform based on their role.
 *
 * Roles in the System:
 * --------------------
 * - Admin: Full access (can delete, edit, create)
 * - Writer: Can edit and create content, but cannot delete
 * - Authenticated: Regular logged-in user
 * - Public: Not logged in (no permissions)
 *
 * Usage:
 * ------
 * import { usePermissions } from './context/PermissionsContext';
 * const { canDelete, canEdit, canCreate, isWriter, isAdmin } = usePermissions();
 *
 * // In component:
 * {canDelete && <button onClick={handleDelete}>Delete</button>}
 */

import React, { createContext, useContext } from 'react';
import { useAuth } from './AuthContext';

// Create the permissions context
const PermissionsContext = createContext();

/**
 * Custom Hook: usePermissions
 *
 * Provides easy access to permissions context from any component.
 * Throws error if used outside PermissionsProvider.
 *
 * @returns {Object} Permissions object with boolean flags
 * @throws {Error} If used outside of PermissionsProvider
 */
export const usePermissions = () => {
  const context = useContext(PermissionsContext);
  if (!context) {
    throw new Error('usePermissions must be used within PermissionsProvider');
  }
  return context;
};

/**
 * PermissionsProvider Component
 *
 * Wraps the application and provides permission checks to all children.
 * Must be placed after AuthProvider in the component tree.
 *
 * @param {Object} props
 * @param {React.ReactNode} props.children - Child components to wrap
 */
export const PermissionsProvider = ({ children }) => {
  // Get current user from AuthContext
  const { user } = useAuth();

  /**
   * Permissions Object
   *
   * Defines what actions the current user can perform.
   * These are derived from the user's role type.
   */
  const permissions = {
    // Only admin can delete content
    // Note: 'authenticated' type is treated as admin here (may need adjustment)
    canDelete: user?.role?.type === 'admin' || user?.role?.type === 'authenticated',

    // Both admin and writer can edit existing content
    canEdit: true,

    // Both admin and writer can create new content
    canCreate: true,

    // Check if user is specifically a writer
    isWriter: user?.role?.type === 'writer',

    // Check if user is an admin
    // Note: 'authenticated' type is treated as admin here
    isAdmin: user?.role?.type === 'admin' || user?.role?.type === 'authenticated',
  };

  return (
    <PermissionsContext.Provider value={permissions}>
      {children}
    </PermissionsContext.Provider>
  );
};
