/**
 * Authentication Context
 *
 * This context provides authentication state and methods to the entire application.
 * It handles user login, registration, logout, and session persistence.
 *
 * Features:
 * ---------
 * - JWT-based authentication with Strapi backend
 * - Automatic session restoration from localStorage
 * - User role fetching for admin/writer privileges
 * - Login/Register/Logout methods
 *
 * How it works:
 * -------------
 * 1. On app load, checks localStorage for saved token/user
 * 2. If found, validates and restores the session
 * 3. Fetches user role information from custom endpoint
 * 4. Provides auth state and methods to all child components
 *
 * Usage:
 * ------
 * import { useAuth } from './context/AuthContext';
 * const { user, login, logout, isAuthenticated, isAdmin } = useAuth();
 */

import React, { createContext, useState, useContext, useEffect } from 'react';
import axios from 'axios';

// Create the context with undefined default (will be populated by provider)
const AuthContext = createContext();

/**
 * Custom Hook: useAuth
 *
 * Provides easy access to auth context from any component.
 * Throws error if used outside AuthProvider (helps catch bugs).
 *
 * @returns {Object} Auth context value with user, token, login, logout, etc.
 * @throws {Error} If used outside of AuthProvider
 */
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider');
  }
  return context;
};

/**
 * AuthProvider Component
 *
 * Wraps the application and provides authentication context to all children.
 * Must be placed near the root of the component tree (in App.js).
 *
 * @param {Object} props
 * @param {React.ReactNode} props.children - Child components to wrap
 */
export const AuthProvider = ({ children }) => {
  // =========================================================================
  // STATE
  // =========================================================================

  const [user, setUser] = useState(null);      // Current user object (null if not logged in)
  const [token, setToken] = useState(null);    // JWT token (null if not logged in)
  const [loading, setLoading] = useState(true); // True while checking saved auth

  // =========================================================================
  // EFFECTS
  // =========================================================================

  /**
   * Effect: Check for Saved Authentication on Mount
   *
   * When the app loads:
   * 1. Check if the server has restarted (session ID changed)
   * 2. If restarted, clear saved auth and require re-login
   * 3. If not, restore the session and fetch updated user role
   */
  useEffect(() => {
    const checkAuth = async () => {
      // First, check if the server has restarted by comparing session IDs
      // This ensures users are logged out when the server restarts
      try {
        const sessionResponse = await axios.get('http://localhost:1337/api/server-session');
        const currentServerSessionId = sessionResponse.data.sessionId;
        const savedServerSessionId = localStorage.getItem('serverSessionId');

        // If we have a saved session ID and it doesn't match, server has restarted
        if (savedServerSessionId && savedServerSessionId !== currentServerSessionId) {
          console.log('Server has restarted. Logging out user.');
          // Clear all auth data
          localStorage.removeItem('token');
          localStorage.removeItem('user');
          localStorage.removeItem('serverSessionId');
          // Save the new session ID for future checks
          localStorage.setItem('serverSessionId', currentServerSessionId);
          setLoading(false);
          return; // Don't restore session, user must re-login
        }

        // Save the current server session ID (first visit or session matches)
        localStorage.setItem('serverSessionId', currentServerSessionId);
      } catch (error) {
        console.warn('Could not check server session:', error);
        // If server is unreachable, we still try to use saved auth
        // The API calls will fail anyway if server is down
      }

      // Get saved auth data from localStorage
      const savedToken = localStorage.getItem('token');
      const savedUser = localStorage.getItem('user');

      if (savedToken && savedUser) {
        const parsedUser = JSON.parse(savedUser);

        // If user doesn't have role info, fetch it using the custom endpoint
        // Role info is needed for admin/writer access control
        if (!parsedUser.role) {
          try {
            // Custom endpoint that returns user with role populated
            const userWithRole = await axios.get(`http://localhost:1337/api/admin-panel/me`, {
              headers: {
                Authorization: `Bearer ${savedToken}`,
              },
            });

            const fullUser = userWithRole.data;
            setUser(fullUser);
            // Update localStorage with full user data
            localStorage.setItem('user', JSON.stringify(fullUser));
          } catch (error) {
            console.error('Error fetching user role:', error);
            // If role fetch fails, use saved user data (may be missing role)
            setUser(parsedUser);
          }
        } else {
          // User already has role info, use as-is
          setUser(parsedUser);
        }

        setToken(savedToken);
      }
      // Done checking auth, allow app to render
      setLoading(false);
    };

    checkAuth();
  }, []);

  // =========================================================================
  // AUTH METHODS
  // =========================================================================

  /**
   * Register a New User
   *
   * Creates a new user account via Strapi's auth API.
   * Automatically logs in the user after successful registration.
   *
   * @param {string} username - Desired username
   * @param {string} email - User's email address
   * @param {string} password - User's password
   * @returns {Object} { success: boolean, error?: string }
   */
  const register = async (username, email, password) => {
    try {
      // Call Strapi's built-in registration endpoint
      const response = await axios.post('http://localhost:1337/api/auth/local/register', {
        username,
        email,
        password,
      });

      const { jwt, user } = response.data;

      // Try to fetch user with role information using the custom endpoint
      // New users typically get 'authenticated' role by default
      let fullUser = user;
      try {
        const userWithRole = await axios.get(`http://localhost:1337/api/admin-panel/me`, {
          headers: {
            Authorization: `Bearer ${jwt}`,
          },
        });
        fullUser = userWithRole.data;
      } catch (roleError) {
        console.warn('Could not fetch user role, using basic user data:', roleError);
        // Use basic user data if role fetch fails (still functional)
      }

      // Set auth state
      setToken(jwt);
      setUser(fullUser);

      // Persist to localStorage for session restoration
      localStorage.setItem('token', jwt);
      localStorage.setItem('user', JSON.stringify(fullUser));

      return { success: true };
    } catch (error) {
      console.error('Registration error:', error);
      return {
        success: false,
        error: error.response?.data?.error?.message || 'Registration failed'
      };
    }
  };

  /**
   * Login User
   *
   * Authenticates user via Strapi's auth API.
   * Supports login with either email or username (identifier).
   *
   * @param {string} identifier - Email or username
   * @param {string} password - User's password
   * @returns {Object} { success: boolean, user?: Object, error?: string }
   */
  const login = async (identifier, password) => {
    try {
      // Call Strapi's built-in login endpoint
      const response = await axios.post('http://localhost:1337/api/auth/local', {
        identifier, // Can be email or username
        password,
      });

      const { jwt, user } = response.data;

      // Try to fetch user with role information using the custom endpoint
      // This is needed to determine admin/writer access
      let fullUser = user;
      try {
        const userWithRole = await axios.get(`http://localhost:1337/api/admin-panel/me`, {
          headers: {
            Authorization: `Bearer ${jwt}`,
          },
        });
        fullUser = userWithRole.data;
      } catch (roleError) {
        console.warn('Could not fetch user role, using basic user data:', roleError);
        // Use basic user data if role fetch fails
      }

      // Set auth state
      setToken(jwt);
      setUser(fullUser);

      // Persist to localStorage for session restoration
      localStorage.setItem('token', jwt);
      localStorage.setItem('user', JSON.stringify(fullUser));

      return { success: true, user: fullUser };
    } catch (error) {
      console.error('Login error:', error);
      return {
        success: false,
        error: error.response?.data?.error?.message || 'Login failed'
      };
    }
  };

  /**
   * Logout User
   *
   * Clears auth state and removes saved session from localStorage.
   * Note: We keep serverSessionId so we can detect future server restarts
   */
  const logout = () => {
    setToken(null);
    setUser(null);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    // Note: We intentionally keep serverSessionId in localStorage
    // so we can still detect server restarts after logout
  };

  // =========================================================================
  // COMPUTED VALUES
  // =========================================================================

  // Check if user has admin role (handles different role formats)
  const isAdmin = user?.role?.type === 'admin' || user?.role?.name === 'Admin';

  // =========================================================================
  // CONTEXT VALUE
  // =========================================================================

  // Object provided to all consumers of this context
  const value = {
    user,                           // Current user object or null
    token,                          // JWT token or null
    login,                          // Login function
    register,                       // Register function
    logout,                         // Logout function
    isAuthenticated: !!token,       // Boolean: is user logged in?
    isAdmin,                        // Boolean: is user an admin?
  };

  // =========================================================================
  // RENDER
  // =========================================================================

  // Show loading while checking saved auth
  // This prevents flash of unauthenticated content
  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  // Provide auth context to children
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};
