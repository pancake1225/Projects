/**
 * Manage Articles Page Component
 *
 * Admin/Writer dashboard for creating, editing, and managing articles.
 * Shared between Admin (/admin/articles) and Writer (/writer/articles) roles.
 *
 * Features:
 * ---------
 * 1. Create new articles with rich content
 * 2. Edit existing articles (title, body, category, tags)
 * 3. Delete articles (Admin only - Writers cannot delete)
 * 4. Upload thumbnail images for article cards
 * 5. Upload and manage video attachments
 * 6. Create new tags on-the-fly while editing
 * 7. Filter articles by category, tag, and search
 * 8. Sort articles by date, title, or category
 *
 * Access Control:
 * ---------------
 * - Accessible by Admin and Writer roles
 * - Writers can create/edit but NOT delete
 * - Delete button hidden for non-Admin users (via canDelete permission)
 * - Shows AdminNav or WriterNav based on URL path
 *
 * Content Structure:
 * ------------------
 * - Title: Article headline (required)
 * - Slug: URL-friendly identifier (auto-generated, required)
 * - Description: Short summary for cards
 * - Body: Full article content (stored as Strapi blocks)
 * - Category: Single category assignment
 * - Tags: Multiple tag selection (category-filtered)
 * - Thumbnail: Image for article cards
 * - Media: Video attachments (can be deleted/added)
 *
 * API Endpoints:
 * --------------
 * - GET /articles - Fetch all articles
 * - POST /articles - Create new article
 * - PUT /articles/:documentId - Update article
 * - DELETE /articles/:documentId - Delete article
 * - POST /upload - Upload media files
 */

import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { usePermissions } from '../context/PermissionsContext';
import { getArticles, createArticle, updateArticle, deleteArticle, getCategories } from '../services/api';
import AdminNav from '../components/AdminNav';
import WriterNav from '../components/WriterNav';
import './ManageArticles.css';

function ManageArticles() {
  const location = useLocation();
  const { token, user } = useAuth();
  const { canDelete } = usePermissions();  // Only Admins can delete

  // Determine which navigation to show based on URL path
  const isWriterPath = location.pathname.startsWith('/writer');

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // Article data
  const [articles, setArticles] = useState([]);        // All articles from API
  const [categories, setCategories] = useState([]);    // Categories for dropdown
  const [tags, setTags] = useState([]);                // Tags for checkbox selection

  // UI state
  const [loading, setLoading] = useState(true);        // Loading indicator
  const [error, setError] = useState(null);            // Error message
  const [successMessage, setSuccessMessage] = useState(''); // Success feedback

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);   // Modal visibility
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [selectedArticle, setSelectedArticle] = useState(null); // Article being edited
  const [submitting, setSubmitting] = useState(false); // Form submission state

  // Filter and sort state
  const [sortBy, setSortBy] = useState('recent');      // Sort order
  const [filterCategory, setFilterCategory] = useState(''); // Category filter
  const [filterTag, setFilterTag] = useState('');      // Tag filter
  const [searchQuery, setSearchQuery] = useState('');  // Search text

  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    description: '',
    body: '',
    tags: [],
    category: null,
  });
  const [thumbnailFile, setThumbnailFile] = useState(null);
  const [thumbnailPreview, setThumbnailPreview] = useState(null);
  const [videoFiles, setVideoFiles] = useState([]);
  const [videosToDelete, setVideosToDelete] = useState([]);
  const [imageFiles, setImageFiles] = useState([]);
  const [imagesToDelete, setImagesToDelete] = useState([]);
  const [showNewTagInput, setShowNewTagInput] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagCategory, setNewTagCategory] = useState('');

  useEffect(() => {
    fetchArticles();
    fetchCategories();
    fetchTags();
  }, []);

  const handleCategoryFilterChange = (e) => {
    setFilterCategory(e.target.value);
    setFilterTag(''); // Clear tag filter when category changes
  };

  const fetchCategories = async () => {
    try {
      const response = await getCategories();
      setCategories(response.data.data || []);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await fetch('http://localhost:1337/api/tags?populate=category', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setTags(data.data || []);
    } catch (err) {
      console.error('Failed to fetch tags:', err);
    }
  };

  const fetchArticles = async () => {
    try {
      setLoading(true);
      const response = await getArticles();
      setArticles(response.data.data || []);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch articles:', err);
      setError('Failed to load articles. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const openCreateModal = () => {
    setModalMode('create');
    setFormData({
      title: '',
      slug: '',
      description: '',
      body: '',
      tags: [],
      category: null,
    });
    setModalOpen(true);
  };

  const openEditModal = (article) => {
    setModalMode('edit');
    setSelectedArticle(article);

    // Convert body blocks to plain text for editing
    let bodyText = '';

    if (article.body && Array.isArray(article.body)) {
      bodyText = article.body.map(block => {
        if (block.type === 'paragraph' && block.children) {
          return block.children.map(child => child.text || '').join('');
        }
        return '';
      }).join('\n\n');
    } else if (typeof article.body === 'string') {
      bodyText = article.body;
    }

    // Parse tags from string to array
    const tagArray = article.tags ? article.tags.split(',').map(t => t.trim()).filter(t => t) : [];

    setFormData({
      title: article.title || '',
      slug: article.slug || '',
      description: article.description || '',
      body: bodyText,
      tags: tagArray,
      category: article.category?.id || null,
    });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setSelectedArticle(null);
    setThumbnailFile(null);
    setThumbnailPreview(null);
    setVideoFiles([]);
    setVideosToDelete([]);
    setImageFiles([]);
    setImagesToDelete([]);
    setShowNewTagInput(false);
    setNewTagName('');
    setNewTagCategory('');
    setError(null);
  };

  const handleThumbnailChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file');
        return;
      }
      setThumbnailFile(file);
      setThumbnailPreview(URL.createObjectURL(file));
    }
  };

  const uploadThumbnail = async (file) => {
    const formData = new FormData();
    formData.append('files', file);

    const response = await fetch('http://localhost:1337/api/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to upload thumbnail');
    }

    const data = await response.json();
    return data[0].id; // Return the uploaded file ID
  };

  const handleVideoChange = (e) => {
    const files = Array.from(e.target.files);
    const validFiles = files.filter(file => file.type.startsWith('video/'));
    if (validFiles.length !== files.length) {
      setError('Please select only video files');
      return;
    }
    setVideoFiles(prev => [...prev, ...validFiles]);
  };

  const handleRemoveNewVideo = (index) => {
    setVideoFiles(prev => prev.filter((_, i) => i !== index));
  };

  const uploadVideos = async (files) => {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    const response = await fetch('http://localhost:1337/api/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to upload videos');
    }

    const data = await response.json();
    return data.map(file => file.id); // Return array of uploaded file IDs
  };

  const handleRemoveVideo = (videoId) => {
    setVideosToDelete(prev => [...prev, videoId]);
  };

  const handleUndoRemoveVideo = (videoId) => {
    setVideosToDelete(prev => prev.filter(id => id !== videoId));
  };

  const handleImageChange = (e) => {
    const files = Array.from(e.target.files);
    const validFiles = files.filter(file => file.type.startsWith('image/'));
    if (validFiles.length !== files.length) {
      setError('Please select only image files');
      return;
    }
    setImageFiles(prev => [...prev, ...validFiles]);
  };

  const handleRemoveNewImage = (index) => {
    setImageFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleRemoveImage = (imageId) => {
    setImagesToDelete(prev => [...prev, imageId]);
  };

  const handleUndoRemoveImage = (imageId) => {
    setImagesToDelete(prev => prev.filter(id => id !== imageId));
  };

  const handleTagCheckboxChange = (tagId) => {
    setFormData(prev => {
      const tagIdStr = String(tagId);
      const isSelected = prev.tags.includes(tagIdStr);
      const newTags = isSelected
        ? prev.tags.filter(id => id !== tagIdStr)
        : [...prev.tags, tagIdStr];
      return {
        ...prev,
        tags: newTags
      };
    });
  };

  const handleCreateNewTag = async () => {
    if (!newTagName.trim()) {
      setError('Tag name cannot be empty');
      return;
    }

    const categoryToUse = newTagCategory || formData.category;
    if (!categoryToUse) {
      setError('Please select a category first');
      return;
    }

    try {
      const response = await fetch('http://localhost:1337/api/tags', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          data: {
            name: newTagName,
            category: parseInt(categoryToUse),
            publishedAt: new Date().toISOString(),
          }
        })
      });

      if (!response.ok) throw new Error('Failed to create tag');

      const data = await response.json();
      const newTag = data.data;

      await fetchTags();

      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, String(newTag.id)]
      }));

      setSuccessMessage(`Tag "${newTagName}" created successfully!`);
      setShowNewTagInput(false);
      setNewTagName('');
      setNewTagCategory('');
      setError(null);
    } catch (err) {
      console.error('Failed to create tag:', err);
      setError('Failed to create tag. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Auto-generate slug from title
    if (name === 'title' && modalMode === 'create') {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setFormData(prev => ({
        ...prev,
        slug
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage('');

    if (!formData.title || !formData.slug || !formData.body) {
      setError('Title, slug, and body are required');
      return;
    }

    try {
      setSubmitting(true);

      // Upload thumbnail if provided
      let thumbnailId = null;
      if (thumbnailFile) {
        thumbnailId = await uploadThumbnail(thumbnailFile);
      }

      // Upload videos if provided
      let videoIds = [];
      if (videoFiles.length > 0) {
        videoIds = await uploadVideos(videoFiles);
      }

      // Upload images if provided
      let imageIds = [];
      if (imageFiles.length > 0) {
        imageIds = await uploadVideos(imageFiles);
      }

      // Prepare data for Strapi
      // Convert plain text to blocks format (only standard Strapi block types)
      const bodyBlocks = formData.body.split('\n').filter(line => line.trim()).map(line => ({
        type: 'paragraph',
        children: [{ type: 'text', text: line }]
      }));

      const submitData = {
        title: formData.title,
        description: formData.description,
        body: bodyBlocks,
        tags: Array.isArray(formData.tags) ? formData.tags.join(', ') : (formData.tags || ''),
      };

      // Add thumbnail: new upload takes priority, otherwise preserve existing
      if (thumbnailId) {
        submitData.thumbnail = thumbnailId;
      } else if (modalMode === 'edit' && selectedArticle?.thumbnail?.id) {
        submitData.thumbnail = selectedArticle.thumbnail.id;
      }

      // Collect all media IDs (both existing and new)
      let allMediaIds = [];

      // When editing, preserve existing media (excluding ones marked for deletion)
      if (modalMode === 'edit' && selectedArticle?.media) {
        const existingMedia = Array.isArray(selectedArticle.media)
          ? selectedArticle.media
          : selectedArticle.media?.data ? selectedArticle.media.data : [];

        allMediaIds = existingMedia
          .map(item => item.id || item)
          .filter(id => id && !videosToDelete.includes(id) && !imagesToDelete.includes(id));
      }

      // Add newly uploaded videos and images
      if (videoIds.length > 0) {
        allMediaIds = [...allMediaIds, ...videoIds];
      }
      if (imageIds.length > 0) {
        allMediaIds = [...allMediaIds, ...imageIds];
      }

      // Set media field with all video IDs (or empty array if all were deleted)
      if (modalMode === 'edit') {
        // Always set media field when editing to allow clearing all videos
        submitData.media = allMediaIds.length > 0 ? allMediaIds : [];
      } else if (allMediaIds.length > 0) {
        // Only set if there are videos when creating
        submitData.media = allMediaIds;
      }

      // Add slug only for create (UID fields can't be updated)
      if (modalMode === 'create') {
        submitData.slug = formData.slug;
      }

      // Add category if selected, or explicitly set to null to clear it
      if (formData.category) {
        submitData.category = parseInt(formData.category);
      } else {
        submitData.category = null;
      }

      if (modalMode === 'create') {
        // Add author email for new articles
        submitData.authorEmail = user?.email || 'Unknown';
        submitData.lastUpdatedByEmail = user?.email || 'Unknown';
        await createArticle(submitData, token);
        setSuccessMessage('Article created successfully!');
      } else {
        // Add updater email for edited articles
        submitData.lastUpdatedByEmail = user?.email || 'Unknown';
        await updateArticle(selectedArticle.documentId, submitData, token);
        setSuccessMessage('Article updated successfully!');
      }

      await fetchArticles();
      closeModal();
    } catch (err) {
      console.error('Failed to save article:', err);
      setError(err.response?.data?.error?.message || 'Failed to save article');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (article) => {
    if (!window.confirm(`Are you sure you want to delete "${article.title}"?`)) {
      return;
    }

    try {
      setSuccessMessage('');
      setError(null);
      await deleteArticle(article.documentId, token);
      setSuccessMessage('Article deleted successfully!');
      await fetchArticles();
    } catch (err) {
      console.error('Failed to delete article:', err);
      setError(err.response?.data?.error?.message || 'Failed to delete article');
    }
  };

  const getFilteredAndSortedArticles = () => {
    let filtered = [...articles];

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(a =>
        a.title.toLowerCase().includes(query) ||
        a.description?.toLowerCase().includes(query) ||
        a.tags?.toLowerCase().includes(query)
      );
    }

    if (filterCategory) {
      filtered = filtered.filter(a => a.category?.id === parseInt(filterCategory));
    }

    if (filterTag) {
      const tagQuery = filterTag.toLowerCase();
      filtered = filtered.filter(a => {
        if (!a.tags) return false;
        const articleTags = a.tags.split(',').map(t => t.trim().toLowerCase());
        return articleTags.some(tag => tag.includes(tagQuery));
      });
    }

    switch (sortBy) {
      case 'recent':
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'oldest':
        filtered.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        break;
      case 'title':
        filtered.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'category':
        filtered.sort((a, b) => {
          const catA = a.category?.name || '';
          const catB = b.category?.name || '';
          return catA.localeCompare(catB);
        });
        break;
      default:
        break;
    }

    return filtered;
  };

  const filteredArticles = getFilteredAndSortedArticles();

  if (loading) {
    return (
      <>
        <AdminNav />
        <div className="admin-container">
          <div className="admin-loading">Loading articles...</div>
        </div>
      </>
    );
  }

  return (
    <>
      {isWriterPath ? <WriterNav /> : <AdminNav />}
      <div className="admin-container">
        <div className="admin-header">
          <div>
            <h1>Article Management</h1>
            <p>Create, edit, and manage articles</p>
          </div>
          <button className="create-btn" onClick={openCreateModal}>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            Create Article
          </button>
        </div>

        {error && <div className="admin-error">{error}</div>}
        {successMessage && <div className="admin-success">{successMessage}</div>}

        {/* Filters and Search */}
        <div className="filters-section">
          <input
            type="text"
            className="search-input"
            placeholder="Search articles..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

          <select
            value={filterCategory}
            onChange={handleCategoryFilterChange}
            className="filter-select"
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          <select
            value={filterTag}
            onChange={(e) => setFilterTag(e.target.value)}
            className="filter-select"
            disabled={!filterCategory}
          >
            <option value="">
              {filterCategory ? 'All Tags' : 'All Tags (Select category first)'}
            </option>
            {tags
              .filter(tag => !filterCategory || tag.category?.id === parseInt(filterCategory))
              .map(tag => (
                <option key={tag.id} value={tag.id}>
                  {tag.name}
                </option>
              ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="filter-select"
          >
            <option value="recent">Most Recent</option>
            <option value="oldest">Oldest First</option>
            <option value="title">Title A-Z</option>
            <option value="category">Category</option>
          </select>
        </div>

        <div className="results-count">
          Showing {filteredArticles.length} of {articles.length} articles
        </div>

        <div className="articles-grid">
          {filteredArticles.length === 0 ? (
            <div className="no-articles">
              {searchQuery || filterCategory || filterTag
                ? 'No articles match your filters'
                : 'No articles found. Create your first article!'}
            </div>
          ) : (
            filteredArticles.map((article) => (
              <div key={article.id} className="article-card">
                {article.thumbnail?.url && (
                  <div className="article-image">
                    <img
                      src={`http://localhost:1337${article.thumbnail.url}`}
                      alt={article.title}
                    />
                  </div>
                )}
                <div className="article-content">
                  <h3>{article.title}</h3>
                  <p className="article-excerpt">{article.description}</p>
                  <div className="article-meta">
                    {article.category && (
                      <span className="category-badge">
                        {typeof article.category === 'object' ? article.category.name : 'Category'}
                      </span>
                    )}
                  </div>
                  <div className="article-actions">
                    <button className="edit-btn" onClick={() => openEditModal(article)}>
                      Edit
                    </button>
                    {canDelete && (
                      <button className="delete-btn" onClick={() => handleDelete(article)}>
                        Delete
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Create/Edit Modal */}
        {modalOpen && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content large-modal" onClick={(e) => e.stopPropagation()}>
              <h2>{modalMode === 'create' ? 'Create New Article' : 'Edit Article'}</h2>

              <form onSubmit={handleSubmit}>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="title">Title *</label>
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      placeholder="Enter article title"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="slug">Slug *</label>
                    <input
                      type="text"
                      id="slug"
                      name="slug"
                      value={formData.slug}
                      onChange={handleInputChange}
                      placeholder="article-url-slug"
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="description">Description</label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Brief description of the article"
                    rows="2"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="thumbnail">
                    Thumbnail Image
                    <small> (optional - displayed on article cards)</small>
                  </label>
                  <input
                    type="file"
                    id="thumbnail"
                    accept="image/*"
                    onChange={handleThumbnailChange}
                  />
                  {thumbnailPreview && (
                    <div style={{ marginTop: '1rem' }}>
                      <img
                        src={thumbnailPreview}
                        alt="Thumbnail preview"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          borderRadius: '8px',
                          objectFit: 'cover'
                        }}
                      />
                    </div>
                  )}
                  {!thumbnailPreview && selectedArticle?.thumbnail?.url && (
                    <div style={{ marginTop: '1rem' }}>
                      <img
                        src={`http://localhost:1337${selectedArticle.thumbnail.url}`}
                        alt="Current thumbnail"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          borderRadius: '8px',
                          objectFit: 'cover'
                        }}
                      />
                      <small style={{ display: 'block', marginTop: '0.5rem', color: '#6b7280' }}>
                        Current thumbnail (upload a new file to replace)
                      </small>
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="videos">
                    Videos
                    <small> (optional - embed videos in article)</small>
                  </label>
                  <input
                    type="file"
                    id="videos"
                    accept="video/*"
                    multiple
                    onChange={handleVideoChange}
                  />
                  {videoFiles.length > 0 && (
                    <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', color: '#6b7280' }}>
                      <small style={{ display: 'block', marginBottom: '0.25rem' }}>New videos to upload:</small>
                      {videoFiles.map((f, idx) => (
                        <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                          <span>{f.name}</span>
                          <button type="button" onClick={() => handleRemoveNewVideo(idx)} style={{ padding: '0.1rem 0.5rem', fontSize: '0.75rem', backgroundColor: '#dc2626', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Remove</button>
                        </div>
                      ))}
                    </div>
                  )}
                  {modalMode === 'edit' && selectedArticle?.media && (() => {
                    const mediaItems = Array.isArray(selectedArticle.media)
                      ? selectedArticle.media
                      : selectedArticle.media?.data ? selectedArticle.media.data : [];
                    const videos = mediaItems.filter(item => {
                      const mimeType = item.mime || item.attributes?.mime || '';
                      return mimeType.startsWith('video/');
                    });

                    return videos.length > 0 && (
                      <div style={{ marginTop: '1rem' }}>
                        <small style={{ display: 'block', marginBottom: '0.5rem', color: '#6b7280' }}>
                          Current videos in article:
                        </small>
                        {videos.map((video, idx) => {
                          const videoData = video.attributes || video;
                          const videoId = video.id || videoData.id;
                          const videoUrl = videoData.url?.startsWith('http')
                            ? videoData.url
                            : `http://localhost:1337${videoData.url}`;
                          const isMarkedForDeletion = videosToDelete.includes(videoId);

                          return (
                            <div key={idx} style={{
                              marginBottom: '1rem',
                              padding: '0.75rem',
                              border: '1px solid #e5e7eb',
                              borderRadius: '8px',
                              position: 'relative',
                              opacity: isMarkedForDeletion ? 0.5 : 1,
                              backgroundColor: isMarkedForDeletion ? '#fee2e2' : 'transparent'
                            }}>
                              <video
                                src={videoUrl}
                                style={{
                                  maxWidth: '300px',
                                  maxHeight: '200px',
                                  borderRadius: '8px',
                                  display: 'block',
                                  marginBottom: '0.5rem'
                                }}
                                controls
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <small style={{ color: '#6b7280', flex: 1 }}>
                                  {videoData.name}
                                  {isMarkedForDeletion && <span style={{ color: '#dc2626', marginLeft: '0.5rem' }}>(Will be deleted)</span>}
                                </small>
                                {!isMarkedForDeletion ? (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveVideo(videoId)}
                                    style={{
                                      padding: '0.25rem 0.75rem',
                                      fontSize: '0.875rem',
                                      backgroundColor: '#dc2626',
                                      color: 'white',
                                      border: 'none',
                                      borderRadius: '4px',
                                      cursor: 'pointer'
                                    }}
                                  >
                                    Delete
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => handleUndoRemoveVideo(videoId)}
                                    style={{
                                      padding: '0.25rem 0.75rem',
                                      fontSize: '0.875rem',
                                      backgroundColor: '#059669',
                                      color: 'white',
                                      border: 'none',
                                      borderRadius: '4px',
                                      cursor: 'pointer'
                                    }}
                                  >
                                    Undo
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                        <small style={{ display: 'block', marginTop: '0.5rem', color: '#6b7280' }}>
                          (upload new videos to add more)
                        </small>
                      </div>
                    );
                  })()}
                </div>

                <div className="form-group">
                  <label htmlFor="images">
                    Images
                    <small> (optional - embed images in article)</small>
                  </label>
                  <input
                    type="file"
                    id="images"
                    accept="image/*"
                    multiple
                    onChange={handleImageChange}
                  />
                  {imageFiles.length > 0 && (
                    <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', color: '#6b7280' }}>
                      <small style={{ display: 'block', marginBottom: '0.25rem' }}>New images to upload:</small>
                      {imageFiles.map((f, idx) => (
                        <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.25rem' }}>
                          <span>{f.name}</span>
                          <button type="button" onClick={() => handleRemoveNewImage(idx)} style={{ padding: '0.1rem 0.5rem', fontSize: '0.75rem', backgroundColor: '#dc2626', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>Remove</button>
                        </div>
                      ))}
                    </div>
                  )}
                  {modalMode === 'edit' && selectedArticle?.media && (() => {
                    const mediaItems = Array.isArray(selectedArticle.media)
                      ? selectedArticle.media
                      : selectedArticle.media?.data ? selectedArticle.media.data : [];
                    const images = mediaItems.filter(item => {
                      const mimeType = item.mime || item.attributes?.mime || '';
                      return mimeType.startsWith('image/');
                    });

                    return images.length > 0 && (
                      <div style={{ marginTop: '1rem' }}>
                        <small style={{ display: 'block', marginBottom: '0.5rem', color: '#6b7280' }}>
                          Current images in article:
                        </small>
                        {images.map((image, idx) => {
                          const imageData = image.attributes || image;
                          const imageId = image.id || imageData.id;
                          const imageUrl = imageData.url?.startsWith('http')
                            ? imageData.url
                            : `http://localhost:1337${imageData.url}`;
                          const isMarkedForDeletion = imagesToDelete.includes(imageId);

                          return (
                            <div key={idx} style={{
                              marginBottom: '1rem',
                              padding: '0.75rem',
                              border: '1px solid #e5e7eb',
                              borderRadius: '8px',
                              position: 'relative',
                              opacity: isMarkedForDeletion ? 0.5 : 1,
                              backgroundColor: isMarkedForDeletion ? '#fee2e2' : 'transparent'
                            }}>
                              <img
                                src={imageUrl}
                                alt={imageData.name || 'Article image'}
                                style={{
                                  maxWidth: '300px',
                                  maxHeight: '200px',
                                  borderRadius: '8px',
                                  display: 'block',
                                  marginBottom: '0.5rem',
                                  objectFit: 'cover'
                                }}
                              />
                              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <small style={{ color: '#6b7280', flex: 1 }}>
                                  {imageData.name}
                                  {isMarkedForDeletion && <span style={{ color: '#dc2626', marginLeft: '0.5rem' }}>(Will be deleted)</span>}
                                </small>
                                {!isMarkedForDeletion ? (
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveImage(imageId)}
                                    style={{
                                      padding: '0.25rem 0.75rem',
                                      fontSize: '0.875rem',
                                      backgroundColor: '#dc2626',
                                      color: 'white',
                                      border: 'none',
                                      borderRadius: '4px',
                                      cursor: 'pointer'
                                    }}
                                  >
                                    Delete
                                  </button>
                                ) : (
                                  <button
                                    type="button"
                                    onClick={() => handleUndoRemoveImage(imageId)}
                                    style={{
                                      padding: '0.25rem 0.75rem',
                                      fontSize: '0.875rem',
                                      backgroundColor: '#059669',
                                      color: 'white',
                                      border: 'none',
                                      borderRadius: '4px',
                                      cursor: 'pointer'
                                    }}
                                  >
                                    Undo
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                        <small style={{ display: 'block', marginTop: '0.5rem', color: '#6b7280' }}>
                          (upload new images to add more)
                        </small>
                      </div>
                    );
                  })()}
                </div>

                <div className="form-group">
                  <label htmlFor="body">Body Content *</label>
                  <textarea
                    id="body"
                    name="body"
                    value={formData.body}
                    onChange={handleInputChange}
                    placeholder="Article content"
                    rows="10"
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="category">Category</label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category || ''}
                    onChange={handleInputChange}
                  >
                    <option value="">Select a category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>
                    Tags
                    <small> (optional - select tags from the chosen category)</small>
                    <button
                      type="button"
                      onClick={() => setShowNewTagInput(!showNewTagInput)}
                      style={{
                        marginLeft: '1rem',
                        padding: '0.25rem 0.75rem',
                        background: showNewTagInput ? '#6b7280' : '#10b981',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        fontSize: '0.85rem',
                        cursor: 'pointer'
                      }}
                    >
                      {showNewTagInput ? 'Cancel' : '+ New Tag'}
                    </button>
                  </label>

                  {showNewTagInput && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', padding: '1rem', background: '#f0f9ff', border: '2px solid #3b82f6', borderRadius: '8px', marginBottom: '1rem' }}>
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>New Tag Name:</label>
                      <input
                        type="text"
                        placeholder="Enter new tag name"
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        style={{ padding: '0.75rem', border: '1px solid #3b82f6', borderRadius: '6px', fontSize: '1rem' }}
                      />
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>
                        Category: {categories.find(c => c.id === parseInt(formData.category))?.name}
                      </label>
                      <small style={{ color: '#6b7280', fontSize: '0.875rem' }}>Tag will be created under the currently selected category</small>
                      <button type="button" onClick={handleCreateNewTag} style={{ padding: '0.75rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '6px', fontSize: '1rem', fontWeight: 'bold', cursor: 'pointer' }}>
                        Create Tag
                      </button>
                    </div>
                  )}

                  <div className="tags-checkbox-list">
                    {formData.category ? (
                      (() => {
                        const categoryTags = tags.filter(tag => tag.category?.id === parseInt(formData.category));
                        return categoryTags.length > 0 ? (
                          categoryTags.map(tag => (
                            <label key={tag.id} className="tag-checkbox-item">
                              <input
                                type="checkbox"
                                checked={formData.tags.includes(String(tag.id))}
                                onChange={() => handleTagCheckboxChange(tag.id)}
                              />
                              <span>{tag.name}</span>
                            </label>
                          ))
                        ) : (
                          <p style={{ color: '#6b7280', fontSize: '0.9rem', padding: '0.5rem' }}>
                            No tags available for this category. Create a new tag above.
                          </p>
                        );
                      })()
                    ) : (
                      <p style={{ color: '#6b7280', fontSize: '0.9rem', padding: '0.5rem' }}>
                        Please select a category first to see available tags.
                      </p>
                    )}
                  </div>
                </div>

                {error && <div className="modal-error">{error}</div>}

                <div className="modal-actions">
                  <button type="button" className="cancel-btn" onClick={closeModal}>
                    Cancel
                  </button>
                  <button type="submit" className="submit-btn" disabled={submitting}>
                    {submitting ? 'Saving...' : (modalMode === 'create' ? 'Create Article' : 'Update Article')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default ManageArticles;
