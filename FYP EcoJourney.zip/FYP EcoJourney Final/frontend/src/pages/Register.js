/**
 * Register Page Component
 *
 * Provides the user registration form for EcoJourney.
 * New users create an account to track their quiz progress.
 *
 * Features:
 * ---------
 * 1. Username, email, password, and confirm password fields
 * 2. Client-side validation:
 *    - All fields required
 *    - Password minimum 6 characters
 *    - Password confirmation match
 * 3. Error message display
 * 4. Loading state during registration
 * 5. Link to login page for existing users
 *
 * Registration Flow:
 * ------------------
 * 1. User fills in registration form
 * 2. Client-side validation runs
 * 3. Form submits to AuthContext's register function
 * 4. AuthContext calls Strapi /auth/local/register endpoint
 * 5. On success: New user created, JWT stored, redirect to /articles
 * 6. On failure: Error message displayed (e.g., email already exists)
 *
 * Note: New users get "Authenticated" role by default.
 * Admin/Writer roles must be assigned manually in Strapi admin.
 */

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { trackSignUp } from '../analytics';
import './Auth.css';

function Register() {
  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [username, setUsername] = useState('');         // Username input
  const [email, setEmail] = useState('');               // Email input
  const [password, setPassword] = useState('');         // Password input
  const [confirmPassword, setConfirmPassword] = useState(''); // Password confirmation
  const [error, setError] = useState('');               // Error message
  const [loading, setLoading] = useState(false);        // Loading state

  // Get register function from AuthContext
  const { register } = useAuth();
  const navigate = useNavigate();

  // =========================================================================
  // FORM SUBMISSION HANDLER
  // =========================================================================

  /**
   * Handle Form Submit
   *
   * Performs client-side validation before calling AuthContext register.
   * Validates: required fields, password length, password match.
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // VALIDATION 1: All fields required
    if (!username || !email || !password || !confirmPassword) {
      setError('Please fill in all fields');
      setLoading(false);
      return;
    }

    // VALIDATION 2: Password minimum length
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      setLoading(false);
      return;
    }

    // VALIDATION 3: Passwords must match
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    // Call AuthContext register function
    const result = await register(username, email, password);

    if (result.success) {
      // Registration successful - user is auto-logged in, redirect to articles
      trackSignUp();
      navigate('/articles');
    } else {
      // Registration failed - show error message
      setError(result.error);
    }

    setLoading(false);
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <h1>Join EcoJourney</h1>
          <p>Create an account to start learning</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Choose a username"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Create a password (min 6 characters)"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm Password</label>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm your password"
              required
            />
          </div>

          <button 
            type="submit" 
            className="btn btn-primary btn-block"
            disabled={loading}
          >
            {loading ? 'Creating account...' : 'Sign Up'}
          </button>
        </form>

        <div className="auth-footer">
          <p>
            Already have an account?{' '}
            <Link to="/login">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Register;