/**
 * Profile Page Component
 *
 * Displays the user's quiz progress and statistics.
 * Features:
 * - Stats overview (quizzes completed, average score, total points, completion rate)
 * - List of completed quizzes with scores and retake options
 * - Reset progress functionality
 *
 * Data Source:
 * ------------
 * Fetches quiz results from the Strapi backend via /quiz-results/my-results endpoint.
 * Falls back to localStorage if backend fetch fails.
 *
 * Why Backend Over localStorage?
 * ------------------------------
 * - Backend data includes accurate points (with difficulty multipliers)
 * - Backend is the authoritative source for leaderboard
 * - Syncs across devices if user logs in elsewhere
 */

import React, { useState, useEffect } from 'react';
import { getUserStats, getCompletedQuizzes, resetProgress } from '../utils/storage';
import { getQuizzes, resetUserProgress } from '../services/api';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Profile.css';

// Strapi API base URL
const API_URL = 'http://localhost:1337/api';

function Profile() {
  // Get current user from AuthContext (provides user object and auth state)
  const { user } = useAuth();

  // Component state
  const [stats, setStats] = useState(null);           // User statistics object
  const [allQuizzes, setAllQuizzes] = useState([]);   // All available quizzes (for title lookup)
  const [loading, setLoading] = useState(true);       // Loading state for skeleton/spinner
  const [resetting, setResetting] = useState(false);  // Reset button disabled state

  // Load data when component mounts
  useEffect(() => {
    loadData();
  }, []);

  /**
   * Load Profile Data
   *
   * Fetches quiz results from backend and calculates statistics.
   * Also fetches all quizzes to display titles for completed quizzes.
   *
   * Data Flow:
   * 1. Fetch user's quiz results from /quiz-results/my-results
   * 2. Calculate totals (points, score, quizzes taken)
   * 3. Fetch all quizzes for title/slug lookup
   * 4. Set state with combined data
   */
  const loadData = async () => {
    try {
      // Initialize counters for statistics calculation
      let totalPoints = 0;      // Sum of all points (with difficulty multiplier)
      let quizzesTaken = 0;     // Number of quizzes completed
      let totalScore = 0;       // Sum of raw scores (correct answers)
      let totalPossible = 0;    // Sum of total questions (for average calculation)
      let backendQuizResults = [];  // Array to store backend results

      // Only fetch from backend if user is logged in
      if (user) {
        try {
          // Get JWT token for API authentication
          const token = localStorage.getItem('token');

          // Fetch user's quiz results from custom endpoint
          // This endpoint returns only results for the authenticated user
          const response = await fetch(`${API_URL}/quiz-results/my-results`, {
            headers: {
              'Authorization': `Bearer ${token}`  // JWT authentication
            }
          });

          if (response.ok) {
            const data = await response.json();

            // Check if we got valid data with results
            if (data && data.data && data.data.length > 0) {
              backendQuizResults = data.data;

              // Loop through each result and calculate totals
              data.data.forEach((result) => {
                // Points include difficulty multiplier (from backend)
                // Fallback to score if points not set
                totalPoints += result.points || result.score || 0;
                totalScore += result.score || 0;
                totalPossible += result.totalQuestions || 0;
                quizzesTaken++;
              });
            }
          }
        } catch (err) {
          console.error('Error fetching quiz results from backend:', err);

          // ---------------------------------------------------------------
          // FALLBACK: Use localStorage data if backend fails
          // ---------------------------------------------------------------
          // This ensures the page still works even if the server is down
          const localStats = getUserStats();
          totalPoints = localStats.totalPoints;
          quizzesTaken = localStats.totalQuizzes;
          totalScore = localStats.totalPoints;
          totalPossible = localStats.completedQuizzes.reduce((sum, q) => sum + q.totalQuestions, 0);
        }
      }

      // Calculate average score as percentage
      // Guard against division by zero
      const averageScore = totalPossible > 0 ? Math.round((totalScore / totalPossible) * 100) : 0;

      // ---------------------------------------------------------------
      // Merge backend results with localStorage fallback
      // ---------------------------------------------------------------
      // If we have backend results, transform them into the display format
      // Otherwise, fall back to localStorage data
      const completedQuizzes = backendQuizResults.length > 0
        ? backendQuizResults.map(result => ({
            // Handle both Strapi v4 (uses 'id') and v5 (uses 'documentId') formats
            // This ensures compatibility across Strapi versions
            quizId: result.quiz?.id || result.quiz?.documentId || null,
            quizTitle: result.quiz?.title || null,    // Quiz title for display
            quizSlug: result.quiz?.slug || null,      // Quiz slug for retake link
            score: result.score,                       // Raw score (correct answers)
            totalQuestions: result.totalQuestions,     // Total questions in quiz
            percentage: result.percentage,             // Score as percentage
            completedAt: result.completedAt,           // Completion timestamp
            points: result.points,                     // Points (with difficulty multiplier)
            maxPoints: result.maxPoints,               // Max possible points
            difficulty: result.difficulty              // Difficulty level
          }))
        : getCompletedQuizzes();  // Fallback to localStorage

      // Set the stats state with calculated values
      setStats({
        totalQuizzes: quizzesTaken,
        averageScore: averageScore,
        totalPoints: totalPoints,
        completedQuizzes: completedQuizzes
      });

      // Fetch all quizzes for title lookup (for localStorage fallback)
      // This is needed because localStorage only stores quizId, not title
      const quizzesRes = await getQuizzes();
      setAllQuizzes(quizzesRes.data.data || []);

    } catch (error) {
      console.error('Error loading profile data:', error);
    } finally {
      // Always set loading to false when done (success or error)
      setLoading(false);
    }
  };

  /**
   * Handle Reset Progress
   *
   * Clears all quiz history from both backend and localStorage.
   * Shows confirmation dialog first to prevent accidental resets.
   *
   * Steps:
   * 1. Show confirmation dialog
   * 2. Reset backend data (via API)
   * 3. Reset localStorage data
   * 4. Reload data to update UI
   */
  const handleReset = async () => {
    // Show confirmation dialog - this is a destructive action!
    if (window.confirm('Are you sure you want to reset all progress? This will delete all your quiz results and points from the leaderboard. This cannot be undone.')) {
      setResetting(true);  // Disable button while processing

      try {
        // Reset progress in backend (deletes all quiz results for this user)
        await resetUserProgress();

        // Also reset localStorage (for offline/fallback data)
        resetProgress();

        // Reload data to reflect changes in UI
        await loadData();

        alert('Progress reset successfully! Your points have been removed from the leaderboard.');
      } catch (error) {
        console.error('Error resetting progress:', error);
        alert('Failed to reset progress. Please try again.');
      } finally {
        setResetting(false);  // Re-enable button
      }
    }
  };

  // Show loading state while fetching data
  if (loading) {
    return <div className="loading">Loading your progress...</div>;
  }

  // Calculate completion rate (percentage of all quizzes completed)
  // Guard against division by zero if no quizzes exist
  const completionRate = allQuizzes.length > 0
    ? Math.round((stats.totalQuizzes / allQuizzes.length) * 100)
    : 0;

  return (
    <div className="profile">
      <h1>My Progress</h1>

      {/* ================================================================
          STATS OVERVIEW - Four stat cards showing key metrics
          ================================================================ */}
      <div className="stats-overview">
        {/* Card 1: Number of quizzes completed */}
        <div className="stat-card">
          <div className="stat-value">{stats.totalQuizzes}</div>
          <div className="stat-label">Quizzes Completed</div>
        </div>

        {/* Card 2: Average score across all quizzes */}
        <div className="stat-card">
          <div className="stat-value">{stats.averageScore}%</div>
          <div className="stat-label">Average Score</div>
        </div>

        {/* Card 3: Total points (with difficulty multipliers) */}
        <div className="stat-card">
          <div className="stat-value">{stats.totalPoints}</div>
          <div className="stat-label">Total Points</div>
        </div>

        {/* Card 4: Percentage of all available quizzes completed */}
        <div className="stat-card">
          <div className="stat-value">{completionRate}%</div>
          <div className="stat-label">Overall Completion</div>
        </div>
      </div>

      {/* ================================================================
          CONDITIONAL RENDERING: Empty state vs completed quizzes
          ================================================================ */}
      {stats.totalQuizzes === 0 ? (
        // Empty state - no quizzes completed yet
        <div className="empty-state">
          <p>You haven't completed any quizzes yet!</p>
          <Link to="/quizzes" className="btn btn-primary">Start Your First Quiz</Link>
        </div>
      ) : (
        // User has completed quizzes - show history and reset button
        <>
          {/* ==============================================================
              COMPLETED QUIZZES LIST
              Shows each completed quiz with score, date, and retake option
              ============================================================== */}
          <section className="completed-quizzes">
            <h2>Completed Quizzes</h2>
            <div className="quiz-history">
              {stats.completedQuizzes.map((completion, index) => {
                // Try to find quiz in allQuizzes array for title/slug
                // This handles cases where backend didn't return quiz details
                const quiz = allQuizzes.find(q => q.id === completion.quizId || q.documentId === completion.quizId);

                // Use quiz title from allQuizzes, or from completion record, or fallback
                const quizTitle = quiz?.title || completion.quizTitle || 'Quiz';
                // Use quiz slug for retake link
                const quizSlug = quiz?.slug || completion.quizSlug;

                return (
                  <div key={index} className="history-item">
                    {/* Quiz info section */}
                    <div className="history-info">
                      <h3>{quizTitle}</h3>
                      <p className="completion-date">
                        Completed: {new Date(completion.completedAt).toLocaleDateString()}
                      </p>
                      {/* Show difficulty badge if available */}
                      {completion.difficulty && (
                        <span className={`difficulty-badge difficulty-${completion.difficulty}`}>
                          {/* Capitalize first letter of difficulty */}
                          {completion.difficulty.charAt(0).toUpperCase() + completion.difficulty.slice(1)}
                        </span>
                      )}
                    </div>

                    {/* Score display section */}
                    <div className="history-score">
                      {/* Score badge with color based on percentage */}
                      <div className="score-badge" data-score={completion.percentage >= 80 ? 'excellent' : completion.percentage >= 60 ? 'good' : 'fair'}>
                        {completion.score}/{completion.totalQuestions}
                      </div>
                      <div className="percentage">{completion.percentage}%</div>
                      {/* Show points if available (includes difficulty multiplier) */}
                      {completion.points !== undefined && (
                        <div className="points-earned">
                          <strong>{completion.points}</strong> pts
                        </div>
                      )}
                    </div>

                    {/* Actions section - retake button */}
                    <div className="history-actions">
                      {quizSlug && (
                        <Link
                          to={`/quizzes/${quizSlug}`}
                          className="btn btn-small btn-retake"
                        >
                          Retake
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* ==============================================================
              RESET PROGRESS BUTTON
              Deletes all quiz history from backend and localStorage
              ============================================================== */}
          <div className="profile-actions">
            <button
              onClick={handleReset}
              className="btn btn-danger"
              disabled={resetting}  // Disable while processing
            >
              {resetting ? 'Resetting...' : 'Reset All Progress'}
            </button>
          </div>
        </>
      )}
    </div>
  );
}

export default Profile;
