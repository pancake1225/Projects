/**
 * Quizzes Page Component
 *
 * Displays a filterable grid of all available sustainability quizzes.
 * Users can browse, search, and filter quizzes before selecting one to attempt.
 *
 * Features:
 * ---------
 * 1. Hero section with page title and description
 * 2. Login prompt banner for unauthenticated users
 * 3. Sidebar with search and filter options (category, tags)
 * 4. Responsive grid layout for quiz cards
 * 5. Completion badges on quizzes the user has already taken
 *
 * Authentication:
 * ---------------
 * - Quizzes are viewable by everyone
 * - Attempting quizzes requires login (shown via banner)
 * - Completion status is tracked in localStorage
 *
 * Data Source:
 * ------------
 * - Quizzes: /api/quizzes?populate=* (via api service)
 * - Tags: /api/tags?populate=category
 * - Categories: Extracted from quiz data (not fetched separately)
 *
 * Filter Logic:
 * -------------
 * - Category: Exact match on category name
 * - Tags: Match ANY selected tag (OR logic)
 * - Search: Matches title OR description
 */

import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { getQuizzes } from '../services/api';
import { getCompletedQuizzes } from '../utils/storage';
import { useAuth } from '../context/AuthContext';
import './Quizzes.css';

function Quizzes() {
  // Get current user for login status check
  const { user } = useAuth();
  // Get current location for redirect after login
  const location = useLocation();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [quizzes, setQuizzes] = useState([]);           // All quizzes from API
  const [categories, setCategories] = useState([]);     // Unique category names
  const [tags, setTags] = useState([]);                 // All tags with category relations
  const [loading, setLoading] = useState(true);         // Loading state
  const [error, setError] = useState('');               // Error message

  // Filter state
  const [selectedCategory, setSelectedCategory] = useState('ALL');  // Selected category name
  const [selectedTags, setSelectedTags] = useState([]);             // Array of selected tag names
  const [searchQuery, setSearchQuery] = useState('');               // Search text

  // =========================================================================
  // INITIAL DATA FETCH
  // =========================================================================
  useEffect(() => {
    fetchQuizzes();
  }, []);

  /**
   * Fetch Quizzes and Tags
   *
   * Loads all quizzes via the API service and extracts unique categories.
   * Also fetches tags separately for the filter sidebar.
   *
   * Note: Categories are extracted from quiz data rather than fetched
   * separately - this ensures we only show categories that have quizzes.
   */
  const fetchQuizzes = async () => {
    try {
      // Fetch quizzes using the centralized API service
      const response = await getQuizzes();
      const quizData = response.data.data || [];
      setQuizzes(quizData);

      // Extract unique category names from quizzes
      // Using Set to automatically deduplicate
      const uniqueCategories = [...new Set(
        quizData.map(q => q.category?.name).filter(Boolean)
      )];
      setCategories(uniqueCategories);

      // Fetch tags with their category associations
      // populate=category allows filtering tags by category
      const tagsRes = await fetch('http://localhost:1337/api/tags?populate=category');
      const tagsData = await tagsRes.json();
      setTags(tagsData.data || []);
    } catch (err) {
      console.error('Error fetching quizzes:', err);
      setError('Failed to load quizzes');
    } finally {
      setLoading(false);
    }
  };

  // =========================================================================
  // COMPLETION TRACKING
  // Get list of quiz IDs the user has completed (from localStorage)
  // =========================================================================
  const completedQuizIds = getCompletedQuizzes().map(q => q.quizId);

  // =========================================================================
  // CATEGORY-BASED TAG FILTERING
  // Only show tags that belong to the selected category
  // =========================================================================

  // Find category object from a quiz that has this category
  const selectedCategoryObj = quizzes.find(q => q.category?.name === selectedCategory)?.category;
  // Filter tags to only those belonging to selected category
  const filteredTags = selectedCategoryObj
    ? tags.filter(tag => tag.category?.id === selectedCategoryObj.id)
    : [];

  // =========================================================================
  // QUIZ FILTERING LOGIC
  // Combines category, search, and tag filters with AND logic
  // =========================================================================
  const filteredQuizzes = quizzes.filter(quiz => {
    // CATEGORY FILTER: Exact match on category name
    const matchesCategory = selectedCategory === 'ALL' || quiz.category?.name === selectedCategory;

    // SEARCH FILTER: Match title OR description (case-insensitive)
    const matchesSearch = !searchQuery ||
      quiz.title?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      quiz.description?.toLowerCase().includes(searchQuery.toLowerCase());

    // TAG FILTER: Match ANY selected tag (OR logic within tags)
    // Quiz tags are stored as array of tag objects
    const matchesTags = selectedTags.length === 0 || selectedTags.some(selectedTag =>
      quiz.tags?.some(t => t.name === selectedTag)
    );

    // All filters must pass (AND logic)
    return matchesCategory && matchesSearch && matchesTags;
  });

  if (loading) {
    return (
      <div className="quizzes-page">
        <div className="quizzes-loading">Loading quizzes...</div>
      </div>
    );
  }

  if (error || quizzes.length === 0) {
    return (
      <div className="quizzes-page">
        <section className="quizzes-hero">
          <div className="quizzes-hero-content">
            <div className="quizzes-hero-eyebrow">Test Your Knowledge</div>
            <h1 className="quizzes-hero-title">
              Challenge yourself with sustainability quizzes
            </h1>
            <p className="quizzes-hero-text">
              Explore interactive quizzes covering environmental topics, renewable energy, waste management, and more.
            </p>
          </div>
        </section>
        <div className="quizzes-content-section">
          <div className="no-quizzes">
            <p>No quizzes available yet. Check back soon!</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="quizzes-page">
      {/* Hero Section */}
      <section className="quizzes-hero">
        <div className="quizzes-hero-content">
          <div className="quizzes-hero-eyebrow">Test Your Knowledge</div>
          <h1 className="quizzes-hero-title">
            Challenge yourself with sustainability quizzes
          </h1>
          <p className="quizzes-hero-text">
            Explore interactive quizzes covering environmental topics, renewable energy, waste management, and more.
          </p>
        </div>
      </section>

      {/* Login Message for Unauthenticated Users */}
      {!user && (
        <div className="login-required-banner">
          <div className="login-banner-content">
            <svg className="login-banner-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <div className="login-banner-text">
              <strong>Sign in or create an account</strong> to attempt quizzes and track your progress.
            </div>
            <div className="login-banner-buttons">
              <Link to="/login" state={{ from: location }} className="login-banner-button">
                Sign In
              </Link>
              <Link to="/register" state={{ from: location }} className="login-banner-button signup">
                Sign Up
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Content Section */}
      <div className="quizzes-content-section">
        <div className="quizzes-content-header">
          <h2>Available Quizzes</h2>
          <p>Test your sustainability knowledge</p>
        </div>

        <div className="quizzes-layout">
          {/* Sidebar */}
          <aside className="quizzes-sidebar">
            <div className="sidebar-title">Filter quizzes</div>

            <div className="sidebar-section">
              <div className="sidebar-label">Search</div>
              <input
                className="sidebar-search-input"
                placeholder="Search quizzes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>

            {categories.length > 0 && (
              <div className="sidebar-section">
                <div className="sidebar-label">Category</div>
                <div className="filter-pills">
                  <button
                    className={`filter-pill ${selectedCategory === 'ALL' ? 'filter-pill-active' : ''}`}
                    onClick={() => {
                      setSelectedCategory('ALL');
                      setSelectedTags([]);
                    }}
                  >
                    ALL
                  </button>
                  {categories.map((category) => (
                    <button
                      key={category}
                      className={`filter-pill ${selectedCategory === category ? 'filter-pill-active' : ''}`}
                      onClick={() => {
                        setSelectedCategory(category);
                        setSelectedTags([]);
                      }}
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {filteredTags.length > 0 && (
              <div className="sidebar-section">
                <div className="sidebar-label">Tags</div>
                <div className="filter-pills tags-pills">
                  {filteredTags.map((tag) => {
                    const tagName = tag.name;
                    const isSelected = selectedTags.includes(tagName);
                    return (
                      <button
                        key={tag.id}
                        className={`filter-pill tag-pill ${isSelected ? 'tag-pill-active' : ''}`}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedTags(selectedTags.filter(t => t !== tagName));
                          } else {
                            setSelectedTags([...selectedTags, tagName]);
                          }
                        }}
                      >
                        {tagName}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </aside>

          {/* Grid */}
          <div className="quizzes-grid-container">
            {filteredQuizzes.length === 0 ? (
              <div className="no-quizzes">
                <p>No quizzes found matching your criteria.</p>
              </div>
            ) : (
              <div className="quizzes-grid">
                {filteredQuizzes.map((quiz) => {
                  const isCompleted = completedQuizIds.includes(quiz.id);
                  
                  return (
                    <Link
                      key={quiz.id}
                      to={`/quizzes/${quiz.slug}`}
                      className="quiz-card"
                    >
                      {quiz.thumbnail?.url && (
                        <div className="quiz-card-thumbnail">
                          <img
                            src={`http://localhost:1337${quiz.thumbnail.url}`}
                            alt={quiz.title}
                            loading="lazy"
                          />
                        </div>
                      )}

                      {isCompleted && (
                        <div className="quiz-completed-badge">✓ Completed</div>
                      )}

                      {quiz.category?.name && (
                        <div className="quiz-category-badge">
                          {quiz.category.name}
                        </div>
                      )}

                      <h3 className="quiz-card-title">{quiz.title}</h3>

                      {quiz.description && (
                        <p className="quiz-card-description">
                          {quiz.description}
                        </p>
                      )}

                      <div className="quiz-card-footer">
                        <span className="quiz-start-link">
                          {isCompleted ? 'Retake →' : 'Start Quiz →'}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Quizzes;
