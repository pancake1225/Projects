/**
 * Manage Questions Page Component (Question Bank)
 *
 * Admin/Writer dashboard for managing the centralized question bank.
 * Questions are stored independently and linked to quizzes via category/tags.
 *
 * Features:
 * ---------
 * 1. Create multiple-choice questions with 2+ options
 * 2. Specify correct answer with optional explanation
 * 3. Assign category and tags for quiz filtering
 * 4. View question details in preview modal
 * 5. Edit/delete questions (Admin only for delete)
 * 6. Create new tags on-the-fly during question creation
 * 7. Filter questions by category, tag, and search
 *
 * Question Structure:
 * -------------------
 * - questionText: The question itself
 * - options: Array of answer choices (minimum 2)
 * - correctAnswer: Index of correct option (0-based)
 * - explanation: Why the answer is correct (shown after quiz)
 * - category: Single category (required)
 * - tags: Multiple tags (optional, for filtering)
 *
 * Quiz Integration:
 * -----------------
 * Questions are NOT directly attached to quizzes. Instead:
 * 1. Questions have category and optional tags
 * 2. Quizzes have category and optional tags
 * 3. When user starts quiz, matching questions are dynamically fetched
 * 4. This allows reusing questions across multiple quizzes
 *
 * API Endpoints:
 * --------------
 * - GET /question-banks - Fetch all questions
 * - POST /question-banks - Create question
 * - PUT /question-banks/:documentId - Update question
 * - DELETE /question-banks/:documentId - Delete question
 */

import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { usePermissions } from '../context/PermissionsContext';
import { getCategories, getTags } from '../services/api';
import AdminNav from '../components/AdminNav';
import WriterNav from '../components/WriterNav';
import './ManageQuestions.css';

function ManageQuestions() {
  const location = useLocation();
  const { token } = useAuth();
  const { canDelete } = usePermissions();  // Only Admins can delete

  // Determine which navigation to show based on URL path
  const isWriterPath = location.pathname.startsWith('/writer');

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // Question data
  const [questions, setQuestions] = useState([]);      // All questions from API
  const [categories, setCategories] = useState([]);    // Categories for dropdown
  const [tags, setTags] = useState([]);                // Tags for selection

  // UI state
  const [loading, setLoading] = useState(true);        // Loading indicator
  const [error, setError] = useState(null);            // Error message
  const [successMessage, setSuccessMessage] = useState(''); // Success feedback

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);   // Create/Edit modal
  const [viewModalOpen, setViewModalOpen] = useState(false); // View modal
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [selectedQuestion, setSelectedQuestion] = useState(null); // Question being edited/viewed
  const [submitting, setSubmitting] = useState(false); // Form submission state

  // Sorting and filtering
  const [sortBy, setSortBy] = useState('recent');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterTag, setFilterTag] = useState('');
  const [searchQuery, setSearchQuery] = useState('');

  // New tag creation
  const [showNewTagInput, setShowNewTagInput] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagCategory, setNewTagCategory] = useState('');

  const [formData, setFormData] = useState({
    questionText: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    explanation: '',
    category: '',
    tags: [],
  });

  useEffect(() => {
    fetchCategories();
    fetchTags();
    fetchQuestions();
  }, []);

  const handleCategoryFilterChange = (e) => {
    setFilterCategory(e.target.value);
    setFilterTag(''); // Clear tag filter when category changes
  };

  const fetchCategories = async () => {
    try {
      const response = await getCategories();
      setCategories(response.data.data || []);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await fetch('http://localhost:1337/api/tags?populate=category', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      console.log('Fetched tags with category:', data);
      setTags(data.data || []);
    } catch (err) {
      console.error('Failed to fetch tags:', err);
    }
  };

  const fetchQuestions = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:1337/api/question-banks?populate=*', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      console.log('Fetched questions:', data);
      setQuestions(data.data || []);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch questions:', err);
      setError('Failed to load questions. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const openCreateModal = () => {
    setModalMode('create');
    setSelectedQuestion(null);
    setFormData({
      questionText: '',
      options: ['', '', '', ''],
      correctAnswer: 0,
      explanation: '',
      category: '',
      tags: [],
    });
    setModalOpen(true);
  };

  const openEditModal = (question) => {
    setModalMode('edit');
    setSelectedQuestion(question);

    const tagIds = question.tags?.map(t => String(t.id)) || [];

    setFormData({
      questionText: question.questionText || '',
      options: question.options || ['', '', '', ''],
      correctAnswer: question.correctAnswer || 0,
      explanation: question.explanation || '',
      category: question.category?.id || '',
      tags: tagIds,
    });
    setModalOpen(true);
  };

  const openViewModal = (question) => {
    setSelectedQuestion(question);
    setViewModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setViewModalOpen(false);
    setSelectedQuestion(null);
    setError(null);
    setSuccessMessage('');
    setShowNewTagInput(false);
    setNewTagName('');
    setNewTagCategory('');
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleOptionChange = (index, value) => {
    setFormData(prev => ({
      ...prev,
      options: prev.options.map((opt, i) => i === index ? value : opt)
    }));
  };

  const addOption = () => {
    setFormData(prev => ({
      ...prev,
      options: [...prev.options, '']
    }));
  };

  const removeOption = (index) => {
    if (formData.options.length <= 2) {
      setError('Must have at least 2 options');
      return;
    }
    setFormData(prev => {
      const newOptions = prev.options.filter((_, i) => i !== index);
      const newCorrectAnswer = prev.correctAnswer >= newOptions.length ? 0 : prev.correctAnswer;
      return {
        ...prev,
        options: newOptions,
        correctAnswer: newCorrectAnswer
      };
    });
  };

  const handleTagCheckboxChange = (tagId) => {
    setFormData(prev => {
      const tagIdStr = String(tagId);
      const isSelected = prev.tags.includes(tagIdStr);

      const newTags = isSelected
        ? prev.tags.filter(id => id !== tagIdStr)
        : [...prev.tags, tagIdStr];

      return {
        ...prev,
        tags: newTags
      };
    });
  };

  const handleCreateNewTag = async () => {
    if (!newTagName.trim()) {
      setError('Tag name cannot be empty');
      return;
    }

    // Use the currently selected category from the form if newTagCategory is not set
    const categoryToUse = newTagCategory || formData.category;

    if (!categoryToUse) {
      setError('Please select a category first');
      return;
    }

    try {
      const response = await fetch('http://localhost:1337/api/tags', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          data: {
            name: newTagName,
            category: parseInt(categoryToUse),
            publishedAt: new Date().toISOString(),
          }
        })
      });

      if (!response.ok) throw new Error('Failed to create tag');

      const data = await response.json();
      const newTag = data.data;

      // Refetch tags to get the full data with category relationship
      await fetchTags();

      // Add the new tag to selected tags
      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, String(newTag.id)]
      }));

      setSuccessMessage(`Tag "${newTagName}" created successfully!`);
      setShowNewTagInput(false);
      setNewTagName('');
      setNewTagCategory('');
      setError(null);
    } catch (err) {
      console.error('Failed to create tag:', err);
      setError('Failed to create tag. Please try again.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage('');

    if (!formData.questionText.trim()) {
      setError('Question text is required');
      return;
    }

    if (formData.options.some(opt => !opt.trim())) {
      setError('All options must be filled in');
      return;
    }

    if (!formData.category) {
      setError('Please select a category');
      return;
    }

    try {
      setSubmitting(true);

      const submitData = {
        questionText: formData.questionText,
        options: formData.options,
        correctAnswer: parseInt(formData.correctAnswer),
        explanation: formData.explanation,
        category: parseInt(formData.category),
        tags: formData.tags.map(id => parseInt(id)),
        publishedAt: new Date().toISOString(),
      };

      const url = modalMode === 'create'
        ? 'http://localhost:1337/api/question-banks'
        : `http://localhost:1337/api/question-banks/${selectedQuestion.documentId}`;

      const method = modalMode === 'create' ? 'POST' : 'PUT';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({ data: submitData })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error?.message || 'Failed to save question');
      }

      const message = modalMode === 'create' ? 'Question created successfully!' : 'Question updated successfully!';
      console.log(message);

      // Close modal first
      closeModal();

      // Then reload questions to reflect the new/updated question
      await fetchQuestions();

      setSuccessMessage(message);
    } catch (err) {
      console.error('Failed to save question:', err);
      setError(err.message || 'Failed to save question');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (question) => {
    if (!window.confirm(`Are you sure you want to delete this question?\n\n"${question.questionText}"\n\nThis action cannot be undone.`)) {
      return;
    }

    try {
      const response = await fetch(`http://localhost:1337/api/question-banks/${question.documentId}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      if (!response.ok) throw new Error('Failed to delete question');

      setSuccessMessage('Question deleted successfully!');
      await fetchQuestions();
    } catch (err) {
      console.error('Failed to delete question:', err);
      setError('Failed to delete question. Please try again.');
    }
  };

  const getFilteredAndSortedQuestions = () => {
    let filtered = [...questions];

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(q =>
        q.questionText.toLowerCase().includes(query) ||
        q.explanation?.toLowerCase().includes(query)
      );
    }

    if (filterCategory) {
      filtered = filtered.filter(q => q.category?.id === parseInt(filterCategory));
    }

    if (filterTag) {
      filtered = filtered.filter(q =>
        q.tags?.some(t => t.id === parseInt(filterTag))
      );
    }

    switch (sortBy) {
      case 'recent':
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'oldest':
        filtered.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        break;
      case 'question':
        filtered.sort((a, b) => a.questionText.localeCompare(b.questionText));
        break;
      case 'category':
        filtered.sort((a, b) => {
          const catA = a.category?.name || '';
          const catB = b.category?.name || '';
          return catA.localeCompare(catB);
        });
        break;
      default:
        break;
    }

    return filtered;
  };

  const filteredQuestions = getFilteredAndSortedQuestions();

  if (loading) {
    return (
      <div className="admin-container">
        <div className="admin-loading">Loading questions...</div>
      </div>
    );
  }

  return (
    <>
      {isWriterPath ? <WriterNav /> : <AdminNav />}
      <div className="admin-container">
        <div className="admin-header">
          <div>
            <h1>Question Bank Management</h1>
            <p>Manage all quiz questions in one place</p>
          </div>
          <button className="create-btn" onClick={openCreateModal}>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            Create Question
          </button>
        </div>

        {error && <div className="admin-error">{error}</div>}
        {successMessage && <div className="admin-success">{successMessage}</div>}

        {/* Filters and Search */}
        <div className="filters-section">
          <input
            type="text"
            className="search-input"
            placeholder="Search questions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

          <select
            value={filterCategory}
            onChange={handleCategoryFilterChange}
            className="filter-select"
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          <select
            value={filterTag}
            onChange={(e) => setFilterTag(e.target.value)}
            className="filter-select"
            disabled={!filterCategory}
          >
            <option value="">
              {filterCategory ? 'All Tags' : 'All Tags (Select category first)'}
            </option>
            {tags
              .filter(tag => !filterCategory || tag.category?.id === parseInt(filterCategory))
              .map(tag => (
                <option key={tag.id} value={tag.id}>
                  {tag.name}
                </option>
              ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="filter-select"
          >
            <option value="recent">Most Recent</option>
            <option value="oldest">Oldest First</option>
            <option value="question">Question A-Z</option>
            <option value="category">Category</option>
          </select>
        </div>

        <div className="results-count">
          Showing {filteredQuestions.length} of {questions.length} questions
        </div>

        {/* Questions List - Compact View */}
        <div className="questions-list">
          {filteredQuestions.length === 0 ? (
            <div className="no-questions">
              {searchQuery || filterCategory || filterTag
                ? 'No questions match your filters'
                : 'No questions found. Create your first question!'}
            </div>
          ) : (
            filteredQuestions.map((question) => (
              <div key={question.id} className="question-item-compact" onClick={() => openViewModal(question)}>
                <div className="question-header">
                  <div className="question-meta">
                    {question.category && (
                      <span className="category-badge">
                        {question.category.name}
                      </span>
                    )}
                    {question.tags?.map(tag => (
                      <span key={tag.id} className="tag-badge">
                        {tag.name}
                      </span>
                    ))}
                  </div>
                  <div className="question-actions" onClick={(e) => e.stopPropagation()}>
                    <button className="edit-btn" onClick={() => openEditModal(question)}>
                      Edit
                    </button>
                    {canDelete && (
                      <button className="delete-btn" onClick={() => handleDelete(question)}>
                        Delete
                      </button>
                    )}
                  </div>
                </div>

                <div className="question-text-compact">{question.questionText}</div>
              </div>
            ))
          )}
        </div>

        {/* View Question Modal */}
        {viewModalOpen && selectedQuestion && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content large-modal" onClick={(e) => e.stopPropagation()}>
              <h2>Question Details</h2>

              <div className="view-question-content">
                <div className="view-meta">
                  {selectedQuestion.category && (
                    <span className="category-badge">
                      {selectedQuestion.category.name}
                    </span>
                  )}
                  {selectedQuestion.tags?.map(tag => (
                    <span key={tag.id} className="tag-badge">
                      {tag.name}
                    </span>
                  ))}
                </div>

                <div className="view-question-text">{selectedQuestion.questionText}</div>

                <div className="view-options">
                  <strong>Answer Options:</strong>
                  {selectedQuestion.options?.map((option, index) => (
                    <div
                      key={index}
                      className={`option-item ${index === selectedQuestion.correctAnswer ? 'correct' : ''}`}
                    >
                      <span className="option-label">{String.fromCharCode(65 + index)}.</span>
                      {option}
                      {index === selectedQuestion.correctAnswer && <span className="correct-mark">✓ Correct</span>}
                    </div>
                  ))}
                </div>

                {selectedQuestion.explanation && (
                  <div className="view-explanation">
                    <strong>Explanation:</strong>
                    <p>{selectedQuestion.explanation}</p>
                  </div>
                )}
              </div>

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={closeModal}>
                  Close
                </button>
                <button type="button" className="edit-btn" onClick={() => { closeModal(); openEditModal(selectedQuestion); }}>
                  Edit Question
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Create/Edit Modal */}
        {modalOpen && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content large-modal" onClick={(e) => e.stopPropagation()}>
              <h2>{modalMode === 'create' ? 'Create New Question' : 'Edit Question'}</h2>

              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="questionText">Question Text *</label>
                  <textarea
                    id="questionText"
                    name="questionText"
                    value={formData.questionText}
                    onChange={handleInputChange}
                    placeholder="Enter your question..."
                    rows="3"
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Answer Options *</label>
                  <div className="options-container">
                    {formData.options.map((option, index) => (
                      <div
                        key={index}
                        className={`option-input-group ${formData.correctAnswer === index ? 'is-correct' : ''}`}
                      >
                        <div className="option-main">
                          <span className="option-letter">{String.fromCharCode(65 + index)}</span>
                          <input
                            type="text"
                            value={option}
                            onChange={(e) => handleOptionChange(index, e.target.value)}
                            placeholder={`Option ${String.fromCharCode(65 + index)}`}
                            required
                            className="option-text-input"
                          />
                        </div>
                        <div className="option-controls">
                          <label className={`correct-answer-label ${formData.correctAnswer === index ? 'selected' : ''}`}>
                            <input
                              type="radio"
                              name="correctAnswer"
                              value={index}
                              checked={formData.correctAnswer === index}
                              onChange={() => setFormData(prev => ({ ...prev, correctAnswer: index }))}
                            />
                            <span className="correct-indicator">
                              {formData.correctAnswer === index ? '✓ Correct Answer' : 'Mark as Correct'}
                            </span>
                          </label>
                          {formData.options.length > 2 && (
                            <button
                              type="button"
                              className="remove-option-btn"
                              onClick={() => removeOption(index)}
                            >
                              ✕ Remove
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  <button type="button" className="add-option-btn" onClick={addOption}>
                    + Add Option
                  </button>
                </div>

                <div className="form-group">
                  <label htmlFor="explanation">Explanation (optional)</label>
                  <textarea
                    id="explanation"
                    name="explanation"
                    value={formData.explanation}
                    onChange={handleInputChange}
                    placeholder="Explain why the correct answer is correct..."
                    rows="2"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="category">Category *</label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="" disabled>Select a category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>
                    Tags
                    <small> (optional)</small>
                    <button
                      type="button"
                      onClick={() => {
                        console.log('Toggle new tag input. Current:', showNewTagInput);
                        setShowNewTagInput(!showNewTagInput);
                      }}
                      style={{
                        marginLeft: '1rem',
                        padding: '0.25rem 0.75rem',
                        background: showNewTagInput ? '#6b7280' : '#10b981',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        fontSize: '0.85rem',
                        cursor: 'pointer'
                      }}
                    >
                      {showNewTagInput ? 'Cancel' : '+ New Tag'}
                    </button>
                  </label>
                  {console.log('showNewTagInput value:', showNewTagInput)}

                  {showNewTagInput && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', padding: '1rem', background: '#f0f9ff', border: '2px solid #3b82f6', borderRadius: '8px', marginBottom: '1rem' }}>
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>New Tag Name:</label>
                      <input
                        type="text"
                        placeholder="Enter new tag name"
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        style={{ padding: '0.75rem', border: '1px solid #3b82f6', borderRadius: '6px', fontSize: '1rem' }}
                      />
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>
                        Category: {categories.find(c => c.id === parseInt(formData.category))?.name || 'Please select a category first'}
                      </label>
                      <small style={{ color: '#6b7280', fontSize: '0.875rem' }}>Tag will be created under the currently selected category</small>
                      <button type="button" onClick={handleCreateNewTag} style={{ padding: '0.75rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '6px', fontSize: '1rem', fontWeight: 'bold', cursor: 'pointer' }}>
                        Create Tag
                      </button>
                    </div>
                  )}

                  <div className="tags-checkbox-list">
                    {formData.category ? (
                      (() => {
                        // Handle both Strapi v4 and v5 response formats
                        const filteredTags = tags.filter(tag => {
                          const categoryId = tag.category?.id || tag.category?.documentId;
                          const formCategoryId = parseInt(formData.category);
                          console.log('Tag:', tag.name, 'Category ID:', categoryId, 'Looking for:', formCategoryId);
                          return categoryId === formCategoryId;
                        });
                        console.log('Category selected:', formData.category);
                        console.log('All tags:', tags);
                        console.log('Filtered tags:', filteredTags);
                        console.log('Selected tag IDs:', formData.tags);

                        if (filteredTags.length === 0) {
                          return <div className="no-tags-message">No tags available for this category. Click "+ New Tag" to create one.</div>;
                        }

                        return filteredTags.map((tag) => (
                          <label key={tag.id} className="tag-checkbox-item">
                            <input
                              type="checkbox"
                              value={tag.id}
                              checked={formData.tags.includes(String(tag.id))}
                              onChange={() => handleTagCheckboxChange(tag.id)}
                            />
                            <span>{tag.name}</span>
                          </label>
                        ));
                      })()
                    ) : (
                      <div className="no-tags-message">Please select a category first to see available tags</div>
                    )}
                  </div>
                  {formData.tags.length > 0 && (
                    <small>{formData.tags.length} tag(s) selected</small>
                  )}
                </div>

                {error && <div className="modal-error">{error}</div>}

                <div className="modal-actions">
                  <button type="button" className="cancel-btn" onClick={closeModal}>
                    Cancel
                  </button>
                  <button type="submit" className="submit-btn" disabled={submitting}>
                    {submitting ? 'Saving...' : (modalMode === 'create' ? 'Create Question' : 'Update Question')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default ManageQuestions;
