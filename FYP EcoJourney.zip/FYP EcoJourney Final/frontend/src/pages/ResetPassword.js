/**
 * Reset Password Page Component
 *
 * Allows users to set a new password using the 6-digit PIN from their email.
 * This is Part 2 of the password reset flow (after ForgotPassword).
 *
 * Features:
 * ---------
 * 1. Email field (prefilled from ForgotPassword page via location state)
 * 2. 6-digit PIN input with validation
 * 3. New password and confirmation fields
 * 4. Client-side validation
 * 5. Auto-redirect to login after successful reset
 *
 * Password Reset Flow (Part 2 of 2):
 * ----------------------------------
 * 1. User arrives from ForgotPassword page (email prefilled)
 * 2. User enters 6-digit PIN from email
 * 3. User enters new password (min 6 chars) and confirms
 * 4. Frontend calls /admin-panel/reset-password-with-pin
 * 5. Backend verifies PIN and updates password
 * 6. User redirected to login page
 *
 * Backend Endpoint:
 * -----------------
 * POST /api/admin-panel/reset-password-with-pin
 * Body: { email: string, pin: string, newPassword: string }
 *
 * Validation:
 * -----------
 * - PIN: Exactly 6 digits
 * - Password: Minimum 6 characters
 * - Passwords must match
 */

import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import axios from 'axios';
import './Auth.css';

function ResetPassword() {
  const navigate = useNavigate();
  const location = useLocation();

  // Get email from location state (passed from ForgotPassword page)
  const emailFromState = location.state?.email || '';

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [email, setEmail] = useState(emailFromState);  // Prefilled from ForgotPassword
  const [pin, setPin] = useState('');                  // 6-digit PIN from email
  const [password, setPassword] = useState('');        // New password
  const [confirmPassword, setConfirmPassword] = useState(''); // Password confirmation
  const [error, setError] = useState('');              // Error message
  const [success, setSuccess] = useState('');          // Success message
  const [loading, setLoading] = useState(false);       // Loading state

  // =========================================================================
  // FORM SUBMISSION HANDLER
  // =========================================================================

  /**
   * Handle Form Submit
   *
   * Validates input and calls backend to reset password.
   * On success, redirects to login page after 2 seconds.
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    // VALIDATION 1: All fields required
    if (!email || !pin || !password || !confirmPassword) {
      setError('Please fill in all fields');
      setLoading(false);
      return;
    }

    // VALIDATION 2: PIN must be exactly 6 digits
    if (pin.length !== 6 || !/^\d+$/.test(pin)) {
      setError('PIN must be a 6-digit number');
      setLoading(false);
      return;
    }

    // VALIDATION 3: Password minimum length
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      setLoading(false);
      return;
    }

    // VALIDATION 4: Passwords must match
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    try {
      // Call custom password reset endpoint
      await axios.post('http://localhost:1337/api/admin-panel/reset-password-with-pin', {
        email,
        pin,
        newPassword: password,
      });

      // Show success message and redirect to login
      setSuccess('Password reset successful! Redirecting to login...');

      setTimeout(() => {
        navigate('/login');
      }, 2000);
    } catch (err) {
      console.error('Reset password error:', err);
      setError(err.response?.data?.error?.message || 'Failed to reset password');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <h1>Reset Password</h1>
          <p>Enter the 6-digit PIN from your email and your new password</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {success && (
            <div className="success-message">
              {success}
            </div>
          )}

          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="pin">6-Digit PIN</label>
            <input
              type="text"
              id="pin"
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, '').slice(0, 6))}
              placeholder="Enter 6-digit PIN from email"
              maxLength="6"
              pattern="\d{6}"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">New Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter new password (min 6 characters)"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">Confirm New Password</label>
            <input
              type="password"
              id="confirmPassword"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Confirm new password"
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-block"
            disabled={loading}
          >
            {loading ? 'Resetting...' : 'Reset Password'}
          </button>
        </form>
      </div>
    </div>
  );
}

export default ResetPassword;