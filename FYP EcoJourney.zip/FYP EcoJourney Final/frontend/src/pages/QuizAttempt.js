/**
 * Quiz Attempt Page Component
 *
 * The main quiz-taking interface where users attempt quizzes.
 * Handles the complete quiz flow: difficulty selection -> questions -> results.
 *
 * Features:
 * ---------
 * 1. Difficulty selection screen (easy/medium/hard)
 * 2. Timed questions with visual countdown
 * 3. Auto-advance when time runs out
 * 4. Answer selection with navigation (prev/next)
 * 5. Results screen with answer review
 * 6. Points calculation based on difficulty multiplier
 *
 * Game Mechanics:
 * ---------------
 * Difficulty affects three things:
 * - Points per correct answer: Easy=1x, Medium=2x, Hard=3x
 * - Time per question: Easy=30s, Medium=20s, Hard=15s
 * - Number of questions: Easy=3, Medium=6, Hard=9
 *
 * Scoring Logic:
 * --------------
 * - Only answers submitted BEFORE timeout count as correct
 * - Timed out questions are marked incorrect (no points)
 * - Final score saved to both localStorage AND Strapi backend
 *
 * Question Flow:
 * --------------
 * 1. User selects difficulty
 * 2. Frontend fetches questions from /quiz-questions endpoint
 * 3. Backend returns shuffled questions filtered by difficulty
 * 4. User answers questions with timer running
 * 5. On submit or last timeout, results are calculated and saved
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { getQuizBySlug, getQuizQuestions } from '../services/api';
import { saveQuizCompletion } from '../utils/storage';
import { trackQuizStart, trackQuizComplete } from '../analytics';
import './QuizAttempt.css';

// =========================================================================
// DIFFICULTY CONFIGURATION
// These constants control the game balance for each difficulty level
// =========================================================================

// Point multipliers - higher difficulty = more points per correct answer
const DIFFICULTY_POINTS = {
  easy: 1,     // 1 point per correct answer
  medium: 2,   // 2 points per correct answer
  hard: 3      // 3 points per correct answer
};

// Time limits in seconds - higher difficulty = less time
const DEFAULT_TIME_PER_QUESTION = {
  easy: 30,    // 30 seconds for easy
  medium: 20,  // 20 seconds for medium
  hard: 15     // 15 seconds for hard
};

// Question counts - higher difficulty = more questions
const DEFAULT_QUESTION_COUNT = {
  easy: 3,     // 3 questions for easy
  medium: 6,   // 6 questions for medium
  hard: 9      // 9 questions for hard
};

/**
 * Fisher-Yates Shuffle Algorithm
 * Randomly shuffles an array in-place with O(n) complexity.
 * Used for randomizing question order and answer options.
 *
 * @param {Array} array - The array to shuffle
 * @returns {Array} A new shuffled array (original unchanged)
 */
function shuffleArray(array) {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function QuizAttempt() {
  // Get quiz slug from URL params
  const { slug } = useParams();
  const navigate = useNavigate();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // Quiz data
  const [quiz, setQuiz] = useState(null);                    // Quiz metadata from API
  const [selectedDifficulty, setSelectedDifficulty] = useState(null);  // User's chosen difficulty
  const [randomizedQuestions, setRandomizedQuestions] = useState([]);  // Questions for this attempt

  // Question navigation state
  const [currentQuestion, setCurrentQuestion] = useState(0);  // Index of current question (0-based)
  const [selectedAnswers, setSelectedAnswers] = useState({}); // Map of questionIndex -> answerIndex

  // Results state
  const [showResults, setShowResults] = useState(false);     // Show results screen
  const [score, setScore] = useState(0);                     // Number of correct answers
  const [totalPoints, setTotalPoints] = useState(0);         // Points earned (with multiplier)

  // UI state
  const [loading, setLoading] = useState(true);              // Loading indicator
  const [timeLeft, setTimeLeft] = useState(0);               // Seconds remaining for current question
  const [timedOutQuestions, setTimedOutQuestions] = useState(new Set());  // Questions where time expired
  const [quizStarted, setQuizStarted] = useState(false);     // Has user selected difficulty

  // =========================================================================
  // REFS
  // Used to maintain stable references across re-renders
  // =========================================================================
  const timerRef = useRef(null);                    // Interval ID for countdown timer
  const calculateAndShowResultsRef = useRef(null); // Stable reference to results function

  // =========================================================================
  // CALCULATE AND SHOW RESULTS
  // Stored in ref to avoid dependency issues in useCallback/useEffect
  // =========================================================================

  /**
   * Calculate final score and display results
   *
   * Scoring Rules:
   * - Only questions answered BEFORE timeout count as correct
   * - Each correct answer earns points based on difficulty multiplier
   * - Results are saved to both localStorage and Strapi backend
   */
  calculateAndShowResultsRef.current = async () => {
    // Stop the timer
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    const pointMultiplier = DIFFICULTY_POINTS[selectedDifficulty];
    let correctAnswers = 0;
    let earnedPoints = 0;

    // Calculate score - check each question
    randomizedQuestions.forEach((question, index) => {
      // Answer is correct if:
      // 1. Selected answer matches correct answer index
      // 2. Question was NOT timed out (answered before time expired)
      if (selectedAnswers[index] === question.correctAnswer &&
          !timedOutQuestions.has(index)) {
        correctAnswers++;
        earnedPoints += pointMultiplier;
      }
    });

    // Calculate maximum possible points for percentage display
    const maxPossiblePoints = randomizedQuestions.length * pointMultiplier;

    setScore(correctAnswers);
    setTotalPoints(earnedPoints);
    trackQuizComplete(quiz.title, selectedDifficulty, correctAnswers, randomizedQuestions.length);

    // Save completion to localStorage (for offline tracking) AND
    // Strapi backend (for leaderboard). See storage.js for details.
    // Use documentId for Strapi v5 relations (fallback to id for compatibility)
    await saveQuizCompletion(
      quiz.documentId || quiz.id,
      correctAnswers,
      randomizedQuestions.length,
      earnedPoints,
      maxPossiblePoints,
      selectedDifficulty
    );

    setShowResults(true);
  };

  // =========================================================================
  // TIMEOUT HANDLER
  // Called when question timer reaches zero
  // =========================================================================

  /**
   * Handle Time Up
   *
   * When the timer expires for a question:
   * 1. Mark the question as timed out (won't count even if answered)
   * 2. Auto-advance to next question OR show results if last question
   *
   * useCallback ensures stable reference for timer dependency
   */
  const handleTimeUp = useCallback(() => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    // Mark this question as timed out (any answer given now won't count)
    setTimedOutQuestions(prev => new Set([...prev, currentQuestion]));

    // Auto-advance to next question or finish quiz
    if (currentQuestion < randomizedQuestions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      // Last question - calculate and show results
      calculateAndShowResultsRef.current();
    }
  }, [currentQuestion, randomizedQuestions.length]);

  // =========================================================================
  // FETCH QUIZ METADATA ON MOUNT
  // =========================================================================
  useEffect(() => {
    const fetchQuiz = async () => {
      try {
        // Fetch quiz by slug to get metadata (title, description, etc.)
        const response = await getQuizBySlug(slug);
        if (response.data.data.length > 0) {
          setQuiz(response.data.data[0]);
        }
      } catch (error) {
        console.error('Error fetching quiz:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchQuiz();
  }, [slug]);

  // =========================================================================
  // COUNTDOWN TIMER EFFECT
  // Manages the per-question countdown timer
  // =========================================================================
  useEffect(() => {
    // Only run timer when quiz is in progress
    if (!quizStarted || showResults || !selectedDifficulty) return;

    // Clear any existing timer from previous question
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    // Reset timer to full duration for the selected difficulty
    const timeLimit = DEFAULT_TIME_PER_QUESTION[selectedDifficulty];
    setTimeLeft(timeLimit);

    // Start countdown - decrement every second
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          // Time's up! Handle timeout
          handleTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Cleanup: clear timer when question changes or component unmounts
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [currentQuestion, quizStarted, showResults, selectedDifficulty, handleTimeUp]);

  // =========================================================================
  // START QUIZ - Called when user selects difficulty
  // =========================================================================

  /**
   * Start Quiz
   *
   * Initiates a quiz attempt with the selected difficulty:
   * 1. Sets the difficulty level
   * 2. Fetches questions from backend (filtered and shuffled by difficulty)
   * 3. Initializes quiz state and starts the timer
   *
   * @param {string} difficulty - 'easy', 'medium', or 'hard'
   */
  const startQuiz = async (difficulty) => {
    setSelectedDifficulty(difficulty);
    setLoading(true);

    try {
      // Fetch questions from custom endpoint
      // Backend handles: filtering by difficulty, limiting count, shuffling
      console.log('Fetching questions for quiz ID:', quiz.id, 'difficulty:', difficulty);
      const response = await getQuizQuestions(quiz.id, difficulty);
      console.log('API Response:', response.data);

      const questionsData = response.data.questions || [];

      // Validate we have questions to show
      if (questionsData.length === 0) {
        alert('No questions available for this quiz. Please contact the administrator.');
        setLoading(false);
        return;
      }

      // Initialize quiz state
      setRandomizedQuestions(questionsData);  // Questions already shuffled by backend
      setQuizStarted(true);
      trackQuizStart(quiz.title, difficulty);
      setCurrentQuestion(0);
      setSelectedAnswers({});
      setTimedOutQuestions(new Set());
    } catch (error) {
      console.error('Error fetching quiz questions:', error);
      console.error('Error response:', error.response?.data);

      alert(`Failed to load quiz questions: ${error.response?.data?.error?.message || error.message}`);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  // =========================================================================
  // NAVIGATION HANDLERS
  // =========================================================================

  /**
   * Handle Answer Selection
   * Records the user's selected answer for a question
   */
  const handleAnswerSelect = (questionIndex, answerIndex) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [questionIndex]: answerIndex
    });
  };

  /**
   * Navigate to Next Question
   * Clears timer and advances to next question
   */
  const handleNext = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    if (currentQuestion < randomizedQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  /**
   * Navigate to Previous Question
   * Clears timer and goes back to previous question
   */
  const handlePrevious = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  /**
   * Submit Quiz
   * Called when user clicks Submit on last question
   */
  const handleSubmit = () => {
    calculateAndShowResultsRef.current();
  };

  // =========================================================================
  // HELPER FUNCTIONS
  // =========================================================================

  /**
   * Format Time for Display
   * Converts seconds to MM:SS format
   */
  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  /**
   * Get Timer CSS Class
   * Returns class name based on remaining time percentage:
   * - timer-normal: >50% time remaining (green)
   * - timer-warning: 20-50% remaining (yellow)
   * - timer-critical: <20% remaining (red, pulsing)
   */
  const getTimerClass = () => {
    const timeLimit = DEFAULT_TIME_PER_QUESTION[selectedDifficulty];
    const percentage = (timeLeft / timeLimit) * 100;

    if (percentage <= 20) return 'timer-critical';
    if (percentage <= 50) return 'timer-warning';
    return 'timer-normal';
  };

  if (loading) {
    return <div className="loading">Loading quiz...</div>;
  }

  if (!quiz) {
    return <div className="error">Quiz not found</div>;
  }

  // NOTE: Questions are now fetched dynamically from question bank when difficulty is selected
  // No need to check for embedded questions anymore

  // Difficulty Selection Screen
  if (!quizStarted) {
    return (
      <div className="quiz-attempt">
        <div className="difficulty-selection">
          <h1>{quiz.title}</h1>
          {quiz.description && <p className="quiz-description">{quiz.description}</p>}
          
          <h2>Select Difficulty</h2>
          <p className="difficulty-info">Higher difficulty = More points, Less time, Fewer questions</p>
          
          <div className="difficulty-options">
            <button 
              className="difficulty-btn easy"
              onClick={() => startQuiz('easy')}
            >
              <div className="difficulty-icon">🌱</div>
              <div className="difficulty-name">Easy</div>
              <div className="difficulty-details">
                <span>{DIFFICULTY_POINTS.easy}x Points</span>
                <span>{DEFAULT_TIME_PER_QUESTION.easy}s per question</span>
                <span>{DEFAULT_QUESTION_COUNT.easy} questions</span>
              </div>
            </button>

            <button
              className="difficulty-btn medium"
              onClick={() => startQuiz('medium')}
            >
              <div className="difficulty-icon">🌿</div>
              <div className="difficulty-name">Medium</div>
              <div className="difficulty-details">
                <span>{DIFFICULTY_POINTS.medium}x Points</span>
                <span>{DEFAULT_TIME_PER_QUESTION.medium}s per question</span>
                <span>{DEFAULT_QUESTION_COUNT.medium} questions</span>
              </div>
            </button>

            <button
              className="difficulty-btn hard"
              onClick={() => startQuiz('hard')}
            >
              <div className="difficulty-icon">🌳</div>
              <div className="difficulty-name">Hard</div>
              <div className="difficulty-details">
                <span>{DIFFICULTY_POINTS.hard}x Points</span>
                <span>{DEFAULT_TIME_PER_QUESTION.hard}s per question</span>
                <span>{DEFAULT_QUESTION_COUNT.hard} questions</span>
              </div>
            </button>
          </div>
          
          <Link to="/quizzes" className="btn btn-secondary back-btn">
            ← Back to Quizzes
          </Link>
        </div>
      </div>
    );
  }

  const totalQuestions = randomizedQuestions.length;
  const currentQ = randomizedQuestions[currentQuestion];

  // Results Screen
  if (showResults) {
    const percentage = Math.round((score / totalQuestions) * 100);
    const maxPossiblePoints = totalQuestions * DIFFICULTY_POINTS[selectedDifficulty];
    
    return (
      <div className="quiz-results">
        <h1>Quiz Complete!</h1>
        
        <div className="results-difficulty-badge">
          <span className={`difficulty-badge ${selectedDifficulty}`}>
            {selectedDifficulty.charAt(0).toUpperCase() + selectedDifficulty.slice(1)} Mode
          </span>
        </div>
        
        <div className="results-summary">
          <div className="score-circle">
            <div className="score-value">{percentage}%</div>
            <div className="score-label">{score}/{totalQuestions} Correct</div>
          </div>
          
          <div className="points-display">
            <div className="points-earned">{totalPoints}</div>
            <div className="points-label">Points Earned</div>
            <div className="points-max">out of {maxPossiblePoints} possible</div>
          </div>
        </div>
        
        <div className="results-feedback">
          {percentage >= 80 && <p className="feedback excellent">🎉 Excellent work! You're an eco-champion!</p>}
          {percentage >= 60 && percentage < 80 && <p className="feedback good">👍 Good job! Keep learning!</p>}
          {percentage < 60 && <p className="feedback improve">📚 Keep practicing! Review the materials and try again.</p>}
        </div>

        <div className="answers-review">
          <h2>Review Answers</h2>
          {randomizedQuestions.map((question, index) => {
            const isCorrect = selectedAnswers[index] === question.correctAnswer && 
                             !timedOutQuestions.has(index);
            const wasTimedOut = timedOutQuestions.has(index);
            
            return (
              <div key={index} className={`answer-review ${isCorrect ? 'correct' : 'incorrect'} ${wasTimedOut ? 'timed-out' : ''}`}>
                <h3>
                  Question {index + 1}
                  {wasTimedOut && <span className="timed-out-badge">⏱️ Time's Up</span>}
                </h3>
                <p className="question-text">{question.questionText}</p>
                <p className="your-answer">
                  Your answer: {selectedAnswers[index] !== undefined 
                    ? question.options[selectedAnswers[index]] 
                    : 'Not answered'} 
                  {isCorrect ? ' ✓' : ' ✗'}
                </p>
                {!isCorrect && (
                  <p className="correct-answer">
                    Correct answer: {question.options[question.correctAnswer]}
                  </p>
                )}
                {question.explanation && (
                  <p className="explanation">💡 {question.explanation}</p>
                )}
              </div>
            );
          })}
        </div>

        <div className="results-actions">
          <button onClick={() => navigate('/quizzes')} className="btn btn-primary">
            Back to Quizzes
          </button>
          <button onClick={() => window.location.reload()} className="btn btn-secondary">
            Retake Quiz
          </button>
        </div>
      </div>
    );
  }

  // Quiz Question Screen
  return (
    <div className="quiz-attempt">
      <div className="quiz-header">
        <h1>{quiz.title}</h1>
        <div className="quiz-header-info">
          <span className={`difficulty-badge ${selectedDifficulty}`}>
            {selectedDifficulty.charAt(0).toUpperCase() + selectedDifficulty.slice(1)}
          </span>
          <span className="quiz-progress">
            Question {currentQuestion + 1} of {totalQuestions}
          </span>
        </div>
      </div>

      {/* Timer */}
      <div className={`quiz-timer ${getTimerClass()}`}>
        <div className="timer-icon">⏱️</div>
        <div className="timer-value">{formatTime(timeLeft)}</div>
      </div>



      {/* Timer Progress Bar */}
      <div className="timer-bar">
        <div 
          className={`timer-fill ${getTimerClass()}`}
          style={{ 
            width: `${(timeLeft / DEFAULT_TIME_PER_QUESTION[selectedDifficulty]) * 100}%` 
          }}
        />
      </div>

      <div className="question-container">
        <div className="question-points">
          +{DIFFICULTY_POINTS[selectedDifficulty]} {DIFFICULTY_POINTS[selectedDifficulty] === 1 ? 'point' : 'points'} for correct answer
        </div>
        
        <h2>{currentQ.questionText}</h2>
        
        <div className="options">
          {currentQ.options && currentQ.options.map((option, index) => (
            <label key={index} className="option">
              <input
                type="radio"
                name={`question-${currentQuestion}`}
                checked={selectedAnswers[currentQuestion] === index}
                onChange={() => handleAnswerSelect(currentQuestion, index)}
              />
              <span className="option-text">{option}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="quiz-navigation">
        <button 
          onClick={handlePrevious} 
          disabled={currentQuestion === 0}
          className="btn btn-secondary"
        >
          Previous
        </button>
        
        {currentQuestion === totalQuestions - 1 ? (
          <button 
            onClick={handleSubmit}
            disabled={selectedAnswers[currentQuestion] === undefined}
            className="btn btn-primary"
          >
            Submit Quiz
          </button>
        ) : (
          <button 
            onClick={handleNext}
            disabled={selectedAnswers[currentQuestion] === undefined}
            className="btn btn-primary"
          >
            Next
          </button>
        )}
      </div>
    </div>
  );
}

export default QuizAttempt;
