import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

function Writer() {
  const navigate = useNavigate();

  useEffect(() => {
    // Redirect to Article Management by default
    navigate('/writer/articles', { replace: true });
  }, [navigate]);

  return null;
}

export default Writer;
