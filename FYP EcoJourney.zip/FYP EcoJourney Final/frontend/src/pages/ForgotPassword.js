/**
 * Forgot Password Page Component
 *
 * Allows users to request a password reset PIN.
 * Uses a custom backend endpoint that sends a 6-digit PIN via email.
 *
 * Features:
 * ---------
 * 1. Email input for account identification
 * 2. Sends 6-digit PIN to user's email
 * 3. Auto-redirect to reset password page after success
 * 4. Error handling for invalid emails
 *
 * Password Reset Flow (Part 1 of 2):
 * ----------------------------------
 * 1. User enters their email address
 * 2. Frontend calls /admin-panel/request-password-reset
 * 3. Backend generates 6-digit PIN and sends email
 * 4. PIN is stored in database with expiration
 * 5. User is redirected to /reset-password with email prefilled
 *
 * Backend Endpoint:
 * -----------------
 * POST /api/admin-panel/request-password-reset
 * Body: { email: string }
 *
 * Note: This uses a custom endpoint instead of Strapi's default
 * password reset which uses URL tokens. PIN-based reset is simpler
 * for users to type from their email.
 */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import './Auth.css';

function ForgotPassword() {
  const navigate = useNavigate();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [email, setEmail] = useState('');       // Email input value
  const [message, setMessage] = useState('');   // Success message
  const [error, setError] = useState('');       // Error message
  const [loading, setLoading] = useState(false); // Loading state

  // =========================================================================
  // FORM SUBMISSION HANDLER
  // =========================================================================

  /**
   * Handle Form Submit
   *
   * Sends password reset PIN request to backend.
   * On success, redirects to reset-password page after 2 seconds.
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    // Validate email is provided
    if (!email) {
      setError('Please enter your email');
      setLoading(false);
      return;
    }

    try {
      // Call custom password reset endpoint
      await axios.post('http://localhost:1337/api/admin-panel/request-password-reset', {
        email,
      });

      // Show success message
      setMessage('A 6-digit PIN has been sent to your email. Redirecting to reset page...');
      setEmail('');

      // Auto-redirect to reset page after 2 seconds
      // Pass email in state so it's prefilled on the reset page
      setTimeout(() => {
        navigate('/reset-password', { state: { email } });
      }, 2000);
    } catch (err) {
      console.error('Forgot password error:', err);
      setError(err.response?.data?.error?.message || 'Failed to send reset PIN');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <h1>Forgot Password?</h1>
          <p>Enter your email to receive a 6-digit reset PIN</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          {message && (
            <div className="success-message">
              {message}
            </div>
          )}

          <div className="form-group">
            <label htmlFor="email">Email Address</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary btn-block"
            disabled={loading}
          >
            {loading ? 'Sending...' : 'Send Reset PIN'}
          </button>
        </form>

        <div className="auth-footer">
          <p>
            Remember your password?{' '}
            <Link to="/login">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default ForgotPassword;