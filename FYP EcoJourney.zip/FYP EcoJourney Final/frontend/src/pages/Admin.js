/**
 * Admin Page Component (User Management)
 *
 * Admin dashboard for managing user accounts. Only accessible to users
 * with the Admin role. Provides full CRUD operations on user accounts.
 *
 * Features:
 * ---------
 * 1. View all registered users in a table format
 * 2. Search users by username or email with autocomplete suggestions
 * 3. Edit user details (username, email, role)
 * 4. Change user passwords (admin override)
 * 5. Delete user accounts (with confirmation)
 * 6. View user status (active/blocked) and role
 *
 * Access Control:
 * ---------------
 * - Only Admin role can access this page
 * - Protected by AdminRoute wrapper in App.js
 * - Requires valid JWT token for all API calls
 *
 * API Endpoints Used:
 * -------------------
 * - GET /admin-panel/users - Fetch all users
 * - GET /users-permissions/roles - Fetch available roles
 * - PUT /admin-panel/users/:id - Update user details
 * - PUT /admin-panel/users/:id/role - Update user role
 * - PUT /admin-panel/users/:id/password - Change password
 * - DELETE /admin-panel/users/:id - Delete user
 *
 * Modals:
 * -------
 * 1. Edit Modal: Update username, email, and role assignment
 * 2. Password Modal: Set new password for user (admin override)
 */

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { getAllUsers, getAllRoles, changeUserPassword, updateUser, updateUserRole, deleteUser } from '../services/api';
import AdminNav from '../components/AdminNav';
import './Admin.css';

function Admin() {
  // Get JWT token for API authentication
  const { token } = useAuth();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // User data
  const [users, setUsers] = useState([]);              // All users from API
  const [roles, setRoles] = useState([]);              // Available roles
  const [filteredUsers, setFilteredUsers] = useState([]); // Users after search filter

  // UI state
  const [loading, setLoading] = useState(true);        // Loading indicator
  const [error, setError] = useState(null);            // Error message
  const [successMessage, setSuccessMessage] = useState(''); // Success feedback

  // Modal state
  const [selectedUser, setSelectedUser] = useState(null);   // User being edited
  const [modalType, setModalType] = useState(null);         // 'password' or 'edit'
  const [modalError, setModalError] = useState('');         // Modal-specific error
  const [submitting, setSubmitting] = useState(false);      // Form submission state

  // Password modal fields
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Edit modal fields
  const [editUsername, setEditUsername] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editRole, setEditRole] = useState('');

  // Search functionality
  const [searchQuery, setSearchQuery] = useState('');       // Search input value
  const [suggestions, setSuggestions] = useState([]);       // Autocomplete suggestions
  const [showSuggestions, setShowSuggestions] = useState(false); // Show suggestion dropdown
  const searchRef = useRef(null);  // Ref for click-outside detection

  useEffect(() => {
    fetchUsers();
    fetchRoles();
  }, [token]);

  // Handle click outside to close suggestions
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (searchRef.current && !searchRef.current.contains(event.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Filter users based on search query
  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredUsers(users);
      setSuggestions([]);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = users.filter(user =>
        user.username.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query)
      );
      setFilteredUsers(filtered);

      // Get suggestions (limit to 5)
      const suggestionList = users
        .filter(user => user.username.toLowerCase().includes(query))
        .slice(0, 5);
      setSuggestions(suggestionList);
    }
  }, [searchQuery, users]);

  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value);
    setShowSuggestions(true);
  };

  const handleSuggestionClick = (username) => {
    setSearchQuery(username);
    setShowSuggestions(false);
  };

  const clearSearch = () => {
    setSearchQuery('');
    setSuggestions([]);
    setShowSuggestions(false);
  };

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const response = await getAllUsers(token);
      const userData = response.data.data || [];
      setUsers(userData);
      setFilteredUsers(userData);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch users:', err);
      setError('Failed to load users. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const fetchRoles = async () => {
    try {
      const response = await getAllRoles(token);
      setRoles(response.data.roles || []);
    } catch (err) {
      console.error('Failed to fetch roles:', err);
    }
  };

  const openPasswordModal = (user) => {
    setSelectedUser(user);
    setModalType('password');
    setNewPassword('');
    setConfirmPassword('');
    setModalError('');
  };

  const openEditModal = (user) => {
    setSelectedUser(user);
    setModalType('edit');
    setEditUsername(user.username);
    setEditEmail(user.email);
    setEditRole(user.role?.id || '');
    setModalError('');
  };

  const closeModal = () => {
    setSelectedUser(null);
    setModalType(null);
    setNewPassword('');
    setConfirmPassword('');
    setEditUsername('');
    setEditEmail('');
    setEditRole('');
    setModalError('');
  };

  const handlePasswordChange = async (e) => {
    e.preventDefault();
    setModalError('');
    setSuccessMessage('');

    if (newPassword.length < 6) {
      setModalError('Password must be at least 6 characters long');
      return;
    }

    if (newPassword !== confirmPassword) {
      setModalError('Passwords do not match');
      return;
    }

    try {
      setSubmitting(true);
      await changeUserPassword(selectedUser.id, newPassword, token);
      setSuccessMessage(`Password updated successfully for ${selectedUser.username}`);
      closeModal();
    } catch (err) {
      console.error('Failed to change password:', err);
      setModalError(err.response?.data?.error?.message || 'Failed to update password');
    } finally {
      setSubmitting(false);
    }
  };

  const handleUserUpdate = async (e) => {
    e.preventDefault();
    setModalError('');
    setSuccessMessage('');

    // Check if anything changed
    const usernameChanged = editUsername !== selectedUser.username;
    const emailChanged = editEmail !== selectedUser.email;
    const roleChanged = editRole !== selectedUser.role?.id;

    if (!usernameChanged && !emailChanged && !roleChanged) {
      setModalError('No changes detected');
      return;
    }

    if (editUsername.length < 3) {
      setModalError('Username must be at least 3 characters long');
      return;
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(editEmail)) {
      setModalError('Please enter a valid email address');
      return;
    }

    try {
      setSubmitting(true);

      // Update username and email if changed
      if (usernameChanged || emailChanged) {
        const updateData = {};
        if (usernameChanged) updateData.username = editUsername;
        if (emailChanged) updateData.email = editEmail;
        await updateUser(selectedUser.id, updateData, token);
      }

      // Update role if changed
      if (roleChanged) {
        await updateUserRole(selectedUser.id, editRole, token);
      }

      setSuccessMessage(`User ${selectedUser.username} updated successfully`);

      // Update local state
      const updatedRole = roles.find(r => r.id === parseInt(editRole));
      setUsers(users.map(u =>
        u.id === selectedUser.id
          ? { ...u, username: editUsername, email: editEmail, role: updatedRole }
          : u
      ));
      closeModal();
    } catch (err) {
      console.error('Failed to update user:', err);
      setModalError(err.response?.data?.error?.message || 'Failed to update user');
    } finally {
      setSubmitting(false);
    }
  };

  const handleDeleteUser = async (user) => {
    const confirmMessage = `Are you sure you want to delete user "${user.username}"?\n\nThis will permanently delete:\n- The user account\n- All their quiz results and scores\n\nThis action cannot be undone.`;

    if (!window.confirm(confirmMessage)) {
      return;
    }

    try {
      setSuccessMessage('');
      setError('');
      await deleteUser(user.id, token);
      setSuccessMessage(`User ${user.username} deleted successfully`);

      // Remove user from local state
      setUsers(users.filter(u => u.id !== user.id));
    } catch (err) {
      console.error('Failed to delete user:', err);
      setError(err.response?.data?.error?.message || 'Failed to delete user');
    }
  };

  if (loading) {
    return (
      <div className="admin-container">
        <div className="admin-loading">Loading users...</div>
      </div>
    );
  }

  return (
    <>
      <AdminNav />
      <div className="admin-container">
        <div className="admin-header">
          <h1>User Management</h1>
          <p>View all users and manage their accounts</p>
        </div>

      {error && <div className="admin-error">{error}</div>}
      {successMessage && <div className="admin-success">{successMessage}</div>}

      {/* Search Bar */}
      <div className="search-container" ref={searchRef}>
        <div className="search-input-wrapper">
          <input
            type="text"
            className="search-input"
            placeholder="Search by username or email..."
            value={searchQuery}
            onChange={handleSearchChange}
            onFocus={() => setShowSuggestions(true)}
          />
          {searchQuery && (
            <button className="clear-search-btn" onClick={clearSearch}>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </button>
          )}
        </div>
        {showSuggestions && suggestions.length > 0 && (
          <ul className="suggestions-list">
            {suggestions.map((user) => (
              <li
                key={user.id}
                className="suggestion-item"
                onClick={() => handleSuggestionClick(user.username)}
              >
                <span className="suggestion-username">{user.username}</span>
                <span className="suggestion-email">{user.email}</span>
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* Results count */}
      {searchQuery && (
        <div className="search-results-count">
          Found {filteredUsers.length} user{filteredUsers.length !== 1 ? 's' : ''} matching "{searchQuery}"
        </div>
      )}

      <div className="users-table-container">
        <table className="users-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Username</th>
              <th>Email</th>
              <th>Role</th>
              <th>Created</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredUsers.length === 0 ? (
              <tr>
                <td colSpan="7" className="no-users">
                  {searchQuery ? 'No users match your search' : 'No users found'}
                </td>
              </tr>
            ) : (
              filteredUsers.map((user) => (
                <tr key={user.id}>
                  <td>{user.id}</td>
                  <td>{user.username}</td>
                  <td>{user.email}</td>
                  <td>
                    <span className={`role-badge ${user.role?.type || 'authenticated'}`}>
                      {user.role?.name || 'Authenticated'}
                    </span>
                  </td>
                  <td>{new Date(user.createdAt).toLocaleDateString()}</td>
                  <td>
                    <span className={`status-badge ${user.blocked ? 'blocked' : 'active'}`}>
                      {user.blocked ? 'Blocked' : 'Active'}
                    </span>
                  </td>
                  <td className="actions-cell">
                    <button
                      className="edit-btn"
                      onClick={() => openEditModal(user)}
                    >
                      Edit
                    </button>
                    <button
                      className="change-password-btn"
                      onClick={() => openPasswordModal(user)}
                    >
                      Password
                    </button>
                    <button
                      className="delete-btn"
                      onClick={() => handleDeleteUser(user)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Edit User Modal */}
      {selectedUser && modalType === 'edit' && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Edit User</h2>
            <p>Editing user ID: <strong>{selectedUser.id}</strong></p>

            <form onSubmit={handleUserUpdate}>
              <div className="form-group">
                <label htmlFor="editUsername">Username</label>
                <input
                  type="text"
                  id="editUsername"
                  value={editUsername}
                  onChange={(e) => setEditUsername(e.target.value)}
                  placeholder="Enter username"
                  required
                  minLength={3}
                />
              </div>

              <div className="form-group">
                <label htmlFor="editEmail">Email</label>
                <input
                  type="email"
                  id="editEmail"
                  value={editEmail}
                  onChange={(e) => setEditEmail(e.target.value)}
                  placeholder="Enter email"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="editRole">Role</label>
                <select
                  id="editRole"
                  value={editRole}
                  onChange={(e) => setEditRole(e.target.value)}
                  required
                >
                  <option value="">Select a role</option>
                  {roles
                    .filter((role) => role.type !== 'public')
                    .map((role) => (
                      <option key={role.id} value={role.id}>
                        {role.name}
                      </option>
                    ))}
                </select>
              </div>

              {modalError && <div className="modal-error">{modalError}</div>}

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={closeModal}>
                  Cancel
                </button>
                <button type="submit" className="submit-btn" disabled={submitting}>
                  {submitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {selectedUser && modalType === 'password' && (
        <div className="modal-overlay" onClick={closeModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Change Password</h2>
            <p>Changing password for: <strong>{selectedUser.username}</strong></p>
            <p className="user-email">{selectedUser.email}</p>

            <form onSubmit={handlePasswordChange}>
              <div className="form-group">
                <label htmlFor="newPassword">New Password</label>
                <input
                  type="password"
                  id="newPassword"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Enter new password"
                  required
                  minLength={6}
                />
              </div>

              <div className="form-group">
                <label htmlFor="confirmPassword">Confirm Password</label>
                <input
                  type="password"
                  id="confirmPassword"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm new password"
                  required
                  minLength={6}
                />
              </div>

              {modalError && <div className="modal-error">{modalError}</div>}

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={closeModal}>
                  Cancel
                </button>
                <button type="submit" className="submit-btn" disabled={submitting}>
                  {submitting ? 'Updating...' : 'Update Password'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </div>
    </>
  );
}

export default Admin;
