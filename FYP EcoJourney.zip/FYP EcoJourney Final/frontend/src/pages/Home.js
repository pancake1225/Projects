/**
 * Home Page Component (Landing Page)
 *
 * The main landing page for EcoJourney - displays when users visit the root URL.
 * Features a full-screen hero section with the RP ESG Centre branding.
 *
 * Features:
 * ---------
 * 1. Fixed header with logo and navigation
 * 2. Header shadow effect on scroll (appears after 100px scroll)
 * 3. Responsive mobile menu (hamburger menu on small screens)
 * 4. Full-screen hero section with background image
 * 5. Different navigation options for authenticated vs unauthenticated users
 *
 * Layout Structure:
 * -----------------
 * - Fixed Header: Logo + Navigation (Sign In/Sign Up or Welcome message)
 * - Hero Section: Full viewport height with background image and CTA
 *
 * Note: This page has its own header separate from the main Navbar component
 * because it uses a different visual style (transparent header on hero).
 */

import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import './Home.css';

// Import images for the landing page
import buildingImage from '../assets/building.png';  // Hero background image
import rpLogo from '../assets/rp.jpg';               // Republic Polytechnic logo

function Home() {
  // Get authentication state to show different navigation options
  const { isAuthenticated, user } = useAuth();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [showMobileMenu, setShowMobileMenu] = useState(false);  // Mobile menu visibility
  const [headerShadow, setHeaderShadow] = useState(false);      // Header shadow on scroll

  // =========================================================================
  // SCROLL HANDLER - Adds shadow to header when scrolled
  // =========================================================================
  useEffect(() => {
    const handleScroll = () => {
      // Add shadow class when scrolled more than 100 pixels
      setHeaderShadow(window.pageYOffset > 100);
    };
    window.addEventListener('scroll', handleScroll);
    // Cleanup: remove listener when component unmounts
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // =========================================================================
  // MOBILE MENU BODY SCROLL LOCK
  // Prevents background scrolling when mobile menu is open
  // =========================================================================
  useEffect(() => {
    // When mobile menu is open, disable body scroll to prevent background scrolling
    document.body.style.overflow = showMobileMenu ? 'hidden' : '';
  }, [showMobileMenu]);

  return (
    <div className="landing-page">
      {/* Fixed Header */}
      <header className={`landing-header ${headerShadow ? 'header-shadow' : ''}`}>
        <div className="header-container">
          <div className="header-content">
            {/* Logo and Title */}
            <div className="header-logo">
              <div className="logo-circle">
                <img src={rpLogo} alt="Republic Polytechnic ESGC" />
              </div>
              <span className="header-title">Republic Polytechnic ESGC</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="desktop-nav">
              {isAuthenticated ? (
                <>
                  <span className="nav-welcome">Welcome, {user?.username}</span>
                  <Link to="/articles" className="btn-signup">Explore Pages</Link>
                </>
              ) : (
                <>
                  <Link to="/login" className="nav-link">Sign In</Link>
                  <Link to="/register" className="btn-signup">Sign Up</Link>
                </>
              )}
            </nav>

            {/* Mobile Menu Button */}
            <button 
              onClick={() => setShowMobileMenu(!showMobileMenu)}
              className="mobile-menu-btn"
            >
              {showMobileMenu ? (
                <svg className="menu-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="menu-icon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>

          {/* Mobile Navigation */}
          {showMobileMenu && (
            <nav className="mobile-nav">
              {isAuthenticated ? (
                <>
                  <span className="mobile-nav-welcome">Welcome, {user?.username}</span>
                  <Link to="/articles" onClick={() => setShowMobileMenu(false)} className="btn-signup mobile">
                    Explore Articles
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/login" onClick={() => setShowMobileMenu(false)} className="mobile-nav-link">
                    Sign In
                  </Link>
                  <Link to="/register" onClick={() => setShowMobileMenu(false)} className="btn-signup mobile">
                    Sign Up
                  </Link>
                </>
              )}
            </nav>
          )}
        </div>
      </header>

      {/* Hero Section - Full Screen */}
      <section className="hero-section">
        {/* Background Image */}
        <div className="hero-background">
          <img src={buildingImage} alt="Campus building" />
          <div className="hero-overlay"></div>
        </div>

        {/* Hero Content */}
        <div className="hero-content-wrapper">
          <div className="hero-content">
            <div className="hero-badge">
              Get ready for a greener tomorrow with RP Together!
            </div>
            <h1 className="hero-title">
              Creating a Sustainable Future for Our Planet
            </h1>
            <p className="hero-description">
              Join us in our mission to protect and preserve the environment through innovative solutions, 
              community engagement, and sustainable practices that make a real difference.
            </p>
            <Link to="/articles" className="hero-button">
              Explore Our Work
              <svg className="button-arrow" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}

export default Home;