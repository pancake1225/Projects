import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getAllQuizResults, updateQuizResult, deleteQuizResult } from '../services/api';
import AdminNav from '../components/AdminNav';
import './ManageLeaderboard.css';

function ManageLeaderboard() {
  const { user } = useAuth();
  const [scores, setScores] = useState([]);
  const [aggregatedScores, setAggregatedScores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({ points: 0, score: 0 });
  const [saving, setSaving] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);
  const [viewMode, setViewMode] = useState('aggregated'); // 'aggregated' or 'individual'
  const [selectedUser, setSelectedUser] = useState(null);

  const fetchScores = async () => {
    try {
      setLoading(true);
      const response = await getAllQuizResults();
      console.log('ManageLeaderboard API response:', response.data);

      if (response.data && response.data.data) {
        const rawScores = response.data.data;
        setScores(rawScores);

        // Aggregate scores by user for leaderboard view
        const userScores = {};
        rawScores.forEach((result) => {
          // Use direct userId/username fields (we store them directly)
          const userId = result.userId;
          const username = result.username;

          if (userId && username) {
            if (!userScores[userId]) {
              userScores[userId] = {
                id: userId,
                username: username,
                totalPoints: 0,
                quizzesTaken: 0,
                submissions: []
              };
            }
            userScores[userId].totalPoints += result.points || result.score || 0;
            userScores[userId].quizzesTaken += 1;
            userScores[userId].submissions.push(result);
          }
        });

        // Sort users by total points
        const sortedUsers = Object.values(userScores)
          .sort((a, b) => b.totalPoints - a.totalPoints);

        // Assign ranks with tie handling (standard competition ranking)
        let currentRank = 1;
        const leaderboard = sortedUsers.map((u, index) => {
          // If not first user and has different points than previous, update rank
          if (index > 0 && u.totalPoints < sortedUsers[index - 1].totalPoints) {
            currentRank = index + 1;
          }

          // Check if this position is tied (same points as previous or next user)
          const hasSamePointsAsPrev = index > 0 && u.totalPoints === sortedUsers[index - 1].totalPoints;
          const hasSamePointsAsNext = index < sortedUsers.length - 1 && u.totalPoints === sortedUsers[index + 1].totalPoints;
          const isTied = hasSamePointsAsPrev || hasSamePointsAsNext;

          return {
            ...u,
            rank: currentRank,
            isTied
          };
        });

        console.log('ManageLeaderboard processed data:', leaderboard);
        setAggregatedScores(leaderboard);
      }
      setError(null);
    } catch (err) {
      console.error('Error fetching scores:', err);
      console.error('Error details:', err.response?.data || err.message);
      setError('Failed to load quiz scores');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchScores();

    const intervalId = setInterval(() => {
      fetchScores();
    }, 5000);

    return () => clearInterval(intervalId);
  }, []);

  const handleEdit = (score) => {
    setEditingId(score.documentId);
    setEditForm({
      points: score.points || 0,
      score: score.score || 0
    });
  };

  const handleCancelEdit = () => {
    setEditingId(null);
    setEditForm({ points: 0, score: 0 });
  };

  const handleSaveEdit = async (documentId) => {
    try {
      setSaving(true);
      await updateQuizResult(documentId, {
        points: parseInt(editForm.points, 10),
        score: parseInt(editForm.score, 10)
      });
      setEditingId(null);
      await fetchScores();
    } catch (err) {
      console.error('Error updating score:', err);
      alert('Failed to update score. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (documentId) => {
    try {
      setSaving(true);
      await deleteQuizResult(documentId);
      setDeleteConfirm(null);
      await fetchScores();
    } catch (err) {
      console.error('Error deleting score:', err);
      alert('Failed to delete score. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteAllUserScores = async (userId) => {
    const userSubmissions = scores.filter(s => (s.user?.id || s.userId) === userId);
    if (userSubmissions.length === 0) return;

    if (!window.confirm(`Are you sure you want to delete ALL ${userSubmissions.length} scores for this user? This will remove them from the leaderboard.`)) {
      return;
    }

    try {
      setSaving(true);
      for (const submission of userSubmissions) {
        await deleteQuizResult(submission.documentId);
      }
      setSelectedUser(null);
      await fetchScores();
    } catch (err) {
      console.error('Error deleting user scores:', err);
      alert('Failed to delete some scores. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const getUserSubmissions = (userId) => {
    return scores.filter(s => (s.user?.id || s.userId) === userId);
  };

  if (loading && scores.length === 0) {
    return (
      <div className="manage-leaderboard-page">
        <div className="manage-leaderboard-loading">Loading leaderboard data...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="manage-leaderboard-page">
        <div className="manage-leaderboard-error">{error}</div>
      </div>
    );
  }

  return (
    <>
      <AdminNav />
      <div className="manage-leaderboard-page">
        <div className="manage-leaderboard-hero">
          <div className="manage-leaderboard-hero-content">
            <h1 className="manage-leaderboard-hero-title">Manage Leaderboard Scores</h1>
            <p className="manage-leaderboard-hero-text">
              Edit and delete user quiz scores to customize the leaderboard
            </p>
          </div>
        </div>

      <div className="manage-leaderboard-container">
        <div className="view-toggle">
          <button
            className={`toggle-btn ${viewMode === 'aggregated' ? 'active' : ''}`}
            onClick={() => { setViewMode('aggregated'); setSelectedUser(null); }}
          >
            Leaderboard View
          </button>
          <button
            className={`toggle-btn ${viewMode === 'individual' ? 'active' : ''}`}
            onClick={() => setViewMode('individual')}
          >
            Individual Scores
          </button>
        </div>

        {viewMode === 'aggregated' && !selectedUser && (
          <>
            <h2 className="section-title">Current Leaderboard Rankings</h2>
            {aggregatedScores.length === 0 ? (
              <div className="no-scores-data">
                <p>No quiz scores yet.</p>
              </div>
            ) : (
              <div className="leaderboard-table-container">
                <table className="leaderboard-manage-table">
                  <thead>
                    <tr>
                      <th>Rank</th>
                      <th>Username</th>
                      <th>Total Points</th>
                      <th>Quizzes Taken</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {aggregatedScores.map((u) => (
                      <tr key={u.id} className={u.rank <= 3 ? `top-${u.rank}` : ''}>
                        <td className="rank-col">
                          {u.rank === 1 && '🥇 '}
                          {u.rank === 2 && '🥈 '}
                          {u.rank === 3 && '🥉 '}
                          {u.isTied ? `T-${u.rank}` : u.rank}
                        </td>
                        <td className="user-col">{u.username}</td>
                        <td className="points-col">{u.totalPoints}</td>
                        <td className="quizzes-col">{u.quizzesTaken}</td>
                        <td className="actions-cell">
                          <button
                            className="btn-view"
                            onClick={() => setSelectedUser(u)}
                          >
                            View/Edit
                          </button>
                          <button
                            className="btn-delete-all"
                            onClick={() => handleDeleteAllUserScores(u.id)}
                            disabled={saving}
                          >
                            Remove from Leaderboard
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}

        {viewMode === 'aggregated' && selectedUser && (
          <>
            <div className="user-detail-header">
              <button className="btn-back" onClick={() => setSelectedUser(null)}>
                ← Back to Leaderboard
              </button>
              <h2 className="section-title">
                Scores for {selectedUser.username} (Rank #{selectedUser.isTied ? `T-${selectedUser.rank}` : selectedUser.rank})
              </h2>
            </div>
            <div className="user-stats">
              <div className="stat-card">
                <span className="stat-value">{selectedUser.totalPoints}</span>
                <span className="stat-label">Total Points</span>
              </div>
              <div className="stat-card">
                <span className="stat-value">{selectedUser.quizzesTaken}</span>
                <span className="stat-label">Quizzes Taken</span>
              </div>
            </div>
            <div className="scores-table-container">
              <table className="scores-detail-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Score</th>
                    <th>Total Q</th>
                    <th>Points</th>
                    <th>Difficulty</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {getUserSubmissions(selectedUser.id).map((s) => (
                    <tr key={s.documentId}>
                      <td>{s.id}</td>
                      <td>
                        {editingId === s.documentId ? (
                          <input
                            type="number"
                            className="edit-input"
                            value={editForm.score}
                            onChange={(e) => setEditForm({ ...editForm, score: e.target.value })}
                            min="0"
                          />
                        ) : (
                          s.score
                        )}
                      </td>
                      <td>{s.totalQuestions}</td>
                      <td>
                        {editingId === s.documentId ? (
                          <input
                            type="number"
                            className="edit-input"
                            value={editForm.points}
                            onChange={(e) => setEditForm({ ...editForm, points: e.target.value })}
                            min="0"
                          />
                        ) : (
                          s.points
                        )}
                      </td>
                      <td>
                        <span className={`difficulty-badge ${s.difficulty}`}>
                          {s.difficulty}
                        </span>
                      </td>
                      <td className="actions-cell">
                        {editingId === s.documentId ? (
                          <>
                            <button className="btn-save" onClick={() => handleSaveEdit(s.documentId)} disabled={saving}>
                              {saving ? 'Saving...' : 'Save'}
                            </button>
                            <button className="btn-cancel" onClick={handleCancelEdit} disabled={saving}>
                              Cancel
                            </button>
                          </>
                        ) : deleteConfirm === s.documentId ? (
                          <>
                            <button className="btn-delete-confirm" onClick={() => handleDelete(s.documentId)} disabled={saving}>
                              {saving ? 'Deleting...' : 'Confirm'}
                            </button>
                            <button className="btn-cancel" onClick={() => setDeleteConfirm(null)} disabled={saving}>
                              Cancel
                            </button>
                          </>
                        ) : (
                          <>
                            <button className="btn-edit" onClick={() => handleEdit(s)}>
                              Edit
                            </button>
                            <button className="btn-delete" onClick={() => setDeleteConfirm(s.documentId)}>
                              Delete
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}

        {viewMode === 'individual' && (
          <>
            <h2 className="section-title">All Individual Quiz Scores</h2>
            {scores.length === 0 ? (
              <div className="no-scores-data">
                <p>No quiz scores to manage yet.</p>
              </div>
            ) : (
              <div className="scores-table-container">
                <table className="scores-detail-table">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Username</th>
                      <th>Score</th>
                      <th>Total Q</th>
                      <th>Points</th>
                      <th>Difficulty</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {scores.map((s) => (
                      <tr key={s.documentId}>
                        <td>{s.id}</td>
                        <td>{s.user?.username || s.username || 'Unknown'}</td>
                        <td>
                          {editingId === s.documentId ? (
                            <input
                              type="number"
                              className="edit-input"
                              value={editForm.score}
                              onChange={(e) => setEditForm({ ...editForm, score: e.target.value })}
                              min="0"
                            />
                          ) : (
                            s.score
                          )}
                        </td>
                        <td>{s.totalQuestions}</td>
                        <td>
                          {editingId === s.documentId ? (
                            <input
                              type="number"
                              className="edit-input"
                              value={editForm.points}
                              onChange={(e) => setEditForm({ ...editForm, points: e.target.value })}
                              min="0"
                            />
                          ) : (
                            s.points
                          )}
                        </td>
                        <td>
                          <span className={`difficulty-badge ${s.difficulty}`}>
                            {s.difficulty}
                          </span>
                        </td>
                        <td className="actions-cell">
                          {editingId === s.documentId ? (
                            <>
                              <button className="btn-save" onClick={() => handleSaveEdit(s.documentId)} disabled={saving}>
                                {saving ? 'Saving...' : 'Save'}
                              </button>
                              <button className="btn-cancel" onClick={handleCancelEdit} disabled={saving}>
                                Cancel
                              </button>
                            </>
                          ) : deleteConfirm === s.documentId ? (
                            <>
                              <button className="btn-delete-confirm" onClick={() => handleDelete(s.documentId)} disabled={saving}>
                                {saving ? 'Deleting...' : 'Confirm'}
                              </button>
                              <button className="btn-cancel" onClick={() => setDeleteConfirm(null)} disabled={saving}>
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button className="btn-edit" onClick={() => handleEdit(s)}>
                                Edit
                              </button>
                              <button className="btn-delete" onClick={() => setDeleteConfirm(s.documentId)}>
                                Delete
                              </button>
                            </>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </>
        )}
      </div>
      </div>
    </>
  );
}

export default ManageLeaderboard;
