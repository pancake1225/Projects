/**
 * Login Page Component
 *
 * Provides the user login form for EcoJourney.
 * Uses the AuthContext for authentication handling.
 *
 * Features:
 * ---------
 * 1. Email and password input fields
 * 2. Form validation (required fields)
 * 3. Error message display
 * 4. Loading state during authentication
 * 5. Links to registration and forgot password
 *
 * Authentication Flow:
 * --------------------
 * 1. User enters email and password
 * 2. Form submits to AuthContext's login function
 * 3. AuthContext calls Strapi /auth/local endpoint
 * 4. On success: JWT stored, user redirected to /articles
 * 5. On failure: Error message displayed
 *
 * Related Pages:
 * --------------
 * - /register - Create new account
 * - /forgot-password - Request password reset PIN
 */

import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { trackLogin } from '../analytics';
import './Auth.css';

function Login() {
  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [email, setEmail] = useState('');       // Email input value
  const [password, setPassword] = useState(''); // Password input value
  const [error, setError] = useState('');       // Error message to display
  const [loading, setLoading] = useState(false); // Loading state during API call

  // Get login function from AuthContext
  const { login } = useAuth();
  const navigate = useNavigate();

  // =========================================================================
  // FORM SUBMISSION HANDLER
  // =========================================================================

  /**
   * Handle Form Submit
   *
   * Validates input and calls AuthContext login function.
   * On success, redirects to quizzes page.
   * On failure, displays error message.
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Basic validation - ensure both fields are filled
    if (!email || !password) {
      setError('Please fill in all fields');
      setLoading(false);
      return;
    }

    // Call AuthContext login function
    const result = await login(email, password);

    if (result.success) {
      // Login successful - track and redirect to articles page
      trackLogin();
      navigate('/articles');
    } else {
      // Login failed - show error message
      setError(result.error);
    }

    setLoading(false);
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-header">
          <h1>Welcome Back</h1>
          <p>Sign in to continue your eco-journey</p>
        </div>

        <form onSubmit={handleSubmit} className="auth-form">
          {error && (
            <div className="error-message">
              {error}
            </div>
          )}

          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter your password"
              required
            />
            <div className="forgot-password-link">
              <Link to="/forgot-password">Forgot password?</Link>
            </div>
          </div>

          <button 
            type="submit" 
            className="btn btn-primary btn-block"
            disabled={loading}
          >
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>

        <div className="auth-footer">
          <p>
            Don't have an account?{' '}
            <Link to="/register">Sign up</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;