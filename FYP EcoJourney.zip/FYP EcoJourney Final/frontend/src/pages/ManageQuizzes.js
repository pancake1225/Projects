/**
 * Manage Quizzes Page Component
 *
 * Admin/Writer dashboard for creating and managing quizzes.
 * Quizzes are containers that link to questions from the Question Bank.
 *
 * Features:
 * ---------
 * 1. Create new quizzes with title, description, category, and tags
 * 2. Edit existing quiz metadata
 * 3. Delete quizzes (Admin only)
 * 4. Upload thumbnail images for quiz cards
 * 5. Filter quizzes by category, tag, and search
 * 6. Sort quizzes by date, title, or category
 *
 * Access Control:
 * ---------------
 * - Accessible by Admin and Writer roles
 * - Writers can create/edit but NOT delete
 * - Delete button hidden for non-Admin users
 *
 * Quiz-Question Relationship:
 * ---------------------------
 * Quizzes don't contain questions directly. Instead:
 * 1. Quiz has a category and optional tags
 * 2. Questions in the Question Bank have matching categories/tags
 * 3. When user attempts quiz, questions are pulled dynamically
 * 4. User selects difficulty, which affects question count and time
 *
 * This design allows:
 * - Same questions to be used across multiple quizzes
 * - Question bank to be updated without editing quizzes
 * - Dynamic difficulty/time based on user choice
 *
 * API Endpoints:
 * --------------
 * - GET /quizzes - Fetch all quizzes
 * - POST /quizzes - Create new quiz
 * - PUT /quizzes/:documentId - Update quiz
 * - DELETE /quizzes/:documentId - Delete quiz
 * - PUT /quizzes/:documentId/tags - Update quiz tags (custom endpoint)
 */

import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { usePermissions } from '../context/PermissionsContext';
import { getQuizzes, createQuiz, updateQuiz, deleteQuiz, getCategories, getTags, updateQuizTags } from '../services/api';
import AdminNav from '../components/AdminNav';
import WriterNav from '../components/WriterNav';
import './ManageQuizzes.css';

function ManageQuizzes() {
  const location = useLocation();
  const { token, user } = useAuth();
  const { canDelete } = usePermissions();  // Only Admins can delete

  // Determine which navigation to show based on URL path
  const isWriterPath = location.pathname.startsWith('/writer');

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // Quiz data
  const [quizzes, setQuizzes] = useState([]);          // All quizzes from API
  const [categories, setCategories] = useState([]);    // Categories for dropdown
  const [tags, setTags] = useState([]);                // Tags for selection

  // UI state
  const [loading, setLoading] = useState(true);        // Loading indicator
  const [error, setError] = useState(null);            // Error message
  const [successMessage, setSuccessMessage] = useState(''); // Success feedback

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);   // Modal visibility
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [selectedQuiz, setSelectedQuiz] = useState(null); // Quiz being edited
  const [submitting, setSubmitting] = useState(false); // Form submission state

  // Filter and sort state
  const [sortBy, setSortBy] = useState('recent');      // Sort order
  const [filterCategory, setFilterCategory] = useState(''); // Category filter
  const [filterTag, setFilterTag] = useState('');      // Tag filter
  const [searchQuery, setSearchQuery] = useState('');  // Search text

  // New tag creation state
  const [showNewTagInput, setShowNewTagInput] = useState(false);
  const [newTagName, setNewTagName] = useState('');

  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    description: '',
    category: '',
    tags: [],
  });
  const [thumbnailFile, setThumbnailFile] = useState(null);
  const [thumbnailPreview, setThumbnailPreview] = useState(null);

  useEffect(() => {
    fetchQuizzes();
    fetchCategories();
    fetchTags();
  }, []);

  const handleCategoryFilterChange = (e) => {
    setFilterCategory(e.target.value);
    setFilterTag(''); // Clear tag filter when category changes
  };

  const fetchCategories = async () => {
    try {
      const response = await getCategories();
      setCategories(response.data.data || []);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await getTags();
      setTags(response.data.data || []);
    } catch (err) {
      console.error('Failed to fetch tags:', err);
    }
  };

  const fetchQuizzes = async () => {
    try {
      setLoading(true);
      const response = await getQuizzes();
      setQuizzes(response.data.data || []);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch quizzes:', err);
      setError('Failed to load quizzes. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const openCreateModal = () => {
    setModalMode('create');
    setFormData({
      title: '',
      slug: '',
      description: '',
      category: '',
      tags: [],
    });
    setModalOpen(true);
  };

  const openEditModal = (quiz) => {
    setModalMode('edit');
    setSelectedQuiz(quiz);

    // Extract tag IDs as strings for multi-select
    const tagIds = quiz.tags?.map(t => String(t.id)) || [];
    console.log('Opening edit modal for quiz:', quiz.title);
    console.log('Quiz tags:', quiz.tags);
    console.log('Tag IDs for form:', tagIds);

    setFormData({
      title: quiz.title || '',
      slug: quiz.slug || '',
      description: quiz.description || '',
      category: quiz.category?.id || '',
      tags: tagIds,
    });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setSelectedQuiz(null);
    setThumbnailFile(null);
    setThumbnailPreview(null);
    setError(null);
    setShowNewTagInput(false);
    setNewTagName('');
  };

  const handleThumbnailChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file');
        return;
      }
      setThumbnailFile(file);
      setThumbnailPreview(URL.createObjectURL(file));
    }
  };

  const uploadThumbnail = async (file) => {
    const formData = new FormData();
    formData.append('files', file);

    const response = await fetch('http://localhost:1337/api/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to upload thumbnail');
    }

    const data = await response.json();
    return data[0].id; // Return the uploaded file ID
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Auto-generate slug from title
    if (name === 'title' && modalMode === 'create') {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setFormData(prev => ({
        ...prev,
        slug
      }));
    }
  };

  const handleTagsChange = (e) => {
    const selectedOptions = Array.from(e.target.selectedOptions, option => option.value);
    console.log('Selected tags:', selectedOptions);
    setFormData(prev => ({
      ...prev,
      tags: selectedOptions
    }));
  };

  const handleTagCheckboxChange = (tagId) => {
    setFormData(prev => {
      const tagIdStr = String(tagId);
      const isSelected = prev.tags.includes(tagIdStr);

      const newTags = isSelected
        ? prev.tags.filter(id => id !== tagIdStr)
        : [...prev.tags, tagIdStr];

      console.log('Selected tags:', newTags);
      return {
        ...prev,
        tags: newTags
      };
    });
  };

  const handleCreateNewTag = async () => {
    if (!newTagName.trim()) {
      setError('Tag name cannot be empty');
      return;
    }

    if (!formData.category) {
      setError('Please select a category first before creating a tag');
      return;
    }

    try {
      const response = await fetch('http://localhost:1337/api/tags', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({
          data: {
            name: newTagName.trim(),
            category: parseInt(formData.category)
          }
        })
      });

      if (response.ok) {
        const result = await response.json();
        const newTag = result.data;

        // Add the new tag to the tags list
        setTags(prev => [...prev, newTag]);

        // Auto-select the new tag
        setFormData(prev => ({
          ...prev,
          tags: [...prev.tags, String(newTag.id)]
        }));

        // Reset the input
        setNewTagName('');
        setShowNewTagInput(false);
        setSuccessMessage('Tag created successfully!');
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        const errorData = await response.json();
        setError(`Failed to create tag: ${errorData.error?.message || 'Unknown error'}`);
      }
    } catch (err) {
      console.error('Error creating tag:', err);
      setError('An error occurred while creating the tag');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage('');

    if (!formData.title || !formData.slug) {
      setError('Title and slug are required');
      return;
    }

    if (!formData.category) {
      setError('Please select a category');
      return;
    }

    try {
      setSubmitting(true);

      // Upload thumbnail if provided
      let thumbnailId = null;
      if (thumbnailFile) {
        thumbnailId = await uploadThumbnail(thumbnailFile);
      }

      // Prepare data for Strapi v5 REST API
      const submitData = {
        title: formData.title,
        description: formData.description,
        category: parseInt(formData.category),
        publishedAt: new Date().toISOString(), // Auto-publish
      };

      // Add thumbnail: new upload takes priority, otherwise preserve existing
      if (thumbnailId) {
        submitData.thumbnail = thumbnailId;
      } else if (modalMode === 'edit' && selectedQuiz?.thumbnail?.id) {
        submitData.thumbnail = selectedQuiz.thumbnail.id;
      }

      // Add slug only for create (UID fields can't be updated)
      if (modalMode === 'create') {
        submitData.slug = formData.slug;
      }

      console.log('Submitting quiz data (without tags):', submitData);

      // Create or update the quiz first without tags
      let result;
      if (modalMode === 'create') {
        // Add author email for new quizzes
        submitData.authorEmail = user?.email || 'Unknown';
        submitData.lastUpdatedByEmail = user?.email || 'Unknown';
        result = await createQuiz(submitData, token);
        console.log('Quiz created, response:', result.data);
      } else {
        // Add updater email for edited quizzes
        submitData.lastUpdatedByEmail = user?.email || 'Unknown';
        result = await updateQuiz(selectedQuiz.documentId, submitData, token);
        console.log('Quiz updated, response:', result.data);
      }

      // Now update tags separately using the custom tags endpoint
      if (formData.tags && formData.tags.length > 0) {
        const quizDocId = modalMode === 'create' ? result.data.data.documentId : selectedQuiz.documentId;
        console.log('Updating tags for quiz:', quizDocId, 'tags:', formData.tags);

        const tagIds = formData.tags.map(id => parseInt(id));
        await updateQuizTags(quizDocId, tagIds, token);
        console.log('Tags updated successfully');
      }

      const message = modalMode === 'create' ? 'Quiz created successfully!' : 'Quiz updated successfully!';

      await fetchQuizzes();
      closeModal();

      // Set success message after modal closes and auto-clear after 5 seconds
      setSuccessMessage(message);
      setTimeout(() => setSuccessMessage(''), 5000);
    } catch (err) {
      console.error('Failed to save quiz:', err);
      console.error('Error response data:', err.response?.data);
      const errorMsg = err.response?.data?.error?.message ||
                       JSON.stringify(err.response?.data) ||
                       'Failed to save quiz';
      setError(errorMsg);
    } finally {
      setSubmitting(false);
    }
  };

  const handleDelete = async (quiz) => {
    if (!window.confirm(`Are you sure you want to delete "${quiz.title}"? This cannot be undone.`)) {
      return;
    }

    try {
      setSuccessMessage('');
      setError(null);
      await deleteQuiz(quiz.documentId, token);
      setSuccessMessage('Quiz deleted successfully!');
      await fetchQuizzes();
    } catch (err) {
      console.error('Failed to delete quiz:', err);
      setError(err.response?.data?.error?.message || 'Failed to delete quiz');
    }
  };

  const getFilteredAndSortedQuizzes = () => {
    let filtered = [...quizzes];

    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(q =>
        q.title.toLowerCase().includes(query) ||
        q.description?.toLowerCase().includes(query)
      );
    }

    if (filterCategory) {
      filtered = filtered.filter(q => q.category?.id === parseInt(filterCategory));
    }

    if (filterTag) {
      filtered = filtered.filter(q =>
        q.tags?.some(t => t.id === parseInt(filterTag))
      );
    }

    switch (sortBy) {
      case 'recent':
        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        break;
      case 'oldest':
        filtered.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
        break;
      case 'title':
        filtered.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'category':
        filtered.sort((a, b) => {
          const catA = a.category?.name || '';
          const catB = b.category?.name || '';
          return catA.localeCompare(catB);
        });
        break;
      default:
        break;
    }

    return filtered;
  };

  const filteredQuizzes = getFilteredAndSortedQuizzes();

  if (loading) {
    return (
      <>
        <AdminNav />
        <div className="admin-container">
          <div className="admin-loading">Loading quizzes...</div>
        </div>
      </>
    );
  }

  return (
    <>
      {isWriterPath ? <WriterNav /> : <AdminNav />}
      <div className="admin-container">
        <div className="admin-header">
          <div>
            <h1>Quiz Management</h1>
            <p>Create and manage quizzes - difficulty, time limits, and question counts are set by users during quiz attempt</p>
          </div>
          <button className="create-btn" onClick={openCreateModal}>
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <line x1="12" y1="5" x2="12" y2="19"></line>
              <line x1="5" y1="12" x2="19" y2="12"></line>
            </svg>
            Create Quiz
          </button>
        </div>

        {error && <div className="admin-error">{error}</div>}
        {successMessage && <div className="admin-success">{successMessage}</div>}

        {/* Filters and Search */}
        <div className="filters-section">
          <input
            type="text"
            className="search-input"
            placeholder="Search quizzes..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />

          <select
            value={filterCategory}
            onChange={handleCategoryFilterChange}
            className="filter-select"
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          <select
            value={filterTag}
            onChange={(e) => setFilterTag(e.target.value)}
            className="filter-select"
            disabled={!filterCategory}
          >
            <option value="">
              {filterCategory ? 'All Tags' : 'All Tags (Select category first)'}
            </option>
            {tags
              .filter(tag => !filterCategory || tag.category?.id === parseInt(filterCategory))
              .map(tag => (
                <option key={tag.id} value={tag.id}>
                  {tag.name}
                </option>
              ))}
          </select>

          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="filter-select"
          >
            <option value="recent">Most Recent</option>
            <option value="oldest">Oldest First</option>
            <option value="title">Title A-Z</option>
            <option value="category">Category</option>
          </select>
        </div>

        <div className="results-count">
          Showing {filteredQuizzes.length} of {quizzes.length} quizzes
        </div>

        <div className="quizzes-grid">
          {filteredQuizzes.length === 0 ? (
            <div className="no-quizzes">
              <p>{searchQuery || filterCategory || filterTag
                ? 'No quizzes match your filters'
                : 'No quizzes found. Create your first quiz!'}</p>
            </div>
          ) : (
            filteredQuizzes.map((quiz) => {
              const thumbnailUrl = quiz.thumbnail?.url
                ? (quiz.thumbnail.url.startsWith('http')
                  ? quiz.thumbnail.url
                  : `http://localhost:1337${quiz.thumbnail.url}`)
                : null;

              return (
                <div key={quiz.id} className="quiz-card">
                  {thumbnailUrl && (
                    <div className="quiz-thumbnail">
                      <img src={thumbnailUrl} alt={quiz.title} />
                    </div>
                  )}
                  <div className="quiz-content">
                    <div className="quiz-header">
                      <h3>{quiz.title}</h3>
                    </div>
                    <p className="quiz-description">{quiz.description || 'No description'}</p>
                    <div className="quiz-footer">
                      {quiz.category && (
                        <span className="category-badge">
                          {quiz.category.name}
                        </span>
                      )}
                      <div className="quiz-actions">
                        <button className="edit-btn" onClick={() => openEditModal(quiz)}>
                          Edit
                        </button>
                        {canDelete && (
                          <button className="delete-btn" onClick={() => handleDelete(quiz)}>
                            Delete
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Create/Edit Modal */}
        {modalOpen && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content quiz-modal" onClick={(e) => e.stopPropagation()}>
              <h2>{modalMode === 'create' ? 'Create New Quiz' : 'Edit Quiz'}</h2>
              <p className="modal-subtitle">
                Questions are pulled from the question bank based on category and tags
              </p>

              <form onSubmit={handleSubmit}>
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="title">Title *</label>
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      placeholder="e.g., Climate Change Challenge"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="slug">
                      Slug *
                      {modalMode === 'edit' && <small> (cannot be changed)</small>}
                    </label>
                    <input
                      type="text"
                      id="slug"
                      name="slug"
                      value={formData.slug}
                      onChange={handleInputChange}
                      placeholder="climate-change-challenge"
                      disabled={modalMode === 'edit'}
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="description">Description</label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Brief description of what this quiz covers"
                    rows="3"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="thumbnail">
                    Thumbnail Image
                    <small> (optional - displayed on quiz cards)</small>
                  </label>
                  <input
                    type="file"
                    id="thumbnail"
                    accept="image/*"
                    onChange={handleThumbnailChange}
                  />
                  {thumbnailPreview && (
                    <div style={{ marginTop: '1rem' }}>
                      <img
                        src={thumbnailPreview}
                        alt="Thumbnail preview"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          borderRadius: '8px',
                          objectFit: 'cover'
                        }}
                      />
                    </div>
                  )}
                  {!thumbnailPreview && selectedQuiz?.thumbnail?.url && (
                    <div style={{ marginTop: '1rem' }}>
                      <img
                        src={`http://localhost:1337${selectedQuiz.thumbnail.url}`}
                        alt="Current thumbnail"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          borderRadius: '8px',
                          objectFit: 'cover'
                        }}
                      />
                      <small style={{ display: 'block', marginTop: '0.5rem', color: '#6b7280' }}>
                        Current thumbnail (upload a new file to replace)
                      </small>
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="category">
                    Category *
                    <small> (determines which questions to pull)</small>
                  </label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>
                    Tags
                    <small> (optional - further filters questions)</small>
                    <button
                      type="button"
                      onClick={() => setShowNewTagInput(!showNewTagInput)}
                      style={{
                        marginLeft: '1rem',
                        padding: '0.25rem 0.75rem',
                        background: showNewTagInput ? '#6b7280' : '#10b981',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        fontSize: '0.85rem',
                        cursor: 'pointer'
                      }}
                    >
                      {showNewTagInput ? 'Cancel' : '+ New Tag'}
                    </button>
                  </label>

                  {showNewTagInput && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', padding: '1rem', background: '#f0f9ff', border: '2px solid #3b82f6', borderRadius: '8px', marginBottom: '1rem' }}>
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>New Tag Name:</label>
                      <input
                        type="text"
                        placeholder="Enter new tag name"
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        style={{ padding: '0.75rem', border: '1px solid #3b82f6', borderRadius: '6px', fontSize: '1rem' }}
                      />
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>
                        Category: {categories.find(c => c.id === parseInt(formData.category))?.name || 'Please select a category first'}
                      </label>
                      <small style={{ color: '#6b7280', fontSize: '0.875rem' }}>Tag will be created under the currently selected category</small>
                      <button type="button" onClick={handleCreateNewTag} style={{ padding: '0.75rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '6px', fontSize: '1rem', fontWeight: 'bold', cursor: 'pointer' }}>
                        Create Tag
                      </button>
                    </div>
                  )}

                  <div className="tags-checkbox-list">
                    {formData.category ? (
                      (() => {
                        const categoryTags = tags.filter(tag => tag.category?.id === parseInt(formData.category));
                        return categoryTags.length > 0 ? (
                          categoryTags.map((tag) => (
                            <label key={tag.id} className="tag-checkbox-item">
                              <input
                                type="checkbox"
                                value={tag.id}
                                checked={formData.tags.includes(String(tag.id))}
                                onChange={() => handleTagCheckboxChange(tag.id)}
                              />
                              <span>{tag.name}</span>
                            </label>
                          ))
                        ) : (
                          <p style={{ color: '#6b7280', fontSize: '0.9rem', padding: '0.5rem' }}>
                            No tags available for this category. Create a new tag above.
                          </p>
                        );
                      })()
                    ) : (
                      <p style={{ color: '#6b7280', fontSize: '0.9rem', padding: '0.5rem' }}>
                        Please select a category first to see available tags.
                      </p>
                    )}
                  </div>
                  {formData.tags.length > 0 && (
                    <small>{formData.tags.length} tag(s) selected</small>
                  )}
                </div>

                {error && <div className="modal-error">{error}</div>}

                <div className="modal-actions">
                  <button type="button" className="cancel-btn" onClick={closeModal}>
                    Cancel
                  </button>
                  <button type="submit" className="submit-btn" disabled={submitting}>
                    {submitting ? 'Saving...' : (modalMode === 'create' ? 'Create Quiz' : 'Update Quiz')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default ManageQuizzes;
