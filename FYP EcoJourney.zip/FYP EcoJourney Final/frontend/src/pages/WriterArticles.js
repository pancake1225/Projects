import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getArticles, createArticle, updateArticle, getCategories } from '../services/api';
import WriterNav from '../components/WriterNav';
import './ManageArticles.css';

function WriterArticles() {
  const { token } = useAuth();
  const [articles, setArticles] = useState([]);
  const [categories, setCategories] = useState([]);
  const [tags, setTags] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create');
  const [selectedArticle, setSelectedArticle] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  const [formData, setFormData] = useState({
    title: '',
    slug: '',
    description: '',
    body: '',
    tags: [],
    category: null,
  });
  const [thumbnailFile, setThumbnailFile] = useState(null);
  const [thumbnailPreview, setThumbnailPreview] = useState(null);
  const [videoFiles, setVideoFiles] = useState([]);
  const [showNewTagInput, setShowNewTagInput] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagCategory, setNewTagCategory] = useState('');

  useEffect(() => {
    fetchArticles();
    fetchCategories();
    fetchTags();
  }, []);

  const fetchCategories = async () => {
    try {
      const response = await getCategories();
      setCategories(response.data.data || []);
    } catch (err) {
      console.error('Failed to fetch categories:', err);
    }
  };

  const fetchTags = async () => {
    try {
      const response = await fetch('http://localhost:1337/api/tags?populate=category', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await response.json();
      setTags(data.data || []);
    } catch (err) {
      console.error('Failed to fetch tags:', err);
    }
  };

  const fetchArticles = async () => {
    try {
      setLoading(true);
      const response = await getArticles();
      setArticles(response.data.data || []);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch articles:', err);
      setError('Failed to load articles. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const openCreateModal = () => {
    setModalMode('create');
    setFormData({
      title: '',
      slug: '',
      description: '',
      body: '',
      tags: [],
      category: null,
    });
    setModalOpen(true);
  };

  const openEditModal = (article) => {
    setModalMode('edit');
    setSelectedArticle(article);

    // Convert body blocks to plain text for editing
    let bodyText = '';
    if (article.body && Array.isArray(article.body)) {
      bodyText = article.body.map(block => {
        if (block.type === 'paragraph' && block.children) {
          return block.children.map(child => child.text || '').join('');
        }
        return '';
      }).join('\n\n');
    } else if (typeof article.body === 'string') {
      bodyText = article.body;
    }

    // Parse tags from string to array
    const tagArray = article.tags ? article.tags.split(',').map(t => t.trim()).filter(t => t) : [];

    setFormData({
      title: article.title || '',
      slug: article.slug || '',
      description: article.description || '',
      body: bodyText,
      tags: tagArray,
      category: article.category?.id || null,
    });
    setModalOpen(true);
  };

  const closeModal = () => {
    setModalOpen(false);
    setSelectedArticle(null);
    setThumbnailFile(null);
    setThumbnailPreview(null);
    setVideoFiles([]);
    setShowNewTagInput(false);
    setNewTagName('');
    setNewTagCategory('');
    setError(null);
  };

  const handleThumbnailChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        setError('Please select an image file');
        return;
      }
      setThumbnailFile(file);
      setThumbnailPreview(URL.createObjectURL(file));
    }
  };

  const uploadThumbnail = async (file) => {
    const formData = new FormData();
    formData.append('files', file);

    const response = await fetch('http://localhost:1337/api/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to upload thumbnail');
    }

    const data = await response.json();
    return data[0].id;
  };

  const handleVideoChange = (e) => {
    const files = Array.from(e.target.files);
    const videoFiles = files.filter(file => file.type.startsWith('video/'));
    if (videoFiles.length !== files.length) {
      setError('Please select only video files');
      return;
    }
    setVideoFiles(videoFiles);
  };

  const uploadVideos = async (files) => {
    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);
    });

    const response = await fetch('http://localhost:1337/api/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error('Failed to upload videos');
    }

    const data = await response.json();
    return data.map(file => file.id);
  };

  const handleTagCheckboxChange = (tagId) => {
    setFormData(prev => {
      const tagIdStr = String(tagId);
      const isSelected = prev.tags.includes(tagIdStr);
      const newTags = isSelected
        ? prev.tags.filter(id => id !== tagIdStr)
        : [...prev.tags, tagIdStr];
      return {
        ...prev,
        tags: newTags
      };
    });
  };

  const handleCreateNewTag = async () => {
    if (!newTagName.trim()) {
      setError('Tag name cannot be empty');
      return;
    }

    const categoryToUse = newTagCategory || formData.category;
    if (!categoryToUse) {
      setError('Please select a category first');
      return;
    }

    try {
      const response = await fetch('http://localhost:1337/api/tags', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          data: {
            name: newTagName,
            category: parseInt(categoryToUse),
            publishedAt: new Date().toISOString(),
          }
        })
      });

      if (!response.ok) throw new Error('Failed to create tag');

      const data = await response.json();
      const newTag = data.data;

      await fetchTags();

      setFormData(prev => ({
        ...prev,
        tags: [...prev.tags, String(newTag.id)]
      }));

      setSuccessMessage(`Tag "${newTagName}" created successfully!`);
      setShowNewTagInput(false);
      setNewTagName('');
      setNewTagCategory('');
      setError(null);
    } catch (err) {
      console.error('Failed to create tag:', err);
      setError('Failed to create tag. Please try again.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));

    // Auto-generate slug from title
    if (name === 'title' && modalMode === 'create') {
      const slug = value
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setFormData(prev => ({
        ...prev,
        slug
      }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setSuccessMessage('');

    if (!formData.title || !formData.slug || !formData.body) {
      setError('Title, slug, and body are required');
      return;
    }

    try {
      setSubmitting(true);

      // Upload thumbnail if provided
      let thumbnailId = null;
      if (thumbnailFile) {
        thumbnailId = await uploadThumbnail(thumbnailFile);
      }

      // Upload videos if provided
      let videoIds = [];
      if (videoFiles.length > 0) {
        videoIds = await uploadVideos(videoFiles);
      }

      // Prepare data for Strapi
      // Convert plain text to blocks format
      const bodyBlocks = formData.body.split('\n').filter(line => line.trim()).map(line => ({
        type: 'paragraph',
        children: [{ type: 'text', text: line }]
      }));

      const submitData = {
        title: formData.title,
        description: formData.description,
        body: bodyBlocks,
        tags: formData.tags.join(', '), // Convert array back to string for Strapi
      };

      // Add thumbnail if uploaded
      if (thumbnailId) {
        submitData.thumbnail = thumbnailId;
      }

      // Add videos if uploaded
      if (videoIds.length > 0) {
        submitData.media = videoIds;
      }

      // Add slug only for create (UID fields can't be updated)
      if (modalMode === 'create') {
        submitData.slug = formData.slug;
      }

      // Add category if selected
      if (formData.category) {
        submitData.category = formData.category;
      }

      if (modalMode === 'create') {
        await createArticle(submitData, token);
        setSuccessMessage('Article created successfully!');
      } else {
        await updateArticle(selectedArticle.documentId, submitData, token);
        setSuccessMessage('Article updated successfully!');
      }

      await fetchArticles();
      closeModal();
    } catch (err) {
      console.error('Failed to save article:', err);
      setError(err.response?.data?.error?.message || 'Failed to save article');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <>
      <WriterNav />
      <div className="admin-container">
        <div className="admin-header">
          <h1>Manage Articles</h1>
          <button onClick={openCreateModal} className="create-btn">
            + Create New Article
          </button>
        </div>

        {error && <div className="error-message">{error}</div>}
        {successMessage && <div className="success-message">{successMessage}</div>}

        {loading ? (
          <div className="loading">Loading articles...</div>
        ) : (
          <div className="articles-table">
            <table>
              <thead>
                <tr>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Slug</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {articles.map((article) => (
                  <tr key={article.id}>
                    <td>{article.title}</td>
                    <td>{article.category?.name || 'Uncategorized'}</td>
                    <td>{article.slug}</td>
                    <td>
                      <button
                        onClick={() => openEditModal(article)}
                        className="edit-btn-small"
                      >
                        Edit
                      </button>
                      {/* Delete button hidden for writers */}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Modal - Same as ManageArticles but without delete */}
        {modalOpen && (
          <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content" onClick={(e) => e.stopPropagation()}>
              <div className="modal-header">
                <h2>{modalMode === 'create' ? 'Create New Article' : 'Edit Article'}</h2>
                <button className="modal-close" onClick={closeModal}>×</button>
              </div>

              <form onSubmit={handleSubmit} className="modal-form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="title">Title *</label>
                    <input
                      type="text"
                      id="title"
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      placeholder="e.g., Understanding Climate Change"
                      required
                    />
                  </div>

                  <div className="form-group">
                    <label htmlFor="slug">
                      Slug *
                      {modalMode === 'edit' && <small> (cannot be changed)</small>}
                    </label>
                    <input
                      type="text"
                      id="slug"
                      name="slug"
                      value={formData.slug}
                      onChange={handleInputChange}
                      placeholder="understanding-climate-change"
                      disabled={modalMode === 'edit'}
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="description">Description</label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    placeholder="Brief description of the article"
                    rows="2"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="thumbnail">
                    Thumbnail Image
                    <small> (optional - displayed on article cards)</small>
                  </label>
                  <input
                    type="file"
                    id="thumbnail"
                    accept="image/*"
                    onChange={handleThumbnailChange}
                  />
                  {thumbnailPreview && (
                    <div style={{ marginTop: '1rem' }}>
                      <img
                        src={thumbnailPreview}
                        alt="Thumbnail preview"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          borderRadius: '8px',
                          objectFit: 'cover'
                        }}
                      />
                    </div>
                  )}
                  {!thumbnailPreview && selectedArticle?.thumbnail?.url && (
                    <div style={{ marginTop: '1rem' }}>
                      <img
                        src={`http://localhost:1337${selectedArticle.thumbnail.url}`}
                        alt="Current thumbnail"
                        style={{
                          maxWidth: '200px',
                          maxHeight: '200px',
                          borderRadius: '8px',
                          objectFit: 'cover'
                        }}
                      />
                      <small style={{ display: 'block', marginTop: '0.5rem', color: '#6b7280' }}>
                        Current thumbnail (upload a new file to replace)
                      </small>
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="videos">
                    Videos
                    <small> (optional - embed videos in article)</small>
                  </label>
                  <input
                    type="file"
                    id="videos"
                    accept="video/*"
                    multiple
                    onChange={handleVideoChange}
                  />
                  {videoFiles.length > 0 && (
                    <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', color: '#6b7280' }}>
                      Selected: {videoFiles.map(f => f.name).join(', ')}
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label htmlFor="body">Body Content *</label>
                  <textarea
                    id="body"
                    name="body"
                    value={formData.body}
                    onChange={handleInputChange}
                    placeholder="Article content"
                    rows="10"
                    required
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="category">Category</label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category || ''}
                    onChange={handleInputChange}
                  >
                    <option value="">Select a category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="form-group">
                  <label>
                    Tags
                    <small> (optional - select tags from the chosen category)</small>
                    <button
                      type="button"
                      onClick={() => setShowNewTagInput(!showNewTagInput)}
                      style={{
                        marginLeft: '1rem',
                        padding: '0.25rem 0.75rem',
                        background: showNewTagInput ? '#6b7280' : '#10b981',
                        color: 'white',
                        border: 'none',
                        borderRadius: '6px',
                        fontSize: '0.85rem',
                        cursor: 'pointer'
                      }}
                    >
                      {showNewTagInput ? 'Cancel' : '+ New Tag'}
                    </button>
                  </label>

                  {showNewTagInput && (
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', padding: '1rem', background: '#f0f9ff', border: '2px solid #3b82f6', borderRadius: '8px', marginBottom: '1rem' }}>
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>New Tag Name:</label>
                      <input
                        type="text"
                        placeholder="Enter new tag name"
                        value={newTagName}
                        onChange={(e) => setNewTagName(e.target.value)}
                        style={{ padding: '0.75rem', border: '1px solid #3b82f6', borderRadius: '6px', fontSize: '1rem' }}
                      />
                      <label style={{ fontWeight: 'bold', color: '#1e40af' }}>
                        Category: {categories.find(c => c.id === parseInt(formData.category))?.name}
                      </label>
                      <small style={{ color: '#6b7280', fontSize: '0.875rem' }}>Tag will be created under the currently selected category</small>
                      <button type="button" onClick={handleCreateNewTag} style={{ padding: '0.75rem', background: '#10b981', color: 'white', border: 'none', borderRadius: '6px', fontSize: '1rem', fontWeight: 'bold', cursor: 'pointer' }}>
                        Create Tag
                      </button>
                    </div>
                  )}

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', maxHeight: '200px', overflowY: 'auto', padding: '0.5rem', border: '1px solid #e5e7eb', borderRadius: '6px' }}>
                    {formData.category ? (
                      (() => {
                        const categoryTags = tags.filter(tag => tag.category?.id === parseInt(formData.category));
                        return categoryTags.length > 0 ? (
                          categoryTags.map(tag => (
                            <label key={tag.id} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', cursor: 'pointer', borderRadius: '4px', background: formData.tags.includes(String(tag.id)) ? '#e0f2fe' : 'transparent' }}>
                              <input
                                type="checkbox"
                                checked={formData.tags.includes(String(tag.id))}
                                onChange={() => handleTagCheckboxChange(tag.id)}
                              />
                              <span>{tag.name}</span>
                            </label>
                          ))
                        ) : (
                          <p style={{ color: '#6b7280', fontSize: '0.9rem', padding: '0.5rem' }}>
                            No tags available for this category. Create a new tag above.
                          </p>
                        );
                      })()
                    ) : (
                      <p style={{ color: '#6b7280', fontSize: '0.9rem', padding: '0.5rem' }}>
                        Please select a category first to see available tags.
                      </p>
                    )}
                  </div>
                </div>

                {error && <div className="modal-error">{error}</div>}

                <div className="modal-actions">
                  <button type="button" className="cancel-btn" onClick={closeModal}>
                    Cancel
                  </button>
                  <button type="submit" className="submit-btn" disabled={submitting}>
                    {submitting ? 'Saving...' : (modalMode === 'create' ? 'Create Article' : 'Update Article')}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default WriterArticles;
