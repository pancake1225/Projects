/**
 * Leaderboard Page Component
 *
 * Displays a ranked leaderboard of all users based on their quiz points.
 * Features:
 * - Podium display for top 3 users
 * - Searchable table of all ranked users
 * - Filtering by category, tag, and specific quiz
 * - Current user highlighting with "You" badge
 * - Auto-refresh every 5 seconds for real-time updates
 *
 * Data Source:
 * ------------
 * Fetches from /api/quiz-results/leaderboard (public endpoint)
 * Returns pre-aggregated leaderboard data and raw results for client-side filtering
 *
 * Aggregation Logic:
 * ------------------
 * 1. Backend sums up points for each user across all their quiz results
 * 2. Users are sorted by total points (highest first)
 * 3. Rank is assigned based on position
 * 4. When filters are applied, client re-aggregates from raw results
 */

import React, { useEffect, useState } from 'react';
import { getUserStats } from '../utils/storage';
import { useAuth } from '../context/AuthContext';
import './Leaderboard.css';

// Strapi API base URL
const API_URL = 'http://localhost:1337/api';

function Leaderboard() {
  // Get current user from AuthContext (for highlighting user's own row)
  const { user } = useAuth();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [leaderboardData, setLeaderboardData] = useState([]);   // Aggregated leaderboard
  const [loading, setLoading] = useState(true);                  // Loading state
  const [error, setError] = useState('');                        // Error message
  const [searchQuery, setSearchQuery] = useState('');            // Username search
  const [filterCategory, setFilterCategory] = useState('');      // Category filter
  const [filterTag, setFilterTag] = useState('');                // Tag filter
  const [filterQuiz, setFilterQuiz] = useState('');              // Specific quiz filter
  const [categories, setCategories] = useState([]);              // Available categories
  const [tags, setTags] = useState([]);                          // Available tags
  const [quizzes, setQuizzes] = useState([]);                    // Available quizzes

  // =========================================================================
  // INITIAL DATA FETCH
  // Load filter options (categories, tags, quizzes) on mount
  // =========================================================================
  useEffect(() => {
    fetchCategories();
    fetchTags();
    fetchQuizzes();
  }, []);

  // =========================================================================
  // LEADERBOARD DATA FETCH + AUTO-REFRESH
  // Fetches leaderboard and sets up 5-second polling
  // Re-fetches when filters change
  // =========================================================================
  useEffect(() => {
    fetchLeaderboard();

    // Auto-refresh every 5 seconds for real-time leaderboard updates
    // This ensures users see the latest scores without manual refresh
    const intervalId = setInterval(() => {
      fetchLeaderboard();
    }, 5000);

    // Cleanup: clear interval when component unmounts or filters change
    return () => clearInterval(intervalId);
  }, [filterCategory, filterTag, filterQuiz]);  // Re-fetch when filters change

  /**
   * Fetch Categories
   * Loads all categories for the filter dropdown
   */
  const fetchCategories = async () => {
    try {
      const response = await fetch(`${API_URL}/categories`);
      if (response.ok) {
        const data = await response.json();
        setCategories(data.data || []);
      }
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  /**
   * Fetch Tags
   * Loads all tags with their category associations for filtering
   */
  const fetchTags = async () => {
    try {
      // populate=category includes the related category data
      const response = await fetch(`${API_URL}/tags?populate=category`);
      if (response.ok) {
        const data = await response.json();
        setTags(data.data || []);
      }
    } catch (err) {
      console.error('Error fetching tags:', err);
    }
  };

  /**
   * Fetch Quizzes
   * Loads all quizzes for the filter dropdown and for matching results
   */
  const fetchQuizzes = async () => {
    try {
      // populate=* includes all related data (category, tags, etc.)
      const response = await fetch(`${API_URL}/quizzes?populate=*`);
      if (response.ok) {
        const data = await response.json();
        setQuizzes(data.data || []);
      }
    } catch (err) {
      console.error('Error fetching quizzes:', err);
    }
  };

  /**
   * Fetch Leaderboard Data
   *
   * Main function to load and process leaderboard data.
   * Handles both pre-aggregated data (no filters) and
   * client-side re-aggregation (when filters are applied).
   *
   * Flow:
   * 1. Fetch from /quiz-results/leaderboard endpoint
   * 2. If filters applied: re-aggregate from raw results
   * 3. If no filters: use pre-aggregated data from backend
   */
  const fetchLeaderboard = async () => {
    try {
      // Fetch leaderboard from custom endpoint (public, no auth needed)
      const response = await fetch(`${API_URL}/quiz-results/leaderboard`);

      if (response.ok) {
        const data = await response.json();
        console.log('Leaderboard API response:', data);

        // Check if we have valid data
        if (data && data.data && data.data.length > 0) {
          // ---------------------------------------------------------------
          // CLIENT-SIDE FILTERING
          // When filters are applied, we re-aggregate from raw results
          // ---------------------------------------------------------------
          if (filterQuiz || filterCategory || filterTag) {
            // Start with all raw quiz results from backend
            let filteredResults = data.rawResults || [];

            // Apply quiz filter (specific quiz selected)
            if (filterQuiz) {
              filteredResults = filteredResults.filter(result =>
                // Handle both id and documentId formats
                result.quiz?.id === parseInt(filterQuiz) || result.quiz?.documentId === filterQuiz
              );
            } else if (filterCategory || filterTag) {
              // Apply category/tag filter (need to check quiz associations)
              filteredResults = filteredResults.filter(result => {
                // Skip results without quiz data
                if (!result.quiz) return false;

                // Find the full quiz object to check category/tags
                const quiz = quizzes.find(q => q.id === result.quiz.id || q.documentId === result.quiz.documentId);
                if (!quiz) return false;

                // Check category match
                if (filterCategory && quiz.category?.id !== parseInt(filterCategory)) {
                  return false;
                }

                // Check tag match (quiz can have multiple tags)
                if (filterTag && !quiz.tags?.some(t => t.id === parseInt(filterTag))) {
                  return false;
                }

                return true;
              });
            }

            // ---------------------------------------------------------------
            // RE-AGGREGATE FILTERED RESULTS
            // Same logic as backend, but on filtered data
            // ---------------------------------------------------------------
            const userScores = {};  // Object to group results by user

            filteredResults.forEach((result) => {
              const userId = result.userId;
              const username = result.username;
              // Use points (includes difficulty multiplier) or fallback to score
              const pointsValue = result.points || result.score || 0;

              // Only process if we have valid user data
              if (userId && username) {
                // Initialize user entry if first result for this user
                if (!userScores[userId]) {
                  userScores[userId] = {
                    id: userId,
                    username: username,
                    points: 0,
                    quizzesTaken: 0
                  };
                }
                // Add points and increment quiz count
                userScores[userId].points += pointsValue;
                userScores[userId].quizzesTaken += 1;
              }
            });

            // Convert to sorted array with ranks (handling ties)
            const sortedUsers = Object.values(userScores)
              .filter((u) => u.points > 0)           // Remove users with 0 points
              .sort((a, b) => b.points - a.points);  // Sort by points (descending)

            // Assign ranks with tie handling
            let currentRank = 1;
            const leaderboard = sortedUsers.map((u, index) => {
              if (index > 0 && u.points < sortedUsers[index - 1].points) {
                currentRank = index + 1;
              }
              const hasSamePointsAsPrev = index > 0 && u.points === sortedUsers[index - 1].points;
              const hasSamePointsAsNext = index < sortedUsers.length - 1 && u.points === sortedUsers[index + 1].points;
              const isTied = hasSamePointsAsPrev || hasSamePointsAsNext;
              return { ...u, rank: currentRank, isTied };
            });

            setLeaderboardData(leaderboard);
          } else {
            // No filters applied - use pre-aggregated data from backend
            // This is more efficient as aggregation was done server-side
            setLeaderboardData(data.data);
          }
        } else {
          // No quiz results found
          console.log('No quiz results found in database');
          setLeaderboardData([]);
        }
      } else {
        // API error
        const errorText = await response.text();
        console.error('Leaderboard API error:', response.status, errorText);
        setLeaderboardData([]);
      }
    } catch (err) {
      console.error('Error fetching leaderboard:', err);
      setLeaderboardData([]);
    } finally {
      setLoading(false);
    }
  };

  // =========================================================================
  // LOADING STATE
  // =========================================================================
  if (loading) {
    return (
      <div className="leaderboard-page">
        <div className="leaderboard-loading">Loading leaderboard...</div>
      </div>
    );
  }

  // =========================================================================
  // ERROR STATE
  // =========================================================================
  if (error) {
    return (
      <div className="leaderboard-page">
        <div className="leaderboard-error">{error}</div>
      </div>
    );
  }

  // =========================================================================
  // FILTER DATA BY SEARCH QUERY
  // Client-side filtering by username (case-insensitive)
  // =========================================================================
  const filteredData = leaderboardData.filter((entry) =>
    entry.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Recalculate display ranks for search results
  // (so searching for "john" shows John as #1 if he's the only result)
  const filteredDataWithRanks = filteredData.map((entry, index) => ({
    ...entry,
    displayRank: index + 1
  }));

  // =========================================================================
  // RENDER
  // =========================================================================
  return (
    <div className="leaderboard-page">
      {/* ================================================================
          HERO SECTION - Page title and description
          ================================================================ */}
      <div className="leaderboard-hero">
        <div className="leaderboard-hero-content">
          <h1 className="leaderboard-hero-title">🏆 Leaderboard</h1>
          <p className="leaderboard-hero-text">
            Top performers in sustainability quizzes
          </p>
        </div>
      </div>

      <div className="leaderboard-container">
        {/* ================================================================
            SEARCH BAR - Filter by username
            ================================================================ */}
        <div className="leaderboard-search">
          <input
            type="text"
            placeholder="Search for username..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="leaderboard-search-input"
          />
          {/* Clear button - only shown when search has text */}
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="leaderboard-search-clear"
            >
              ✕
            </button>
          )}
        </div>

        {/* ================================================================
            FILTER DROPDOWNS - Category, Tag, Quiz filters
            ================================================================ */}
        <div className="leaderboard-filters">
          {/* Category Filter */}
          <select
            value={filterCategory}
            onChange={(e) => {
              setFilterCategory(e.target.value);
              setFilterTag('');    // Clear tag when category changes
              setFilterQuiz('');   // Clear quiz filter
            }}
            className="leaderboard-filter-select"
          >
            <option value="">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {cat.name}
              </option>
            ))}
          </select>

          {/* Tag Filter - Only enabled when category is selected */}
          <select
            value={filterTag}
            onChange={(e) => {
              setFilterTag(e.target.value);
              setFilterQuiz('');  // Clear quiz filter
            }}
            className="leaderboard-filter-select"
            disabled={!filterCategory}  // Disabled until category selected
          >
            <option value="">
              {filterCategory ? 'All Tags' : 'All Tags (Select category first)'}
            </option>
            {/* Only show tags for selected category */}
            {tags
              .filter(tag => !filterCategory || tag.category?.id === parseInt(filterCategory))
              .map(tag => (
                <option key={tag.id} value={tag.id}>
                  {tag.name}
                </option>
              ))}
          </select>

          {/* Quiz Filter - Mutually exclusive with category/tag filters */}
          <select
            value={filterQuiz}
            onChange={(e) => {
              setFilterQuiz(e.target.value);
              setFilterCategory('');  // Clear category/tag when quiz selected
              setFilterTag('');
            }}
            className="leaderboard-filter-select"
          >
            <option value="">All Quizzes</option>
            {quizzes.map(quiz => (
              <option key={quiz.id} value={quiz.id}>
                {quiz.title}
              </option>
            ))}
          </select>

          {/* Clear Filters Button - Only shown when filters are active */}
          {(filterCategory || filterTag || filterQuiz) && (
            <button
              onClick={() => {
                setFilterCategory('');
                setFilterTag('');
                setFilterQuiz('');
              }}
              className="leaderboard-clear-filters-btn"
            >
              Clear Filters
            </button>
          )}
        </div>

        {/* ================================================================
            EMPTY STATE - No data or no search results
            ================================================================ */}
        {filteredData.length === 0 ? (
          <div className="no-leaderboard-data">
            <p>{searchQuery ? `No users found matching "${searchQuery}"` : 'No quiz scores yet. Be the first to take a quiz!'}</p>
          </div>
        ) : (
          <>
            {/* ==============================================================
                PODIUM - Top 3 users visual display
                Only shown when not searching and at least 1 user exists
                Handles ties: shows ALL tied users and "N/A" when position doesn't exist
                ============================================================== */}
            {!searchQuery && leaderboardData.length >= 1 && (() => {
              // Find ALL users for each podium position (handles ties)
              const firstPlaceUsers = leaderboardData.filter(u => u.rank === 1);
              const secondPlaceUsers = leaderboardData.filter(u => u.rank === 2);
              const thirdPlaceUsers = leaderboardData.filter(u => u.rank === 3);

              // Check if positions are tied
              const firstPlaceTied = firstPlaceUsers.length > 1;
              const secondPlaceTied = secondPlaceUsers.length > 1;
              const thirdPlaceTied = thirdPlaceUsers.length > 1;

              // Get points for each position (all tied users have same points)
              const firstPlacePoints = firstPlaceUsers[0]?.points;
              const secondPlacePoints = secondPlaceUsers[0]?.points;
              const thirdPlacePoints = thirdPlaceUsers[0]?.points;

              return (
                <div className="podium">
                  {/* 2nd Place - Left side */}
                  <div className="podium-item second">
                    <div className="podium-medal">🥈</div>
                    <div className="podium-rank">{secondPlaceUsers.length > 0 ? (secondPlaceTied ? 'T-2' : '2nd') : 'N/A'}</div>
                    <div className="podium-username podium-username-list">
                      {secondPlaceUsers.length > 0
                        ? secondPlaceUsers.map((u, i) => (
                            <span key={u.id}>{u.username}{i < secondPlaceUsers.length - 1 ? ', ' : ''}</span>
                          ))
                        : '-'}
                    </div>
                    <div className="podium-points">{secondPlaceUsers.length > 0 ? `${secondPlacePoints} pts` : ''}</div>
                    <div className="podium-bar second-bar"></div>
                  </div>

                  {/* 1st Place - Center (tallest) */}
                  <div className="podium-item first">
                    <div className="podium-medal">🥇</div>
                    <div className="podium-rank">{firstPlaceTied ? 'T-1' : '1st'}</div>
                    <div className="podium-username podium-username-list">
                      {firstPlaceUsers.map((u, i) => (
                        <span key={u.id}>{u.username}{i < firstPlaceUsers.length - 1 ? ', ' : ''}</span>
                      ))}
                    </div>
                    <div className="podium-points">{firstPlacePoints ? `${firstPlacePoints} pts` : ''}</div>
                    <div className="podium-bar first-bar"></div>
                  </div>

                  {/* 3rd Place - Right side */}
                  <div className="podium-item third">
                    <div className="podium-medal">🥉</div>
                    <div className="podium-rank">{thirdPlaceUsers.length > 0 ? (thirdPlaceTied ? 'T-3' : '3rd') : 'N/A'}</div>
                    <div className="podium-username podium-username-list">
                      {thirdPlaceUsers.length > 0
                        ? thirdPlaceUsers.map((u, i) => (
                            <span key={u.id}>{u.username}{i < thirdPlaceUsers.length - 1 ? ', ' : ''}</span>
                          ))
                        : '-'}
                    </div>
                    <div className="podium-points">{thirdPlaceUsers.length > 0 ? `${thirdPlacePoints} pts` : ''}</div>
                    <div className="podium-bar third-bar"></div>
                  </div>
                </div>
              );
            })()}

            {/* ==============================================================
                LEADERBOARD TABLE - Full ranked list
                ============================================================== */}
            <div className="leaderboard-table-container">
              {/* Search results count */}
              {searchQuery && (
                <div className="leaderboard-search-info">
                  Showing {filteredData.length} result{filteredData.length !== 1 ? 's' : ''}
                </div>
              )}

              <table className="leaderboard-table">
                <thead>
                  <tr>
                    <th>Rank</th>
                    <th>User</th>
                    <th>Points</th>
                    <th>Quizzes Taken</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredDataWithRanks.map((u) => {
                    // Check if this row is the current logged-in user
                    // Used for highlighting with "You" badge
                    const isCurrentUser = user && u.id === user.id;

                    // CSS classes for styling
                    // topClass: Special styling for top 3 (gold, silver, bronze)
                    // currentUserClass: Green highlight for current user
                    const topClass = !searchQuery && u.rank <= 3 ? `top-${u.rank}` : '';
                    const currentUserClass = isCurrentUser ? 'current-user' : '';

                    return (
                      <tr key={u.id} className={`${topClass} ${currentUserClass}`.trim()}>
                        {/* Rank column with medal emoji for top 3, T- prefix for ties */}
                        <td className="rank-col">
                          {!searchQuery && u.rank === 1 && '🥇 '}
                          {!searchQuery && u.rank === 2 && '🥈 '}
                          {!searchQuery && u.rank === 3 && '🥉 '}
                          {u.isTied ? `T-${u.rank}` : u.rank}
                        </td>

                        {/* Username column with "You" badge for current user */}
                        <td className="user-col">
                          {u.username}
                          {isCurrentUser && <span className="you-badge">You</span>}
                        </td>

                        {/* Points column */}
                        <td className="points-col">{u.points}</td>

                        {/* Quizzes taken column */}
                        <td className="quizzes-col">{u.quizzesTaken}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default Leaderboard;
