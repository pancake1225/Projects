/**
 * Articles Page Component
 *
 * Displays a paginated, filterable list of all sustainability articles.
 * Users can browse, search, and filter articles by category and tags.
 *
 * Features:
 * ---------
 * 1. Hero section with page title and description
 * 2. Sidebar with search and filter options
 * 3. Responsive grid layout for article cards
 * 4. Multi-criteria filtering (search + category + tags)
 * 5. Pagination (6 articles per page)
 *
 * Data Source:
 * ------------
 * - Articles: /api/articles?populate=*
 * - Categories: /api/categories?populate=*
 * - Tags: /api/tags?populate=category (includes category relation for filtering)
 *
 * Filter Logic:
 * -------------
 * 1. Search: Matches title OR description (case-insensitive)
 * 2. Category: Exact match on category slug (or "ALL" for no filter)
 * 3. Tags: Matches ANY selected tag (OR logic, not AND)
 * All three filters are combined with AND logic.
 */

import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './Articles.css';

// Strapi API base URL
const API_URL = 'http://localhost:1337/api';

// Number of articles to show per page
const ITEMS_PER_PAGE = 6;

function Articles() {
  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [articles, setArticles] = useState([]);         // All articles from API
  const [categories, setCategories] = useState([]);     // Categories for filter dropdown
  const [tags, setTags] = useState([]);                 // Tags for filter pills
  const [search, setSearch] = useState('');             // Search query text
  const [categoryFilter, setCategoryFilter] = useState('ALL');  // Selected category slug
  const [selectedTags, setSelectedTags] = useState([]); // Array of selected tag names
  const [page, setPage] = useState(1);                  // Current pagination page
  const [loading, setLoading] = useState(true);         // Loading state

  // =========================================================================
  // INITIAL DATA FETCH
  // Loads articles, categories, and tags on component mount
  // =========================================================================
  useEffect(() => {
    fetchData();
  }, []);

  /**
   * Fetch All Data
   *
   * Fetches articles, categories, and tags from Strapi API.
   * All three are fetched in sequence (could be parallelized with Promise.all).
   *
   * populate=* includes all related data (category, tags, thumbnail, etc.)
   * populate=category on tags allows us to filter tags by category
   */
  const fetchData = async () => {
    try {
      // Fetch all articles with their relations (category, tags, thumbnail)
      const articlesRes = await fetch(`${API_URL}/articles?populate=*`);
      const articlesData = await articlesRes.json();
      setArticles(articlesData.data || []);

      // Fetch all categories for the filter sidebar
      const categoriesRes = await fetch(`${API_URL}/categories?populate=*`);
      const categoriesData = await categoriesRes.json();
      setCategories(categoriesData.data || []);

      // Fetch all tags with their category association
      // This allows us to show only relevant tags when a category is selected
      const tagsRes = await fetch(`${API_URL}/tags?populate=category`);
      const tagsData = await tagsRes.json();
      setTags(tagsData.data || []);
    } catch (err) {
      console.error('Error fetching data:', err);
    } finally {
      setLoading(false);
    }
  };

  // =========================================================================
  // CATEGORY-BASED TAG FILTERING
  // Only show tags that belong to the selected category
  // =========================================================================

  // Find the full category object for the selected category filter
  // Handles both Strapi v4 (attributes.slug) and v5 (slug) formats
  const selectedCategory = categories.find(cat =>
    (cat.attributes?.slug || cat.slug) === categoryFilter
  );
  const selectedCategoryId = selectedCategory?.id;

  // Filter tags to only show those belonging to the selected category
  // When no category is selected (ALL), this returns an empty array (no tag pills shown)
  const filteredTags = selectedCategoryId
    ? tags.filter(tag => tag.category?.id === selectedCategoryId)
    : [];

  // =========================================================================
  // ARTICLE FILTERING LOGIC
  // Combines search, category, and tag filters with AND logic
  // =========================================================================
  const filtered = articles.filter((article) => {
    // Extract title and description (handles both Strapi v4 and v5 response formats)
    const title = article.attributes?.title?.toLowerCase() || article.title?.toLowerCase() || '';
    const description = article.attributes?.description?.toLowerCase() || article.description?.toLowerCase() || '';

    // SEARCH FILTER: Match title OR description (case-insensitive)
    const matchesSearch =
      !search ||
      title.includes(search.toLowerCase()) ||
      description.includes(search.toLowerCase());

    // CATEGORY FILTER: Exact match on category slug
    const articleCategory = article.attributes?.category?.data?.attributes?.slug || article.category?.slug;
    const matchesCategory = categoryFilter === 'ALL' || articleCategory === categoryFilter;

    // TAG FILTER: Match ANY selected tag (OR logic within tags)
    // Article tags are stored as comma-separated tag IDs, so convert selected tag names to IDs
    const articleTagIds = (article.attributes?.tags || article.tags || '').split(',').map(t => t.trim());
    const selectedTagIds = selectedTags.map(tagName => {
      const tag = tags.find(t => (t.name || t.attributes?.name) === tagName);
      return tag ? String(tag.id) : '';
    }).filter(Boolean);
    const matchesTags = selectedTagIds.length === 0 || selectedTagIds.some(tagId =>
      articleTagIds.includes(tagId)
    );

    // All filters must pass (AND logic)
    return matchesSearch && matchesCategory && matchesTags;
  });

  // =========================================================================
  // PAGINATION CALCULATION
  // =========================================================================
  const totalPages = Math.max(1, Math.ceil(filtered.length / ITEMS_PER_PAGE));
  // Get articles for current page only
  const shown = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  if (loading) {
    return <div className="articles-loading">Loading articles...</div>;
  }

  return (
    <div className="articles-page">
      {/* Hero Section */}
      <section className="articles-hero">
        <div className="articles-hero-content">
          <div className="articles-hero-eyebrow">Environmental Projects</div>
          <h1 className="articles-hero-title">
            Discover Impactful Environmental Initiatives
          </h1>
          <p className="articles-hero-text">
            Explore curated articles that focus on sustainability, energy, waste reduction, and community impact.
          </p>
        </div>
      </section>

      {/* Content Section */}
      <div className="articles-content-section">
        <div className="articles-content-header">
          <h2>Browse Articles</h2>
          <p>Explore all sustainability articles</p>
        </div>

        <div className="articles-layout">
          {/* Sidebar */}
          <aside className="articles-sidebar">
            <div className="sidebar-title">Filter Articles</div>

            <div className="sidebar-section">
              <div className="sidebar-label">Search</div>
              <input
                className="sidebar-search-input"
                placeholder="Search articles..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </div>

            <div className="sidebar-section">
              <div className="sidebar-label">Category</div>
              <div className="filter-pills">
                <button
                  className={`filter-pill ${categoryFilter === 'ALL' ? 'filter-pill-active' : ''}`}
                  onClick={() => {
                    setCategoryFilter('ALL');
                    setSelectedTags([]);
                    setPage(1);
                  }}
                >
                  All
                </button>
                {categories.map((cat) => {
                  const slug = cat.attributes?.slug || cat.slug;
                  const name = cat.attributes?.name || cat.name;
                  return (
                    <button
                      key={cat.id}
                      className={`filter-pill ${categoryFilter === slug ? 'filter-pill-active' : ''}`}
                      onClick={() => {
                        setCategoryFilter(slug);
                        setSelectedTags([]);
                        setPage(1);
                      }}
                    >
                      {name}
                    </button>
                  );
                })}
              </div>
            </div>

            {filteredTags.length > 0 && (
              <div className="sidebar-section">
                <div className="sidebar-label">Tags</div>
                <div className="filter-pills tags-pills">
                  {filteredTags.map((tag) => {
                    const tagName = tag.name;
                    const isSelected = selectedTags.includes(tagName);
                    return (
                      <button
                        key={tag.id}
                        className={`filter-pill tag-pill ${isSelected ? 'tag-pill-active' : ''}`}
                        onClick={() => {
                          if (isSelected) {
                            setSelectedTags(selectedTags.filter(t => t !== tagName));
                          } else {
                            setSelectedTags([...selectedTags, tagName]);
                          }
                          setPage(1);
                        }}
                      >
                        {tagName}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </aside>

          {/* Grid */}
          <div className="articles-grid-container">
            {shown.length === 0 ? (
              <div className="no-articles">
                <p>No articles found matching your criteria.</p>
              </div>
            ) : (
              <div className="articles-grid">
                {shown.map((article) => {
                  const attrs = article.attributes || article;
                  const slug = attrs.slug || article.id;
                  const title = attrs.title || 'Untitled';
                  const description = attrs.description || '';
                  const categoryName = attrs.category?.data?.attributes?.name || attrs.category?.name || 'Uncategorized';

                  return (
                    <Link
                      key={article.id}
                      className="article-card"
                      to={`/articles/${slug}`}
                    >
                      {article.thumbnail?.url && (
                        <div className="article-card-thumbnail">
                          <img
                            src={`http://localhost:1337${article.thumbnail.url}`}
                            alt={title}
                            loading="lazy"
                          />
                        </div>
                      )}
                      <div className="article-category-badge">
                        {categoryName}
                      </div>
                      <h3 className="article-card-title">{title}</h3>
                      <p className="article-card-description">
                        {description.substring(0, 120)}
                        {description.length > 120 ? '...' : ''}
                      </p>
                      <div className="article-card-link">Read More →</div>
                    </Link>
                  );
                })}
              </div>
            )}

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="articles-pagination">
                <button
                  className="pagination-btn"
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                >
                  Previous
                </button>
                <span className="pagination-info">
                  Page {page} of {totalPages}
                </span>
                <button
                  className="pagination-btn"
                  disabled={page === totalPages}
                  onClick={() => setPage(page + 1)}
                >
                  Next
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Articles;