/**
 * Article Detail Page Component
 *
 * Displays a single article's full content including text, images, and videos.
 * This page is accessed via /articles/:slug route.
 *
 * Features:
 * ---------
 * 1. Fetches article by slug (or documentId as fallback)
 * 2. Renders rich text content from Strapi's block editor
 * 3. Displays embedded images within article body
 * 4. Plays video media attachments
 * 5. Shows category badge and publish date
 * 6. Back navigation to articles list
 *
 * Content Rendering:
 * ------------------
 * Strapi stores article body as an array of blocks (paragraph, image, etc.)
 * This component parses and renders each block type appropriately:
 * - paragraph: Renders as <p> element
 * - image: Renders as <img> with optional caption
 * - Videos are rendered from the separate 'media' field
 *
 * URL Handling:
 * -------------
 * - First tries to fetch by slug: /articles?filters[slug][$eq]=...
 * - If not found, tries by documentId: /articles/{slug}
 * This handles both user-friendly URLs and direct ID links.
 */

import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { trackArticleView } from '../analytics';
import './ArticleDetail.css';

// Strapi API base URL
const API_URL = 'http://localhost:1337/api';

function ArticleDetail() {
  // Get article slug from URL params (e.g., /articles/my-article-slug)
  const { slug } = useParams();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================
  const [article, setArticle] = useState(null);   // Article data from API
  const [loading, setLoading] = useState(true);   // Loading state
  const [error, setError] = useState('');         // Error message

  // =========================================================================
  // FETCH ARTICLE ON MOUNT OR SLUG CHANGE
  // =========================================================================
  useEffect(() => {
    // Scroll to top when navigating to a new article
    window.scrollTo(0, 0);
    fetchArticle();
  }, [slug]);

  // Track article view in Google Analytics when article loads
  useEffect(() => {
    if (article) {
      const title = article.title || article.attributes?.title;
      const category = article.category?.name || article.attributes?.category?.data?.attributes?.name;
      trackArticleView(title, category);
    }
  }, [article]);

  /**
   * Fetch Article Data
   *
   * Attempts to load article data using two strategies:
   * 1. First, try fetching by slug (user-friendly URL)
   * 2. If not found, try fetching by documentId (Strapi v5 ID format)
   *
   * This dual approach ensures the page works whether the user navigates
   * via a slug-based URL or a direct ID link.
   *
   * populate=* includes all related fields (category, media, thumbnail)
   */
  const fetchArticle = async () => {
    try {
      let response, data;

      // STRATEGY 1: Try to fetch by slug (preferred, user-friendly URLs)
      response = await fetch(`${API_URL}/articles?filters[slug][$eq]=${slug}&populate=*`);
      data = await response.json();
      console.log('Article fetch response for slug:', slug, data);

      if (data && data.data && data.data.length > 0) {
        // Found by slug - use the first (and should be only) result
        setArticle(data.data[0]);
      } else {
        // STRATEGY 2: Fallback - try fetching by documentId
        // This handles cases where the slug in URL is actually an ID
        console.log('Article not found by slug, trying documentId:', slug);
        response = await fetch(`${API_URL}/articles/${slug}?populate=*`);
        data = await response.json();
        console.log('Article fetch response for documentId:', slug, data);

        if (data && data.data) {
          setArticle(data.data);
        } else {
          // Neither slug nor documentId found - article doesn't exist
          console.error('Article not found for slug/documentId:', slug);
          setError('Article not found.');
        }
      }
    } catch (err) {
      console.error('Error fetching article:', err);
      setError('Error loading article.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="article-detail-page">
        <div className="article-detail-loading">Loading article...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="article-detail-page">
        <div className="article-detail-wrapper">
          <Link to="/articles" className="article-back-link">
            ← Back to Articles
          </Link>
          <div className="article-error">
            <p>{error}</p>
          </div>
        </div>
      </div>
    );
  }

  if (!article) {
    return (
      <div className="article-detail-page">
        <div className="article-detail-loading">Article not found</div>
      </div>
    );
  }

  // =========================================================================
  // EXTRACT ARTICLE DATA
  // Handles both Strapi v4 (attributes) and v5 (flat) response formats
  // =========================================================================
  const attrs = article.attributes || article;
  const title = attrs.title || 'Untitled';
  const description = attrs.description || '';
  const body = attrs.body || [];                   // Array of content blocks
  const media = attrs.media || [];                 // Media attachments (videos)
  const categoryName = attrs.category?.data?.attributes?.name || attrs.category?.name || 'Uncategorized';
  const publishedDate = attrs.publishedAt || attrs.published_at;

  // =========================================================================
  // RENDER BODY CONTENT
  // Converts Strapi's block-based content to React elements
  // =========================================================================

  /**
   * Render Body Content
   *
   * Strapi's rich text editor stores content as an array of blocks.
   * Each block has a 'type' property and type-specific data.
   *
   * Supported block types:
   * - paragraph: Text content with children array containing text nodes
   * - image: Embedded image with url, alternativeText, caption
   *
   * @returns {Array|null} Array of React elements or null if no content
   */
  const renderBody = () => {
    if (!body || body.length === 0) return null;

    return body.map((block, index) => {
      // PARAGRAPH BLOCKS: Render as <p> element
      if (block.type === 'paragraph' && block.children) {
        // Children array contains text nodes - concatenate their text
        const text = block.children.map(child => child.text || '').join('');
        // Only render non-empty paragraphs
        return text.trim() ? <p key={index}>{text}</p> : null;
      }

      // IMAGE BLOCKS: Render as <img> with optional caption
      if (block.type === 'image' && block.image) {
        // Handle both absolute and relative URLs
        const imageUrl = block.image.url?.startsWith('http')
          ? block.image.url
          : `http://localhost:1337${block.image.url}`;
        return (
          <div key={index} className="article-image-wrapper">
            <img
              src={imageUrl}
              alt={block.image.alternativeText || block.image.name || 'Article image'}
              className="article-image"
            />
            {block.image.caption && (
              <p className="article-image-caption">{block.image.caption}</p>
            )}
          </div>
        );
      }

      // Unknown block types are skipped
      return null;
    }).filter(Boolean);  // Remove null entries
  };

  // =========================================================================
  // RENDER VIDEO MEDIA
  // Extracts and renders video files from the media attachment field
  // =========================================================================

  /**
   * Render Media (Images and Videos)
   *
   * The 'media' field can contain multiple file attachments.
   * This function renders both images and videos from the media field.
   *
   * @returns {Array|null} Array of media elements or null if no media
   */
  const renderMedia = () => {
    if (!media || media.length === 0) return null;

    // Handle different media formats (array vs object with data property)
    const mediaItems = Array.isArray(media) ? media : media?.data ? media.data : [];

    if (mediaItems.length === 0) return null;

    // Separate images and videos
    const images = mediaItems.filter(item => {
      const mimeType = item.mime || item.attributes?.mime || '';
      return mimeType.startsWith('image/');
    });

    const videos = mediaItems.filter(item => {
      const mimeType = item.mime || item.attributes?.mime || '';
      return mimeType.startsWith('video/');
    });

    if (images.length === 0 && videos.length === 0) return null;

    return (
      <>
        {images.length > 0 && (
          <div className="article-images-grid">
            {images.map((image, index) => {
              const imageData = image.attributes || image;
              const imageUrl = imageData.url?.startsWith('http')
                ? imageData.url
                : `http://localhost:1337${imageData.url}`;

              return (
                <div key={`img-${index}`} className="article-image-wrapper">
                  <img
                    src={imageUrl}
                    alt={imageData.alternativeText || imageData.name || 'Article image'}
                    className="article-image"
                  />
                  {imageData.caption && (
                    <p className="article-image-caption">{imageData.caption}</p>
                  )}
                </div>
              );
            })}
          </div>
        )}
        {videos.map((video, index) => {
          const videoData = video.attributes || video;
          const videoUrl = videoData.url?.startsWith('http')
            ? videoData.url
            : `http://localhost:1337${videoData.url}`;

          return (
            <div key={`vid-${index}`} className="article-video-wrapper">
              <video
                controls
                className="article-video"
              >
                <source src={videoUrl} type={videoData.mime || 'video/mp4'} />
                Your browser does not support the video tag.
              </video>
              {videoData.caption && (
                <p className="article-video-caption">{videoData.caption}</p>
              )}
            </div>
          );
        })}
      </>
    );
  };

  return (
    <div className="article-detail-page">
      <div className="article-detail-wrapper">
        <Link to="/articles" className="article-back-link">
          ← Back to Articles
        </Link>

        <article className="article-detail-card">
          <div className="article-detail-header">
            <div className="article-detail-category-badge">{categoryName}</div>
            <h1 className="article-detail-title">{title}</h1>
            {publishedDate && (
              <div className="article-detail-meta">
                Published on {new Date(publishedDate).toLocaleDateString('en-US', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric'
                })}
              </div>
            )}
          </div>

          <div className="article-detail-body">
            {description && (
              <div className="article-detail-description">
                <p>{description}</p>
              </div>
            )}

            {renderMedia()}

            {body && body.length > 0 && (
              <div className="article-detail-content">
                {renderBody()}
              </div>
            )}

            {(!body || body.length === 0) && !description && (
              <p className="article-no-content">No content available for this article.</p>
            )}
          </div>
        </article>
      </div>
    </div>
  );
}

export default ArticleDetail;