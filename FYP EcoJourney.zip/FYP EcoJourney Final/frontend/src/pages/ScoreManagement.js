/**
 * Score Management Page Component
 *
 * Admin-only dashboard for viewing and managing all quiz submissions.
 * Allows administrators to view, edit, and delete quiz scores.
 *
 * Features:
 * ---------
 * 1. View all quiz submissions from all users
 * 2. Search by username or quiz title
 * 3. Edit score and percentage (admin override)
 * 4. Delete quiz submissions
 * 5. Color-coded percentage badges (excellent/good/needs-work)
 *
 * Use Cases:
 * ----------
 * - Correcting technical issues with submissions
 * - Removing test/dummy data
 * - Investigating score discrepancies
 * - Manual score adjustments for special circumstances
 *
 * Access Control:
 * ---------------
 * - Admin role only (protected by AdminRoute)
 * - Requires valid JWT token
 *
 * API Endpoints:
 * --------------
 * - GET /quiz-results/all - Fetch all submissions (admin)
 * - PUT /quiz-results/admin/:documentId - Update submission
 * - DELETE /quiz-results/admin/:documentId - Delete submission
 *
 * Note: Regular users can only see their own submissions via Profile page.
 * This page shows ALL submissions for administrative purposes.
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getQuizResults, updateQuizResultAdmin, deleteQuizResultAdmin } from '../services/api';
import AdminNav from '../components/AdminNav';
import './ScoreManagement.css';

function ScoreManagement() {
  // Get JWT token for API authentication
  const { token } = useAuth();

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // Submission data
  const [submissions, setSubmissions] = useState([]);           // All submissions
  const [filteredSubmissions, setFilteredSubmissions] = useState([]); // After search filter

  // UI state
  const [loading, setLoading] = useState(true);                 // Loading indicator
  const [error, setError] = useState(null);                     // Error message
  const [successMessage, setSuccessMessage] = useState('');     // Success feedback
  const [searchQuery, setSearchQuery] = useState('');           // Search input

  // Edit modal state
  const [editingSubmission, setEditingSubmission] = useState(null); // Submission being edited
  const [editScore, setEditScore] = useState('');               // Score input value
  const [editPercentage, setEditPercentage] = useState('');     // Percentage input value
  const [modalError, setModalError] = useState('');             // Modal-specific error
  const [submitting, setSubmitting] = useState(false);          // Form submission state

  // Delete confirmation state
  const [deletingSubmission, setDeletingSubmission] = useState(null); // Submission to delete

  useEffect(() => {
    fetchSubmissions();
  }, [token]);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredSubmissions(submissions);
    } else {
      const query = searchQuery.toLowerCase();
      const filtered = submissions.filter(sub =>
        sub.username?.toLowerCase().includes(query) ||
        sub.quiz?.title?.toLowerCase().includes(query)
      );
      setFilteredSubmissions(filtered);
    }
  }, [searchQuery, submissions]);

  const fetchSubmissions = async () => {
    try {
      setLoading(true);
      const response = await getQuizResults(token);
      const data = response.data.data || [];
      setSubmissions(data);
      setFilteredSubmissions(data);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch quiz results:', err);
      setError('Failed to load quiz results. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const openEditModal = (submission) => {
    setEditingSubmission(submission);
    setEditScore(submission.score?.toString() || '0');
    setEditPercentage(submission.percentage?.toString() || '0');
    setModalError('');
  };

  const closeEditModal = () => {
    setEditingSubmission(null);
    setEditScore('');
    setEditPercentage('');
    setModalError('');
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    setModalError('');
    setSuccessMessage('');

    const score = parseInt(editScore, 10);
    const percentage = parseInt(editPercentage, 10);

    if (isNaN(score) || score < 0) {
      setModalError('Score must be a non-negative number');
      return;
    }

    if (isNaN(percentage) || percentage < 0 || percentage > 100) {
      setModalError('Percentage must be between 0 and 100');
      return;
    }

    try {
      setSubmitting(true);
      await updateQuizResultAdmin(editingSubmission.documentId, { score, percentage }, token);
      setSuccessMessage('Score updated successfully');

      // Update local state
      setSubmissions(submissions.map(sub =>
        sub.documentId === editingSubmission.documentId
          ? { ...sub, score, percentage }
          : sub
      ));
      closeEditModal();
    } catch (err) {
      console.error('Failed to update quiz result:', err);
      setModalError(err.response?.data?.error?.message || 'Failed to update score');
    } finally {
      setSubmitting(false);
    }
  };

  const openDeleteConfirm = (submission) => {
    setDeletingSubmission(submission);
  };

  const closeDeleteConfirm = () => {
    setDeletingSubmission(null);
  };

  const handleDelete = async () => {
    setSuccessMessage('');
    try {
      setSubmitting(true);
      await deleteQuizResultAdmin(deletingSubmission.documentId, token);
      setSuccessMessage('Score deleted successfully');

      // Remove from local state
      setSubmissions(submissions.filter(sub => sub.documentId !== deletingSubmission.documentId));
      closeDeleteConfirm();
    } catch (err) {
      console.error('Failed to delete quiz result:', err);
      setError(err.response?.data?.error?.message || 'Failed to delete score');
    } finally {
      setSubmitting(false);
    }
  };

  const clearSearch = () => {
    setSearchQuery('');
  };

  if (loading) {
    return (
      <div className="score-management-container">
        <div className="score-loading">Loading quiz submissions...</div>
      </div>
    );
  }

  return (
    <>
      <AdminNav />
      <div className="score-management-container">
        <div className="score-header">
          <h1>Score Management</h1>
          <p>View, edit, and delete quiz scores</p>
        </div>

      {error && <div className="score-error">{error}</div>}
      {successMessage && <div className="score-success">{successMessage}</div>}

      {/* Search Bar */}
      <div className="search-container">
        <div className="search-input-wrapper">
          <svg className="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <input
            type="text"
            className="search-input"
            placeholder="Search by username or quiz title..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button className="clear-search-btn" onClick={clearSearch}>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M18 6 6 18"></path>
                <path d="m6 6 12 12"></path>
              </svg>
            </button>
          )}
        </div>
      </div>

      {/* Results count */}
      {searchQuery && (
        <div className="search-results-count">
          Found {filteredSubmissions.length} submission{filteredSubmissions.length !== 1 ? 's' : ''} matching "{searchQuery}"
        </div>
      )}

      <div className="submissions-table-container">
        <table className="submissions-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>User</th>
              <th>Quiz</th>
              <th>Score</th>
              <th>Total Questions</th>
              <th>Percentage</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filteredSubmissions.length === 0 ? (
              <tr>
                <td colSpan="7" className="no-submissions">
                  {searchQuery ? 'No submissions match your search' : 'No quiz submissions found'}
                </td>
              </tr>
            ) : (
              filteredSubmissions.map((submission) => (
                <tr key={submission.documentId || submission.id}>
                  <td>{submission.id}</td>
                  <td>{submission.username || 'Unknown'}</td>
                  <td>{submission.quiz?.title || 'Unknown Quiz'}</td>
                  <td className="score-cell">{submission.score}</td>
                  <td>{submission.totalQuestions}</td>
                  <td>
                    <span className={`percentage-badge ${submission.percentage >= 80 ? 'excellent' : submission.percentage >= 60 ? 'good' : 'needs-work'}`}>
                      {submission.percentage || 0}%
                    </span>
                  </td>
                  <td className="actions-cell">
                    <button
                      className="edit-btn"
                      onClick={() => openEditModal(submission)}
                    >
                      Edit
                    </button>
                    <button
                      className="delete-btn"
                      onClick={() => openDeleteConfirm(submission)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Edit Modal */}
      {editingSubmission && (
        <div className="modal-overlay" onClick={closeEditModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <h2>Edit Score</h2>
            <p>User: <strong>{editingSubmission.username}</strong></p>
            <p className="quiz-name">Quiz: {editingSubmission.quiz?.title}</p>

            <form onSubmit={handleEditSubmit}>
              <div className="form-group">
                <label htmlFor="editScore">Score</label>
                <input
                  type="number"
                  id="editScore"
                  value={editScore}
                  onChange={(e) => setEditScore(e.target.value)}
                  min="0"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="editPercentage">Percentage</label>
                <input
                  type="number"
                  id="editPercentage"
                  value={editPercentage}
                  onChange={(e) => setEditPercentage(e.target.value)}
                  min="0"
                  max="100"
                  required
                />
              </div>

              {modalError && <div className="modal-error">{modalError}</div>}

              <div className="modal-actions">
                <button type="button" className="cancel-btn" onClick={closeEditModal}>
                  Cancel
                </button>
                <button type="submit" className="submit-btn" disabled={submitting}>
                  {submitting ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingSubmission && (
        <div className="modal-overlay" onClick={closeDeleteConfirm}>
          <div className="modal-content delete-modal" onClick={(e) => e.stopPropagation()}>
            <h2>Confirm Delete</h2>
            <p>Are you sure you want to delete this score?</p>
            <div className="delete-details">
              <p><strong>User:</strong> {deletingSubmission.username}</p>
              <p><strong>Quiz:</strong> {deletingSubmission.quiz?.title}</p>
              <p><strong>Score:</strong> {deletingSubmission.score} ({deletingSubmission.percentage}%)</p>
            </div>
            <p className="delete-warning">This action cannot be undone.</p>

            <div className="modal-actions">
              <button type="button" className="cancel-btn" onClick={closeDeleteConfirm}>
                Cancel
              </button>
              <button
                type="button"
                className="delete-confirm-btn"
                onClick={handleDelete}
                disabled={submitting}
              >
                {submitting ? 'Deleting...' : 'Delete'}
              </button>
            </div>
          </div>
        </div>
      )}
      </div>
    </>
  );
}

export default ScoreManagement;
