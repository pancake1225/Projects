/**
 * Manage Categories & Tags Page Component
 *
 * Admin/Writer dashboard for managing the content taxonomy system.
 * Categories and tags are used to organize articles, quizzes, and questions.
 *
 * Features:
 * ---------
 * 1. Create/edit/delete categories (delete requires Admin role)
 * 2. Create/edit/delete tags under categories
 * 3. Create multiple tags when creating a new category
 * 4. View tag counts per category
 *
 * Taxonomy Structure:
 * -------------------
 * - Categories are top-level groupings (e.g., "Energy", "Waste", "Water")
 * - Tags are sub-topics within categories (e.g., "Solar Power" under "Energy")
 * - Each tag belongs to exactly one category (One-to-Many relation)
 * - Articles, quizzes, and questions can have one category and multiple tags
 *
 * Access Control:
 * ---------------
 * - Admins and Writers can create/edit categories and tags
 * - Only Admins can delete categories and tags
 * - Categories with tags cannot be deleted (must remove tags first)
 *
 * Strapi v5 Note:
 * ---------------
 * - Slug fields (UID type) cannot be updated after creation
 * - Category-Tag relation is stored on Tag side (tag.category)
 * - Uses documentId for updates (Strapi v5 convention)
 */

import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import AdminNav from '../components/AdminNav';
import WriterNav from '../components/WriterNav';
import './ManageCategories.css';

// Strapi API base URL
const API_URL = 'http://localhost:1337/api';

function ManageCategories() {
  const location = useLocation();
  const { user } = useAuth();

  // Determine which navigation to show based on URL path
  const isWriterPath = location.pathname.startsWith('/writer');

  // =========================================================================
  // COMPONENT STATE
  // =========================================================================

  // Data
  const [categories, setCategories] = useState([]);    // All categories
  const [tags, setTags] = useState([]);                // All tags

  // UI state
  const [loading, setLoading] = useState(true);        // Loading indicator
  const [error, setError] = useState('');              // Error message

  // Modal state
  const [showCategoryModal, setShowCategoryModal] = useState(false);
  const [showTagModal, setShowTagModal] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' or 'edit'
  const [selectedItem, setSelectedItem] = useState(null); // Item being edited

  // Form states
  const [categoryName, setCategoryName] = useState('');
  const [categorySlug, setCategorySlug] = useState('');
  const [categoryTags, setCategoryTags] = useState('');
  const [tagName, setTagName] = useState('');
  const [tagCategory, setTagCategory] = useState('');

  const isAdmin = user?.role?.type === 'admin';

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      // Use timestamp for cache-busting
      const timestamp = Date.now();
      console.log('Fetching data with timestamp:', timestamp);

      const [categoriesRes, tagsRes] = await Promise.all([
        fetch(`${API_URL}/categories?populate=tags&_=${timestamp}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        }),
        fetch(`${API_URL}/tags?populate=category&_=${timestamp}`, {
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
          }
        })
      ]);

      if (categoriesRes.ok && tagsRes.ok) {
        const categoriesData = await categoriesRes.json();
        const tagsData = await tagsRes.json();

        console.log('Fetched categories:', categoriesData.data?.length);
        console.log('Fetched tags:', tagsData.data?.length);
        console.log('Tags data:', tagsData.data?.map(t => ({ id: t.id, name: t.name })));
        console.log('Categories with tags:', categoriesData.data?.map(c => ({
          id: c.id,
          name: c.name,
          tags: c.tags
        })));

        setCategories(categoriesData.data || []);
        setTags(tagsData.data || []);
      } else {
        setError('Failed to load data');
      }
    } catch (err) {
      console.error('Error fetching data:', err);
      setError('Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const openCategoryModal = (mode, category = null) => {
    setModalMode(mode);
    setSelectedItem(category);
    if (category) {
      setCategoryName(category.name || '');
      setCategorySlug(category.slug || '');
    } else {
      setCategoryName('');
      setCategorySlug('');
    }
    setShowCategoryModal(true);
  };

  const openTagModal = (mode, tag = null) => {
    setModalMode(mode);
    setSelectedItem(tag);
    if (tag) {
      setTagName(tag.name || '');
      setTagCategory(tag.category?.id || '');
    } else {
      setTagName('');
      setTagCategory('');
    }
    setShowTagModal(true);
  };

  const closeCategoryModal = () => {
    setShowCategoryModal(false);
    setSelectedItem(null);
    setCategoryName('');
    setCategorySlug('');
    setCategoryTags('');
  };

  const closeTagModal = () => {
    setShowTagModal(false);
    setSelectedItem(null);
    setTagName('');
    setTagCategory('');
  };

  const handleCategorySubmit = async (e) => {
    e.preventDefault();

    if (!categoryName.trim() || !categorySlug.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    try {
      const submitData = {
        name: categoryName.trim()
      };

      // Only include slug when creating (UID fields cannot be updated in Strapi v5)
      if (modalMode === 'create') {
        submitData.slug = categorySlug.trim();
      }

      // Note: Don't include tags when editing. Tags maintain their own reference to category.
      // The One-to-Many relation is stored on the Tag side (tag.category), not on Category side.

      console.log('Submitting category data:', JSON.stringify(submitData, null, 2));

      const url = modalMode === 'edit'
        ? `${API_URL}/categories/${selectedItem.documentId || selectedItem.id}`
        : `${API_URL}/categories`;

      const response = await fetch(url, {
        method: modalMode === 'edit' ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ data: submitData })
      });

      if (response.ok) {
        const result = await response.json();
        console.log('Update/Create response:', result);
        const createdCategoryId = result.data?.id;

        // If creating a new category and tags were provided, create them
        if (modalMode === 'create' && categoryTags.trim() && createdCategoryId) {
          const tagNames = categoryTags
            .split(',')
            .map(t => t.trim())
            .filter(Boolean);

          // Create all tags for the new category
          const tagCreationPromises = tagNames.map(tagName =>
            fetch(`${API_URL}/tags`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${localStorage.getItem('token')}`
              },
              body: JSON.stringify({
                data: {
                  name: tagName,
                  category: createdCategoryId
                }
              })
            })
          );

          try {
            await Promise.all(tagCreationPromises);
          } catch (tagError) {
            console.error('Error creating tags:', tagError);
            alert('Category created, but some tags failed to create');
          }
        }

        await fetchData();
        closeCategoryModal();
        alert(`Category ${modalMode === 'edit' ? 'updated' : 'created'} successfully!`);
      } else {
        const errorData = await response.json();
        alert(`Failed to ${modalMode === 'edit' ? 'update' : 'create'} category: ${errorData.error?.message || 'Unknown error'}`);
      }
    } catch (err) {
      console.error('Error saving category:', err);
      alert('An error occurred while saving the category');
    }
  };

  const handleTagSubmit = async (e) => {
    e.preventDefault();

    if (!tagName.trim() || !tagCategory) {
      alert('Please fill in all required fields');
      return;
    }

    try {
      const submitData = {
        name: tagName.trim(),
        category: tagCategory
      };

      const url = modalMode === 'edit'
        ? `${API_URL}/tags/${selectedItem.documentId || selectedItem.id}`
        : `${API_URL}/tags`;

      const response = await fetch(url, {
        method: modalMode === 'edit' ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify({ data: submitData })
      });

      if (response.ok) {
        await fetchData();
        closeTagModal();
        alert(`Tag ${modalMode === 'edit' ? 'updated' : 'created'} successfully!`);
      } else {
        const errorData = await response.json();
        alert(`Failed to ${modalMode === 'edit' ? 'update' : 'create'} tag: ${errorData.error?.message || 'Unknown error'}`);
      }
    } catch (err) {
      console.error('Error saving tag:', err);
      alert('An error occurred while saving the tag');
    }
  };

  const handleDeleteCategory = async (categoryId) => {
    // Check if category is in use
    const inUse = tags.some(tag => tag.category?.id === categoryId);

    if (inUse) {
      alert('Cannot delete this category because it has tags assigned to it. Please reassign or delete the tags first.');
      return;
    }

    if (!window.confirm('Are you sure you want to delete this category? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(`${API_URL}/categories/${categoryId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('Delete category response status:', response.status);
      const responseData = await response.json().catch(() => null);
      console.log('Delete category response data:', responseData);

      if (response.ok) {
        await fetchData();
        alert('Category deleted successfully!');
      } else {
        const errorMessage = responseData?.error?.message || 'Failed to delete category';
        console.error('Delete category failed:', errorMessage);
        alert(`Failed to delete category: ${errorMessage}`);
      }
    } catch (err) {
      console.error('Error deleting category:', err);
      alert('An error occurred while deleting the category');
    }
  };

  const handleDeleteTag = async (tagId) => {
    if (!window.confirm('Are you sure you want to delete this tag? This action cannot be undone.')) {
      return;
    }

    try {
      console.log('Deleting tag with ID:', tagId);
      const response = await fetch(`${API_URL}/tags/${tagId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`,
          'Content-Type': 'application/json'
        }
      });

      console.log('Delete response status:', response.status);
      const responseData = await response.json().catch(() => null);
      console.log('Delete response data:', responseData);

      if (response.ok) {
        // Add a small delay to ensure database has processed the deletion
        await new Promise(resolve => setTimeout(resolve, 300));

        console.log('Refetching data after delete...');
        await fetchData();
        console.log('Data refetched, new tags:', tags.length);

        alert('Tag deleted successfully!');
      } else {
        const errorMessage = responseData?.error?.message || 'Failed to delete tag';
        console.error('Delete failed:', errorMessage);
        alert(`Failed to delete tag: ${errorMessage}`);
      }
    } catch (err) {
      console.error('Error deleting tag:', err);
      alert('An error occurred while deleting the tag');
    }
  };

  if (loading) {
    return <div className="loading">Loading...</div>;
  }

  if (error) {
    return <div className="error">{error}</div>;
  }

  return (
    <>
      {isWriterPath ? <WriterNav /> : <AdminNav />}
      <div className="manage-categories-page">
        <div className="page-header">
          <h1>Manage Categories & Tags</h1>
          <p>Organize your content taxonomy</p>
        </div>

      {/* Categories Section */}
      <section className="content-section">
        <div className="section-header">
          <h2>Categories</h2>
          <button
            onClick={() => openCategoryModal('create')}
            className="btn btn-primary"
          >
            + Create Category
          </button>
        </div>

        {categories.length === 0 ? (
          <div className="no-items">
            <p>No categories yet. Create your first category to get started.</p>
          </div>
        ) : (
          <div className="items-grid">
            {categories.map((category) => (
              <div key={category.id} className="item-card category-card">
                <div className="item-info">
                  <h3>{category.name}</h3>
                  <p className="item-slug">{category.slug}</p>
                  <p className="item-count">
                    {tags.filter(t => t.category?.documentId === category.documentId).length} tags
                  </p>
                </div>
                <div className="item-actions">
                  <button
                    onClick={() => openCategoryModal('edit', category)}
                    className="btn btn-small btn-edit"
                  >
                    Edit
                  </button>
                  {isAdmin && (
                    <button
                      onClick={() => handleDeleteCategory(category.id)}
                      className="btn btn-small btn-delete"
                    >
                      Delete
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Tags Section */}
      <section className="content-section">
        <div className="section-header">
          <h2>Tags</h2>
          <button
            onClick={() => openTagModal('create')}
            className="btn btn-primary"
          >
            + Create Tag
          </button>
        </div>

        {tags.length === 0 ? (
          <div className="no-items">
            <p>No tags yet. Create your first tag to get started.</p>
          </div>
        ) : (
          <div className="tags-list">
            {categories.map((category) => {
              const categoryTags = tags.filter(t => t.category?.id === category.id);
              if (categoryTags.length === 0) return null;

              return (
                <div key={category.id} className="category-group">
                  <h3 className="category-group-title">
                    {category.name}
                  </h3>
                  <div className="tags-grid">
                    {categoryTags.map((tag) => (
                      <div key={tag.id} className="tag-card">
                        <span className="tag-name">{tag.name}</span>
                        <div className="tag-actions">
                          <button
                            onClick={() => openTagModal('edit', tag)}
                            className="btn btn-small btn-edit"
                            title="Edit tag"
                          >
                            Edit
                          </button>
                          {isAdmin && (
                            <button
                              onClick={() => handleDeleteTag(tag.id)}
                              className="btn btn-small btn-delete"
                              title="Delete tag"
                            >
                              Delete
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Category Modal */}
      {showCategoryModal && (
        <div className="modal-overlay" onClick={closeCategoryModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{modalMode === 'edit' ? 'Edit Category' : 'Create Category'}</h2>
              <button onClick={closeCategoryModal} className="modal-close">×</button>
            </div>

            <form onSubmit={handleCategorySubmit} className="modal-form">
              <div className="form-group">
                <label htmlFor="categoryName">Category Name *</label>
                <input
                  id="categoryName"
                  type="text"
                  value={categoryName}
                  onChange={(e) => setCategoryName(e.target.value)}
                  placeholder="e.g., Energy"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="categorySlug">Slug *</label>
                <input
                  id="categorySlug"
                  type="text"
                  value={categorySlug}
                  onChange={(e) => setCategorySlug(e.target.value)}
                  placeholder="e.g., energy"
                  required
                  disabled={modalMode === 'edit'}
                />
                <small>
                  {modalMode === 'edit'
                    ? 'Slug cannot be changed after creation (Strapi v5 limitation)'
                    : 'Used in URLs (lowercase, no spaces)'}
                </small>
              </div>

              {modalMode === 'create' && (
                <div className="form-group">
                  <label htmlFor="categoryTags">Tags (Optional)</label>
                  <input
                    id="categoryTags"
                    type="text"
                    value={categoryTags}
                    onChange={(e) => setCategoryTags(e.target.value)}
                    placeholder="Enter tag names separated by commas (e.g., Solar Power, Wind Energy)"
                  />
                  <small>You can add tags now or create them later</small>
                </div>
              )}

              <div className="modal-actions">
                <button type="button" onClick={closeCategoryModal} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  {modalMode === 'edit' ? 'Update Category' : 'Create Category'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Tag Modal */}
      {showTagModal && (
        <div className="modal-overlay" onClick={closeTagModal}>
          <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
              <h2>{modalMode === 'edit' ? 'Edit Tag' : 'Create Tag'}</h2>
              <button onClick={closeTagModal} className="modal-close">×</button>
            </div>

            <form onSubmit={handleTagSubmit} className="modal-form">
              <div className="form-group">
                <label htmlFor="tagName">Tag Name *</label>
                <input
                  id="tagName"
                  type="text"
                  value={tagName}
                  onChange={(e) => setTagName(e.target.value)}
                  placeholder="e.g., Solar Power"
                  required
                />
              </div>

              {modalMode === 'create' && (
                <div className="form-group">
                  <label htmlFor="tagCategory">Category *</label>
                  <select
                    id="tagCategory"
                    value={tagCategory}
                    onChange={(e) => setTagCategory(e.target.value)}
                    required
                  >
                    <option value="">Select a category</option>
                    {categories.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="modal-actions">
                <button type="button" onClick={closeTagModal} className="btn btn-secondary">
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary">
                  {modalMode === 'edit' ? 'Update Tag' : 'Create Tag'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      </div>
    </>
  );
}

export default ManageCategories;
