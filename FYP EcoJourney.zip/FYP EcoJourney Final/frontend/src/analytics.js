import ReactGA from 'react-ga4';

const MEASUREMENT_ID = process.env.REACT_APP_GA_MEASUREMENT_ID;

export const initGA = () => {
  if (MEASUREMENT_ID) {
    ReactGA.initialize(MEASUREMENT_ID);
    console.log('[GA4] Initialized with ID:', MEASUREMENT_ID);
  } else {
    console.warn('[GA4] No Measurement ID found. Analytics disabled.');
  }
};

export const trackPageView = (path) => {
  if (MEASUREMENT_ID) {
    ReactGA.send({ hitType: 'pageview', page: path });
  }
};

// Article events
export const trackArticleView = (articleTitle, category) => {
  ReactGA.event('article_view', {
    article_title: articleTitle,
    category: category || 'Uncategorized',
  });
};

// Quiz events
export const trackQuizStart = (quizTitle, difficulty) => {
  ReactGA.event('quiz_start', {
    quiz_title: quizTitle,
    difficulty: difficulty,
  });
};

export const trackQuizComplete = (quizTitle, difficulty, score, totalQuestions) => {
  ReactGA.event('quiz_complete', {
    quiz_title: quizTitle,
    difficulty: difficulty,
    score: score,
    total_questions: totalQuestions,
    percentage: totalQuestions > 0 ? Math.round((score / totalQuestions) * 100) : 0,
  });
};

// Auth events
export const trackLogin = () => {
  ReactGA.event('login', { method: 'email' });
};

export const trackSignUp = () => {
  ReactGA.event('sign_up', { method: 'email' });
};
