/**
 * App.js - Main Application Entry Point
 *
 * This is the root component of the EcoJourney React application.
 * It sets up routing, context providers, and the overall app structure.
 *
 * Application Structure:
 * ----------------------
 * AuthProvider          <- Provides authentication state
 *   └── PermissionsProvider  <- Provides role-based permissions
 *         └── Router         <- React Router for navigation
 *               ├── Layout   <- Conditional Navbar/Footer
 *               │     └── Routes  <- All page routes
 *               └── Chatbot  <- Floating chatbot (outside layout)
 *
 * Route Types:
 * ------------
 * 1. Public Routes: Accessible by anyone (Home, Login, Articles, Quizzes list)
 * 2. Protected Routes: Requires login (Profile, Quiz attempt)
 * 3. Admin Routes: Requires admin role (Admin dashboard, content management)
 * 4. Writer Routes: Requires writer role (Article/Quiz creation)
 */

import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { initGA, trackPageView } from './analytics';
import { AuthProvider } from './context/AuthContext';
import { PermissionsProvider } from './context/PermissionsContext';

// =============================================================================
// COMPONENT IMPORTS
// =============================================================================

// Layout Components
import Navbar from './components/Navbar';
import Footer from './components/Footer';

// Route Guards - Protect routes based on authentication/role
import ProtectedRoute from './components/ProtectedRoute';   // Requires login
import AdminRoute from './components/AdminRoute';           // Requires admin role
import WriterRoute from './components/WriterRoute';         // Requires writer role

// Features
import Chatbot from './components/Chatbot';

// =============================================================================
// PAGE IMPORTS
// =============================================================================

// Public Pages
import Home from './pages/Home';
import Articles from './pages/Articles';
import ArticleDetail from './pages/ArticleDetail';
import Quizzes from './pages/Quizzes';
import QuizAttempt from './pages/QuizAttempt';
import Leaderboard from './pages/Leaderboard';

// Authentication Pages
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

// Protected Pages
import Profile from './pages/Profile';

// Admin Pages
import Admin from './pages/Admin';
import ManageLeaderboard from './pages/ManageLeaderboard';
import ManageArticles from './pages/ManageArticles';
import ManageQuizzes from './pages/ManageQuizzes';
import ManageQuestions from './pages/ManageQuestions';
import ManageCategories from './pages/ManageCategories';

// Writer Pages
import Writer from './pages/Writer';

/**
 * Layout Component
 *
 * Wrapper that conditionally renders Navbar and Footer.
 * The landing page (Home) has no Navbar/Footer for a clean look.
 *
 * @param {Object} props
 * @param {React.ReactNode} props.children - Page content to wrap
 */
function Layout({ children }) {
  // Get current route to determine if we're on landing page
  const location = useLocation();
  const isLandingPage = location.pathname === '/';

  // Track page views on route changes
  useEffect(() => {
    trackPageView(location.pathname + location.search);
  }, [location]);

  return (
    <>
      {/* Only show Navbar on non-landing pages */}
      {!isLandingPage && <Navbar />}

      {/* Page content */}
      {children}

      {/* Only show Footer on non-landing pages */}
      {!isLandingPage && <Footer />}
    </>
  );
}

/**
 * AppRoutes Component
 *
 * Defines all application routes and their access requirements.
 * Routes are organized by access level:
 * 1. Public - No authentication required
 * 2. Protected - Requires authentication
 * 3. Admin - Requires admin role
 * 4. Writer - Requires writer role
 */
function AppRoutes() {
  return (
    <Routes>
      {/* ===================================================================
          PUBLIC ROUTES
          Accessible by anyone, no login required
          =================================================================== */}

      {/* Landing Page */}
      <Route path="/" element={<Home />} />

      {/* Authentication Pages */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />

      {/* Articles - Public browsing */}
      <Route path="/articles" element={<Articles />} />
      <Route path="/articles/:slug" element={<ArticleDetail />} />

      {/* Quizzes - List is public, but taking quiz requires login */}
      <Route path="/quizzes" element={<Quizzes />} />
      <Route
        path="/quizzes/:slug"
        element={
          <ProtectedRoute>
            <QuizAttempt />
          </ProtectedRoute>
        }
      />

      {/* Leaderboard - Public */}
      <Route path="/leaderboard" element={<Leaderboard />} />

      {/* ===================================================================
          PROTECTED ROUTES
          Requires user to be logged in
          =================================================================== */}

      <Route
        path="/profile"
        element={
          <ProtectedRoute>
            <Profile />
          </ProtectedRoute>
        }
      />

      {/* ===================================================================
          ADMIN ROUTES
          Requires admin role
          Admin can manage all content and users
          =================================================================== */}

      {/* Admin Dashboard */}
      <Route
        path="/admin"
        element={
          <AdminRoute>
            <Admin />
          </AdminRoute>
        }
      />

      {/* Admin - Leaderboard Management */}
      <Route
        path="/admin/leaderboard"
        element={
          <AdminRoute>
            <ManageLeaderboard />
          </AdminRoute>
        }
      />

      {/* Admin - Article Management */}
      <Route
        path="/admin/articles"
        element={
          <AdminRoute>
            <ManageArticles />
          </AdminRoute>
        }
      />

      {/* Admin - Quiz Management */}
      <Route
        path="/admin/quizzes"
        element={
          <AdminRoute>
            <ManageQuizzes />
          </AdminRoute>
        }
      />

      {/* Admin - Question Bank Management */}
      <Route
        path="/admin/questions"
        element={
          <AdminRoute>
            <ManageQuestions />
          </AdminRoute>
        }
      />

      {/* Admin - Category Management */}
      <Route
        path="/admin/categories"
        element={
          <AdminRoute>
            <ManageCategories />
          </AdminRoute>
        }
      />

      {/* ===================================================================
          WRITER ROUTES
          Requires writer role
          Writers can create/edit articles and quizzes but not manage users
          =================================================================== */}

      {/* Writer Dashboard */}
      <Route
        path="/writer"
        element={
          <WriterRoute>
            <Writer />
          </WriterRoute>
        }
      />

      {/* Writer - Article Management */}
      <Route
        path="/writer/articles"
        element={
          <WriterRoute>
            <ManageArticles />
          </WriterRoute>
        }
      />

      {/* Writer - Quiz Management */}
      <Route
        path="/writer/quizzes"
        element={
          <WriterRoute>
            <ManageQuizzes />
          </WriterRoute>
        }
      />

      {/* Writer - Question Bank */}
      <Route
        path="/writer/questions"
        element={
          <WriterRoute>
            <ManageQuestions />
          </WriterRoute>
        }
      />

      {/* Writer - Category Management */}
      <Route
        path="/writer/categories"
        element={
          <WriterRoute>
            <ManageCategories />
          </WriterRoute>
        }
      />
    </Routes>
  );
}

/**
 * App Component
 *
 * Root component that assembles the entire application.
 * Sets up providers and routing structure.
 */
function App() {
  // Initialize Google Analytics on app load
  useEffect(() => {
    initGA();
  }, []);

  return (
    // AuthProvider: Makes auth state (user, token, login, logout) available
    <AuthProvider>
      {/* PermissionsProvider: Makes permission checks available */}
      <PermissionsProvider>
        {/* Router: Enables client-side routing */}
        <Router>
          {/* Layout: Wraps pages with Navbar/Footer */}
          <Layout>
            <AppRoutes />
          </Layout>

          {/* Chatbot: Floating chat widget (outside Layout for positioning) */}
          <Chatbot />
        </Router>
      </PermissionsProvider>
    </AuthProvider>
  );
}

export default App;
