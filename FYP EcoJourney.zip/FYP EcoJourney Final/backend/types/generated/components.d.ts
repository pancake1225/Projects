import type { Schema, Struct } from '@strapi/strapi';

export interface QuizQuestions extends Struct.ComponentSchema {
  collectionName: 'components_quiz_questions';
  info: {
    displayName: 'questions';
    icon: 'pencil';
  };
  attributes: {
    correctAnswer: Schema.Attribute.Integer & Schema.Attribute.Required;
    explanation: Schema.Attribute.Text;
    options: Schema.Attribute.JSON & Schema.Attribute.Required;
    questionText: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

declare module '@strapi/strapi' {
  export module Public {
    export interface ComponentSchemas {
      'quiz.questions': QuizQuestions;
    }
  }
}
