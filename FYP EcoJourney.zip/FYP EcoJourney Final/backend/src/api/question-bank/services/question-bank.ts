import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::question-bank.question-bank' as any);
