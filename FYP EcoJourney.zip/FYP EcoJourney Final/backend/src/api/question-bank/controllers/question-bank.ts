import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::question-bank.question-bank' as any, ({ strapi }) => ({
  async find(ctx) {
    // Use db query to directly fetch questions with all relations
    const allQuestions = await strapi.db.query('api::question-bank.question-bank').findMany({
      populate: {
        category: true,
        tags: true,
      },
    });

    // Filter to get only one version per documentId (preferring published over draft)
    const uniqueQuestions = [];
    const seenDocumentIds = new Set();

    // Sort by publishedAt (nulls last) so published versions come first
    const sortedQuestions = allQuestions.sort((a, b) => {
      if (a.publishedAt && !b.publishedAt) return -1;
      if (!a.publishedAt && b.publishedAt) return 1;
      return 0;
    });

    for (const question of sortedQuestions) {
      if (!seenDocumentIds.has(question.documentId)) {
        seenDocumentIds.add(question.documentId);
        uniqueQuestions.push(question);
      }
    }

    return { data: uniqueQuestions };
  },
}));
