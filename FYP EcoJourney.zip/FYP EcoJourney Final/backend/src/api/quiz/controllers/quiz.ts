/**
 * Quiz Controller
 *
 * Extends Strapi's core quiz controller with custom functionality
 * for the EcoJourney quiz system.
 *
 * Purpose:
 * --------
 * Provides custom endpoints for quiz functionality that aren't
 * available through Strapi's default REST API:
 *
 * 1. updateTags - Update quiz tags (bypasses REST validation issues)
 * 2. getQuestions - Fetch and filter questions for a quiz attempt
 *
 * Quiz-Question Relationship:
 * ---------------------------
 * Quizzes don't contain questions directly. Instead:
 * - Quiz has: category (required) and tags (optional)
 * - Questions have: category and tags
 * - getQuestions endpoint matches questions to quiz by:
 *   1. Category must match exactly
 *   2. If quiz has tags, question must have at least one matching tag
 *
 * Difficulty System:
 * ------------------
 * Difficulty affects TWO things (handled in frontend):
 * - Question count: Easy=3, Medium=6, Hard=9
 * - Point multiplier: Easy=1x, Medium=2x, Hard=3x
 *
 * Note: All questions are equal - difficulty no longer filters
 * questions by a difficulty field on the question.
 *
 * Strapi v5 Notes:
 * ----------------
 * - Uses Document Service API (strapi.documents)
 * - Must specify status: 'published' to get relations populated
 * - Can lookup by numeric id or alphanumeric documentId
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::quiz.quiz', ({ strapi }) => ({
  // ========================================================================
  // UPDATE TAGS
  // Custom endpoint to update quiz tags (bypasses REST API validation)
  // ========================================================================
  async updateTags(ctx) {
    try {
      const { documentId } = ctx.params;
      const { tags } = ctx.request.body;

      console.log(`[UpdateTags] Updating tags for quiz ${documentId}:`, tags);

      // Update using Document Service API which allows relation updates
      const updatedQuiz = await strapi.documents('api::quiz.quiz').update({
        documentId,
        data: {
          tags: tags || [],
        },
      });

      console.log(`[UpdateTags] Successfully updated tags for quiz ${documentId}`);

      ctx.body = {
        data: updatedQuiz,
      };
    } catch (err) {
      console.error('[UpdateTags Error]:', err);
      ctx.throw(500, err);
    }
  },

  // Custom action to get questions for a quiz
  async getQuestions(ctx) {
    try {
      const { id } = ctx.params;
      const { difficulty } = ctx.query; // Get difficulty from query params

      // Fetch quiz with category and tags
      // Use Document Service with published status to ensure relations are populated
      let quiz: any;

      // Check if id is numeric (entry id) or alphanumeric (documentId)
      const isNumericId = /^\d+$/.test(id);

      if (isNumericId) {
        // Numeric ID - fetch all quizzes and find by id
        const allQuizzes = await strapi.documents('api::quiz.quiz').findMany({
          status: 'published',
          populate: {
            category: true,
            tags: true,
          },
        });
        quiz = allQuizzes.find((q: any) => q.id === parseInt(id));
      } else {
        // DocumentId - fetch directly
        quiz = await strapi.documents('api::quiz.quiz').findOne({
          documentId: id,
          status: 'published',
          populate: {
            category: true,
            tags: true,
          },
        });
      }

      if (!quiz) {
        return ctx.notFound('Quiz not found');
      }

      console.log(`[Quiz ${id}] Loaded quiz:`, {
        category: quiz.category?.name,
        tags: quiz.tags?.map((t: any) => t.name).join(', ') || 'none',
      });

      // Check if quiz has required category
      if (!quiz.category?.name) {
        console.log(`[Quiz ${id}] WARNING: Quiz has no category! Cannot filter questions.`);
        return ctx.badRequest('Quiz must have a category to fetch questions');
      }

      // Prepare tag filter if tags are specified
      const tagDocumentIds = quiz.tags && quiz.tags.length > 0
        ? quiz.tags.map((tag: any) => tag.documentId)
        : [];

      // NOTE: No longer filtering by difficulty - all questions are equal
      // Difficulty only affects question count and point multiplier

      // Try using Document Service API instead of Entity Service (Strapi v5)
      // IMPORTANT: Must fetch published documents only - drafts don't have relations populated!
      console.log(`[Quiz ${id}] Fetching published questions using Document Service API...`);
      const allQuestions: any = await strapi.documents('api::question-bank.question-bank').findMany({
        status: 'published',
        populate: {
          category: true,
          tags: true,
        },
      });

      console.log(`[Quiz ${id}] Fetched ${allQuestions?.length || 0} total questions from database`);

      // Filter in JavaScript by category name and tags
      const questions = allQuestions.filter((q: any) => {
        // Must match category
        const categoryMatches = quiz.category?.name && q.category?.name === quiz.category.name;
        if (!categoryMatches) return false;

        // If quiz has tags, question must have at least one matching tag
        if (tagDocumentIds.length > 0) {
          const questionTagDocIds = (q.tags || []).map((t: any) => t.documentId);
          const hasMatchingTag = tagDocumentIds.some((tagDocId: string) =>
            questionTagDocIds.includes(tagDocId)
          );
          return hasMatchingTag;
        }

        return true;
      });

      console.log(`[Quiz ${id}] Found ${questions?.length || 0} questions after JS filtering`);

      if (!questions || questions.length === 0) {
        console.log(`[Quiz ${id}] No questions found. Quiz has category: ${quiz.category?.id}, tags: ${quiz.tags?.map((t: any) => t.id).join(', ')}`);
        return ctx.badRequest('No questions found matching the quiz criteria');
      }

      // Question counts by difficulty selection
      const questionCounts = {
        easy: 3,
        medium: 6,
        hard: 9,
      };

      // Determine number of questions based on difficulty selection
      let questionCount = quiz.numberOfQuestions || 10;
      if (difficulty && questionCounts[difficulty as keyof typeof questionCounts]) {
        questionCount = questionCounts[difficulty as keyof typeof questionCounts];
      }

      // Shuffle and limit to numberOfQuestions
      const shuffled = questions.sort(() => 0.5 - Math.random());
      const selectedQuestions = shuffled.slice(0, Math.min(questionCount, questions.length));

      // Return questions (all questions are now equal worth)
      return {
        quiz: {
          id: quiz.id,
          title: quiz.title,
          description: quiz.description,
          timeLimit: quiz.timeLimit,
          passingScore: quiz.passingScore,
          numberOfQuestions: quiz.numberOfQuestions,
        },
        difficulty: difficulty || 'medium',
        questions: selectedQuestions.map((q: any) => ({
          id: q.id,
          questionText: q.questionText,
          options: q.options,
          explanation: q.explanation,
          correctAnswer: q.correctAnswer,
        })),
      };
    } catch (err) {
      console.error('[Quiz Controller Error]:', err);
      ctx.throw(500, err);
    }
  },
}));
