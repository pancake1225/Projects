/**
 * Quiz Lifecycle Hooks
 *
 * Sends email notifications to all admins when quizzes are published, updated, or deleted.
 * Distinguishes between newly created quizzes and updated quizzes.
 */

// Store to capture quiz data before deletion
const deletedQuizData = new Map<string, any>();

// Track sent delete emails to prevent duplicates (Strapi triggers delete twice for draft/published)
const sentDeleteEmails = new Set<string>();

// Track documentIds that had a version deleted recently (to detect update vs new in afterCreate)
// When Strapi v5 updates a published doc, it deletes the old draft then creates a new record.
// So the flow is: beforeDelete -> afterDelete -> beforeCreate -> afterCreate
// If we see a documentId in beforeDelete, and then afterCreate fires for the same documentId,
// we know it's an update, not a brand new quiz.
const recentlyDeletedDocIds = new Set<string>();

export default {
  // afterCreate triggers for both new quizzes AND updates (Strapi v5 deletes old draft + creates new record)
  async afterCreate(event) {
    const { result } = event;
    console.log('[Quiz] afterCreate triggered:', result.documentId);

    if (result.publishedAt) {
      // Check if this documentId was recently deleted (meaning this is an update, not new)
      const isUpdate = recentlyDeletedDocIds.has(result.documentId);
      if (isUpdate) {
        recentlyDeletedDocIds.delete(result.documentId);
      }
      console.log('[Quiz] afterCreate - isUpdate:', isUpdate);
      await sendQuizEmail(result, !isUpdate);
    }
  },

  // afterUpdate triggers when updating an existing record in-place
  async afterUpdate(event) {
    const { result } = event;
    console.log('[Quiz] afterUpdate triggered:', result.documentId);

    if (result.publishedAt) {
      // afterUpdate always means the quiz already existed - it's an update
      await sendQuizEmail(result, false);
    }
  },

  // Capture quiz data before deletion
  async beforeDelete(event) {
    const { params } = event;
    const internalId = params.where?.id;
    console.log('[Quiz] beforeDelete id:', internalId);

    if (internalId) {
      try {
        let deletedByEmail = 'Unknown';
        try {
          const ctx = strapi.requestContext.get();
          if (ctx?.state?.user?.email) {
            deletedByEmail = ctx.state.user.email;
          }
        } catch (e) {}

        const quiz: any = await strapi.db.query('api::quiz.quiz').findOne({
          where: { id: internalId },
          populate: ['category', 'tags'],
        });

        if (quiz) {
          // Track this documentId so afterCreate can detect updates vs new
          recentlyDeletedDocIds.add(quiz.documentId);
          // Auto-clean after 10 seconds
          setTimeout(() => recentlyDeletedDocIds.delete(quiz.documentId), 10000);

          const tagNames = quiz.tags?.map((t: any) => t.name).join(', ') || 'None';

          deletedQuizData.set(String(internalId), {
            title: quiz.title,
            slug: quiz.slug,
            description: quiz.description,
            documentId: quiz.documentId,
            categoryName: quiz.category?.name || 'Uncategorized',
            tagNames,
            authorEmail: quiz.authorEmail || 'Unknown',
            deletedByEmail,
          });
        }
      } catch (error) {
        console.error('Error capturing quiz data before delete:', error);
      }
    }
  },

  // Send notification after quiz is deleted (with delayed check to avoid false triggers during updates)
  async afterDelete(event) {
    const { params } = event;
    const internalId = params.where?.id;
    console.log('[Quiz] afterDelete id:', internalId);

    if (internalId) {
      const quizData = deletedQuizData.get(String(internalId));
      deletedQuizData.delete(String(internalId));

      if (quizData?.documentId) {
        // Wait briefly then check if document still exists (update = still exists, real delete = gone)
        setTimeout(async () => {
          try {
            const stillExists = await strapi.db.query('api::quiz.quiz').findOne({
              where: { documentId: quizData.documentId },
            });

            if (stillExists) {
              console.log('[Quiz] Document still exists after delete - this was an update, skipping delete email');
              return;
            }

            // Document is truly gone - send delete email (but prevent duplicates)
            const emailKey = quizData.slug || quizData.title;
            if (sentDeleteEmails.has(emailKey)) {
              console.log('[Quiz] Skipping duplicate delete email for:', emailKey);
              return;
            }

            sentDeleteEmails.add(emailKey);
            console.log('[Quiz] Document fully deleted, sending delete email for:', quizData.title);
            await sendQuizDeleteEmail(quizData);
            setTimeout(() => sentDeleteEmails.delete(emailKey), 5000);
          } catch (error) {
            console.error('[Quiz] Error in delayed delete check:', error);
          }
        }, 1500);
      }
    }
  },
};

/**
 * Send email notification to all admins about quiz publish/update
 */
async function sendQuizEmail(quiz: any, isNew: boolean) {
  console.log('[Quiz] Attempting to send email for:', quiz.title, isNew ? '(NEW)' : '(UPDATED)');

  try {
    const adminRole = await strapi.db.query('plugin::users-permissions.role').findOne({
      where: { type: 'admin' },
    });

    if (!adminRole) {
      console.log('No admin role found');
      return;
    }

    const adminUsers = await strapi.db.query('plugin::users-permissions.user').findMany({
      where: { role: adminRole.id },
    });

    if (adminUsers.length === 0) {
      console.log('No admin users found');
      return;
    }

    const adminEmails = adminUsers.map((user: any) => user.email).filter(Boolean);
    console.log('Sending to admins:', adminEmails);

    // Fetch full quiz with relations
    let fullQuiz: any = await strapi.db.query('api::quiz.quiz').findOne({
      where: { documentId: quiz.documentId },
      populate: ['category', 'tags'],
    });

    if (!fullQuiz && quiz.id) {
      fullQuiz = await strapi.db.query('api::quiz.quiz').findOne({
        where: { id: quiz.id },
        populate: ['category', 'tags'],
      });
    }

    const categoryName = fullQuiz?.category?.name || 'Uncategorized';
    const tagNames = fullQuiz?.tags?.map((t: any) => t.name).join(', ') || 'None';

    const creatorEmail = fullQuiz?.authorEmail || quiz.authorEmail || 'Unknown';
    const updaterEmail = fullQuiz?.lastUpdatedByEmail || quiz.lastUpdatedByEmail || creatorEmail;

    const statusText = isNew ? 'NEW QUIZ PUBLISHED' : 'QUIZ UPDATED';
    const statusColor = isNew ? '#059669' : '#0284c7';

    const emailService = strapi.plugin('email').service('email');

    for (const adminEmail of adminEmails) {
      await emailService.send({
        to: adminEmail,
        from: process.env.SMTP_DEFAULT_FROM || process.env.SMTP_USERNAME,
        subject: `${statusText}: ${quiz.title}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, ${statusColor} 0%, #95d5b2 100%); padding: 30px; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0;">${statusText}</h1>
            </div>
            <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px;">
              <div style="background: ${isNew ? '#d1fae5' : '#dbeafe'}; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                <strong style="color: ${statusColor};">${isNew ? 'This is a brand new quiz' : 'This quiz has been updated'}</strong>
              </div>

              <h2 style="color: #1b4332; margin-top: 0;">Quiz Details</h2>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666; width: 120px;"><strong>Title:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${quiz.title}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Category:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${categoryName}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Tags:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${tagNames}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Slug:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937; font-family: monospace; background: #f3f4f6; padding: 4px 8px; border-radius: 4px;">${quiz.slug}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>${isNew ? 'Created by:' : 'Updated by:'}</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${isNew ? creatorEmail : updaterEmail}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Date:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${new Date().toLocaleString()}</td>
                </tr>
              </table>

              <div style="margin-top: 20px; padding: 16px; background: white; border: 1px solid #e5e7eb; border-radius: 8px;">
                <strong style="color: #374151;">Description:</strong>
                <p style="margin: 8px 0 0; color: #4b5563;">${quiz.description || 'No description provided'}</p>
              </div>

            </div>
            <div style="text-align: center; margin-top: 20px; color: #999; font-size: 12px;">
              <p>EcoJourney - RP ESG Centre Sustainability Awareness Platform</p>
            </div>
          </div>
        `,
      });
    }

    console.log(`[Quiz] Admin emails sent successfully for: ${quiz.title} (${isNew ? 'NEW' : 'UPDATED'})`);
  } catch (error) {
    console.error('[Quiz] Failed to send admin email:', error);
    console.error('Error details:', error.message);
  }
}

/**
 * Send email notification to all admins about quiz deletion
 */
async function sendQuizDeleteEmail(quizData: any) {
  console.log('[Quiz] Attempting to send delete notification for:', quizData.title);

  try {
    const adminRole = await strapi.db.query('plugin::users-permissions.role').findOne({
      where: { type: 'admin' },
    });

    if (!adminRole) {
      console.log('No admin role found');
      return;
    }

    const adminUsers = await strapi.db.query('plugin::users-permissions.user').findMany({
      where: { role: adminRole.id },
    });

    if (adminUsers.length === 0) {
      console.log('No admin users found');
      return;
    }

    const adminEmails = adminUsers.map((user: any) => user.email).filter(Boolean);

    const emailService = strapi.plugin('email').service('email');

    for (const adminEmail of adminEmails) {
      await emailService.send({
        to: adminEmail,
        from: process.env.SMTP_DEFAULT_FROM || process.env.SMTP_USERNAME,
        subject: `QUIZ DELETED: ${quizData.title}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%); padding: 30px; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0;">QUIZ DELETED</h1>
            </div>
            <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px;">
              <div style="background: #fee2e2; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                <strong style="color: #dc2626;">This quiz has been permanently deleted</strong>
              </div>

              <h2 style="color: #1b4332; margin-top: 0;">Deleted Quiz Details</h2>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666; width: 120px;"><strong>Title:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${quizData.title}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Category:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${quizData.categoryName}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Tags:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${quizData.tagNames}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Slug:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937; font-family: monospace; background: #f3f4f6; padding: 4px 8px; border-radius: 4px;">${quizData.slug}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Author:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${quizData.authorEmail}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Deleted by:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${quizData.deletedByEmail || 'Unknown'}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Deleted at:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${new Date().toLocaleString()}</td>
                </tr>
              </table>

              <div style="margin-top: 20px; padding: 16px; background: white; border: 1px solid #e5e7eb; border-radius: 8px;">
                <strong style="color: #374151;">Description:</strong>
                <p style="margin: 8px 0 0; color: #4b5563;">${quizData.description || 'No description provided'}</p>
              </div>
            </div>
            <div style="text-align: center; margin-top: 20px; color: #999; font-size: 12px;">
              <p>EcoJourney - RP ESG Centre Sustainability Awareness Platform</p>
            </div>
          </div>
        `,
      });
    }

    console.log(`[Quiz] Delete notification sent successfully for: ${quizData.title}`);
  } catch (error) {
    console.error('[Quiz] Failed to send delete notification:', error);
    console.error('Error details:', error.message);
  }
}
