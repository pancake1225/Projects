/**
 * Custom Quiz Routes
 *
 * Additional routes for quiz functionality beyond Strapi's default CRUD.
 * These supplement the auto-generated routes from Strapi's core.
 *
 * Route: GET /quizzes/:id/questions
 * ---------------------------------
 * Fetches questions for a quiz attempt based on matching category and tags.
 *
 * Query Parameters:
 * - difficulty: 'easy' | 'medium' | 'hard' (affects question count)
 *
 * URL Parameter:
 * - id: Can be numeric quiz ID or alphanumeric documentId
 *
 * Returns:
 * - quiz: Basic quiz metadata
 * - difficulty: The difficulty level requested
 * - questions: Array of shuffled questions with options
 *
 * Used By:
 * - QuizAttempt.js when user starts a quiz
 */

export default {
  routes: [
    {
      // Get questions for quiz attempt
      // Called when user selects difficulty and starts quiz
      method: 'GET',
      path: '/quizzes/:id/questions',
      handler: 'quiz.getQuestions',
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};
