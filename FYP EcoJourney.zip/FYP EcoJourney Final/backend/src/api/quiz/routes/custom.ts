/**
 * Custom quiz routes
 */

export default {
  routes: [
    {
      method: 'PUT',
      path: '/quizzes/:documentId/tags',
      handler: 'quiz.updateTags',
      config: {
        policies: [],
        auth: false,
      },
    },
  ],
};
