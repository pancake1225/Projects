/**
 * admin-panel service
 */

export default () => ({});
