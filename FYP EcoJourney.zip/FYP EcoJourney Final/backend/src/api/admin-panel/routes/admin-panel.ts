/**
 * Admin Panel Routes
 *
 * Custom routes for user management and authentication features.
 * All routes bypass Strapi's default authentication (auth: false)
 * and use manual JWT verification in the controller instead.
 *
 * Why auth: false?
 * ----------------
 * Strapi's built-in auth middleware doesn't provide the flexibility
 * we need for checking Admin role on users-permissions users.
 * By disabling it, we can implement custom authentication logic
 * that properly integrates with the users-permissions plugin.
 *
 * Security Note:
 * --------------
 * Even though auth: false is set, the controller methods manually
 * verify JWT tokens and check for Admin role where required.
 * Only truly public endpoints (password reset request) skip auth entirely.
 *
 * Route Summary:
 * --------------
 * GET  /me              - Get current user's profile (requires valid JWT)
 * GET  /users           - List all users (Admin only)
 * PUT  /users/:id       - Update user info (Admin only)
 * PUT  /users/:id/password - Change password (Admin only)
 * PUT  /users/:id/role  - Assign role (Admin only)
 * DELETE /users/:id     - Delete user (Admin only)
 * GET  /roles           - List available roles (Admin only)
 * POST /reset-progress  - Reset own quiz progress (requires valid JWT)
 * POST /request-password-reset - Send PIN email (Public)
 * POST /reset-password-with-pin - Reset with PIN (Public)
 */

export default {
  routes: [
    // ========================================================================
    // USER PROFILE ENDPOINT
    // ========================================================================
    {
      method: 'GET',
      path: '/admin-panel/me',
      handler: 'admin-panel.getMe',
      config: {
        policies: [],
        auth: false,  // Manual JWT verification in controller
      },
    },
    // ========================================================================
    // ADMIN-ONLY USER MANAGEMENT ENDPOINTS
    // All require Admin role - verified in controller
    // ========================================================================
    {
      // List all users - Admin dashboard user list
      method: 'GET',
      path: '/admin-panel/users',
      handler: 'admin-panel.getUsers',
      config: {
        policies: [],
        auth: false,  // Admin check in controller
      },
    },
    {
      // Admin password reset - Override user's password
      method: 'PUT',
      path: '/admin-panel/users/:id/password',
      handler: 'admin-panel.changePassword',
      config: {
        policies: [],
        auth: false,  // Admin check in controller
      },
    },
    {
      // Update user details - Change username/email
      method: 'PUT',
      path: '/admin-panel/users/:id',
      handler: 'admin-panel.updateUser',
      config: {
        policies: [],
        auth: false,  // Admin check in controller
      },
    },
    {
      // List available roles - For role dropdown in admin panel
      method: 'GET',
      path: '/admin-panel/roles',
      handler: 'admin-panel.getRoles',
      config: {
        policies: [],
        auth: false,  // Admin check in controller
      },
    },
    {
      // Assign role to user - Change user's role (Admin, Writer, etc.)
      method: 'PUT',
      path: '/admin-panel/users/:id/role',
      handler: 'admin-panel.updateUserRole',
      config: {
        policies: [],
        auth: false,  // Admin check in controller
      },
    },
    {
      // Delete user account and their quiz results
      method: 'DELETE',
      path: '/admin-panel/users/:id',
      handler: 'admin-panel.deleteUser',
      config: {
        policies: [],
        auth: false,  // Admin check in controller
      },
    },

    // ========================================================================
    // AUTHENTICATED USER ENDPOINTS
    // Require valid JWT but not Admin role
    // ========================================================================
    {
      // Reset own quiz progress - Deletes all quiz results for current user
      method: 'POST',
      path: '/admin-panel/reset-progress',
      handler: 'admin-panel.resetUserProgress',
      config: {
        policies: [],
        auth: false,  // JWT verification in controller (not Admin-only)
      },
    },

    // ========================================================================
    // PUBLIC ENDPOINTS (No authentication required)
    // Used for self-service password reset flow
    // ========================================================================
    {
      // Request password reset - Sends 6-digit PIN to user's email
      // Always returns success (even for non-existent emails) for security
      method: 'POST',
      path: '/admin-panel/request-password-reset',
      handler: 'admin-panel.requestPasswordReset',
      config: {
        policies: [],
        auth: false,  // Public endpoint
      },
    },
    {
      // Complete password reset - Verify PIN and set new password
      method: 'POST',
      path: '/admin-panel/reset-password-with-pin',
      handler: 'admin-panel.resetPasswordWithPin',
      config: {
        policies: [],
        auth: false,  // Public endpoint
      },
    },
  ],
};
