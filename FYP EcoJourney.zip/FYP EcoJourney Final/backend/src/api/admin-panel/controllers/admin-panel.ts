/**
 * Admin Panel Controller
 *
 * Custom Strapi controller for user management and authentication features
 * that aren't available in Strapi's default users-permissions plugin.
 *
 * Purpose:
 * --------
 * This controller provides administrative endpoints for:
 * 1. User management (CRUD operations on user accounts)
 * 2. Role management (assigning roles to users)
 * 3. Password management (admin password reset, PIN-based self-service reset)
 * 4. Progress tracking (reset quiz progress)
 *
 * Authentication:
 * ---------------
 * Most endpoints use MANUAL JWT authentication (not Strapi's auth middleware).
 * This is because we need custom admin role checking that works with
 * the users-permissions plugin.
 *
 * Routes are configured with auth: false, then we manually:
 * 1. Extract JWT from Authorization header
 * 2. Verify and decode the token
 * 3. Check if user has Admin role
 *
 * Strapi v5 Notes:
 * ----------------
 * - Uses documentId for updates (not numeric id)
 * - entityService.findMany returns flat objects (not { data: ... })
 * - Password hashing done manually with bcryptjs
 *
 * Available Endpoints:
 * --------------------
 * GET  /admin-panel/me              - Get current user info
 * GET  /admin-panel/users           - List all users (Admin only)
 * PUT  /admin-panel/users/:id       - Update user details (Admin only)
 * PUT  /admin-panel/users/:id/password - Change user password (Admin only)
 * PUT  /admin-panel/users/:id/role  - Update user role (Admin only)
 * DELETE /admin-panel/users/:id     - Delete user account (Admin only)
 * GET  /admin-panel/roles           - List available roles (Admin only)
 * POST /admin-panel/reset-progress  - Reset own quiz progress (Authenticated)
 * POST /admin-panel/request-password-reset - Request PIN (Public)
 * POST /admin-panel/reset-password-with-pin - Reset with PIN (Public)
 */

import type { Core } from '@strapi/strapi';

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

/**
 * Extract and verify user from JWT token
 *
 * Attempts to get user in two ways:
 * 1. From ctx.state.user (if Strapi auth middleware ran)
 * 2. By manually parsing and verifying JWT from Authorization header
 *
 * @param ctx - Koa context object
 * @param strapi - Strapi instance
 * @returns User object with id, or null if not authenticated
 */
const getUserFromToken = async (ctx: any, strapi: Core.Strapi) => {
  // Try to get user from ctx.state first (if auth middleware ran)
  if (ctx.state.user) {
    return ctx.state.user;
  }

  // Otherwise, manually parse JWT from Authorization header
  const authHeader = ctx.request.header.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }

  // Extract token (remove "Bearer " prefix)
  const token = authHeader.substring(7);
  try {
    const jwt = require('jsonwebtoken');
    // Get JWT secret from Strapi config (try multiple possible locations)
    const jwtSecret = strapi.config.get('plugin::users-permissions.jwtSecret') ||
                      strapi.config.get('plugin.users-permissions.jwtSecret') ||
                      process.env.JWT_SECRET;

    if (!jwtSecret) {
      console.error('JWT secret not found');
      return null;
    }

    // Verify and decode the token
    const decoded = jwt.verify(token, jwtSecret) as any;
    return { id: decoded.id };
  } catch (error) {
    console.error('JWT verification failed:', error);
    return null;
  }
};

/**
 * Check if current user has Admin role
 *
 * Extracts user from JWT, then queries database to verify
 * they have the Admin role assigned.
 *
 * @param ctx - Koa context object
 * @param strapi - Strapi instance
 * @returns true if user is admin, false otherwise
 */
const isAdmin = async (ctx: any, strapi: Core.Strapi) => {
  const tokenUser = await getUserFromToken(ctx, strapi);
  if (!tokenUser) {
    console.log('No user from token');
    return false;
  }

  const userId = tokenUser.id;
  console.log('Checking admin for user ID:', userId);

  try {
    // Find user by ID with role populated
    const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
      filters: { id: userId },
      populate: ['role'],
    }) as any[];

    if (!users || users.length === 0) {
      console.log('User not found');
      return false;
    }

    const user = users[0];
    console.log('Found user:', user?.username, 'Role:', user?.role?.name, user?.role?.type);

    if (!user.role) {
      console.log('User role not found');
      return false;
    }

    // Check for admin role by type or name
    const isAdminRole = user.role.type === 'admin' || user.role.name === 'Admin';
    console.log('Is admin role:', isAdminRole);
    return isAdminRole;
  } catch (error) {
    console.error('Error checking admin status:', error);
    return false;
  }
};

// ============================================================================
// CONTROLLER EXPORT
// ============================================================================

export default ({ strapi }: { strapi: Core.Strapi }) => ({
  async getMe(ctx) {
    // Get current user from token
    const tokenUser = await getUserFromToken(ctx, strapi);
    if (!tokenUser) {
      return ctx.unauthorized('Authentication required');
    }

    try {
      // Fetch user with role information
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        filters: { id: tokenUser.id },
        fields: ['id', 'username', 'email', 'createdAt', 'blocked'],
        populate: ['role'],
      });

      if (!users || users.length === 0) {
        return ctx.notFound('User not found');
      }

      ctx.body = users[0];
    } catch (error) {
      console.error('Get me error:', error);
      ctx.throw(500, 'Failed to fetch user data');
    }
  },

  async getUsers(ctx) {
    // Check if user is admin
    const adminCheck = await isAdmin(ctx, strapi);
    if (!adminCheck) {
      return ctx.forbidden('Access denied. Admin role required.');
    }

    try {
      // Use entity service for users-permissions plugin
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        fields: ['id', 'username', 'email', 'createdAt', 'blocked'],
        populate: ['role'],
      });

      ctx.body = { data: users };
    } catch (error) {
      console.error('Get users error:', error);
      ctx.throw(500, 'Failed to fetch users');
    }
  },

  async changePassword(ctx) {
    // Check if user is admin
    const adminCheck = await isAdmin(ctx, strapi);
    if (!adminCheck) {
      return ctx.forbidden('Access denied. Admin role required.');
    }

    const { id } = ctx.params;
    const { newPassword } = ctx.request.body;

    if (!newPassword || newPassword.length < 6) {
      return ctx.badRequest('Password must be at least 6 characters long');
    }

    try {
      // Find user by numeric ID
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        filters: { id: parseInt(id, 10) },
      }) as any[];

      if (!users || users.length === 0) {
        return ctx.notFound('User not found');
      }

      const user = users[0];

      // Hash the new password using bcrypt (Strapi v5 compatible)
      const bcrypt = require('bcryptjs');
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update the user's password using documentId for Strapi v5
      await strapi.entityService.update('plugin::users-permissions.user', user.documentId || user.id, {
        data: {
          password: hashedPassword,
        },
      });

      ctx.body = { message: 'Password updated successfully' };
    } catch (error) {
      console.error('Password change error:', error);
      ctx.throw(500, 'Failed to update password');
    }
  },

  async updateUser(ctx) {
    // Check if user is admin
    const adminCheck = await isAdmin(ctx, strapi);
    if (!adminCheck) {
      return ctx.forbidden('Access denied. Admin role required.');
    }

    const { id } = ctx.params;
    const { username, email } = ctx.request.body;

    if (!username && !email) {
      return ctx.badRequest('Please provide username or email to update');
    }

    try {
      // Find user by numeric ID
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        filters: { id: parseInt(id, 10) },
      }) as any[];

      if (!users || users.length === 0) {
        return ctx.notFound('User not found');
      }

      const user = users[0];
      console.log('Found user for update:', user.id, user.documentId, user.username);

      const updateData: any = {};

      // Validate and add username if provided
      if (username) {
        if (username.length < 3) {
          return ctx.badRequest('Username must be at least 3 characters long');
        }
        // Check if username is already taken by another user
        const existingUser = await strapi.entityService.findMany('plugin::users-permissions.user', {
          filters: { username, id: { $ne: parseInt(id, 10) } },
        }) as any[];
        if (existingUser && existingUser.length > 0) {
          return ctx.badRequest('Username is already taken');
        }
        updateData.username = username;
      }

      // Validate and add email if provided
      if (email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          return ctx.badRequest('Please provide a valid email address');
        }
        // Check if email is already taken by another user
        const existingUser = await strapi.entityService.findMany('plugin::users-permissions.user', {
          filters: { email, id: { $ne: parseInt(id, 10) } },
        }) as any[];
        if (existingUser && existingUser.length > 0) {
          return ctx.badRequest('Email is already taken');
        }
        updateData.email = email;
      }

      // In Strapi v5, we must use documentId for updates
      const documentId = user.documentId;
      if (!documentId) {
        console.error('No documentId found for user:', user);
        return ctx.badRequest('User document ID not found');
      }

      console.log('Updating user with documentId:', documentId, 'data:', updateData);

      // Use Strapi's db query layer directly for users-permissions update
      await strapi.db.query('plugin::users-permissions.user').update({
        where: { documentId: documentId },
        data: updateData,
      });

      // Return success with the new values
      const newUsername = updateData.username || user.username;
      const newEmail = updateData.email || user.email;

      ctx.body = { message: 'User updated successfully', data: { username: newUsername, email: newEmail } };
    } catch (error) {
      console.error('User update error:', error);
      ctx.throw(500, 'Failed to update user');
    }
  },

  async getRoles(ctx) {
    // Check if user is admin
    const adminCheck = await isAdmin(ctx, strapi);
    if (!adminCheck) {
      return ctx.forbidden('Access denied. Admin role required.');
    }

    try {
      // Fetch all roles from users-permissions plugin
      const roles = await strapi.db.query('plugin::users-permissions.role').findMany({
        select: ['id', 'name', 'type', 'description'],
      });

      ctx.body = { roles };
    } catch (error) {
      console.error('Get roles error:', error);
      ctx.throw(500, 'Failed to fetch roles');
    }
  },

  async updateUserRole(ctx) {
    // Check if user is admin
    const adminCheck = await isAdmin(ctx, strapi);
    if (!adminCheck) {
      return ctx.forbidden('Access denied. Admin role required.');
    }

    const { id } = ctx.params;
    const { roleId } = ctx.request.body;

    if (!roleId) {
      return ctx.badRequest('Please provide roleId');
    }

    try {
      // Find user by numeric ID
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        filters: { id: parseInt(id, 10) },
      }) as any[];

      if (!users || users.length === 0) {
        return ctx.notFound('User not found');
      }

      const user = users[0];

      // Verify that the role exists
      const role = await strapi.db.query('plugin::users-permissions.role').findOne({
        where: { id: parseInt(roleId, 10) },
      });

      if (!role) {
        return ctx.badRequest('Role not found');
      }

      // In Strapi v5, we must use documentId for updates
      const documentId = user.documentId;
      if (!documentId) {
        console.error('No documentId found for user:', user);
        return ctx.badRequest('User document ID not found');
      }

      console.log('Updating user role with documentId:', documentId, 'roleId:', roleId);

      // Update user role using db query
      await strapi.db.query('plugin::users-permissions.user').update({
        where: { documentId: documentId },
        data: { role: parseInt(roleId, 10) },
      });

      ctx.body = { message: 'User role updated successfully', data: { role: role.name } };
    } catch (error) {
      console.error('User role update error:', error);
      ctx.throw(500, 'Failed to update user role');
    }
  },

  async resetUserProgress(ctx) {
    // Get user from token (user resetting their own progress)
    const tokenUser = await getUserFromToken(ctx, strapi);
    if (!tokenUser) {
      return ctx.unauthorized('Authentication required');
    }

    const userId = tokenUser.id;

    try {
      // Delete all quiz results for this user using Document Service API
      const allResults = await strapi.documents('api::quiz-result.quiz-result').findMany({
        status: 'published',
      });

      // Filter results by userId (since Strapi v5 doesn't support filtering by custom fields easily)
      const userResults = allResults.filter((result: any) => result.userId === userId);

      // Delete each result
      for (const result of userResults) {
        await strapi.documents('api::quiz-result.quiz-result').delete({
          documentId: result.documentId,
        });
      }

      console.log(`Reset progress for user ${userId}: deleted ${userResults.length} quiz results`);

      ctx.body = {
        message: 'Progress reset successfully',
        deletedCount: userResults.length,
      };
    } catch (error) {
      console.error('Reset progress error:', error);
      ctx.throw(500, 'Failed to reset progress');
    }
  },

  // Delete a user account
  async deleteUser(ctx) {
    const adminCheck = await isAdmin(ctx, strapi);
    if (!adminCheck) {
      return ctx.forbidden('Only admins can delete user accounts');
    }

    const tokenUser = await getUserFromToken(ctx, strapi);
    const { id } = ctx.params;

    try {
      // Prevent self-deletion
      if (tokenUser.id === parseInt(id)) {
        return ctx.badRequest('You cannot delete your own account');
      }

      // Delete all quiz results for this user first
      const allResults = await strapi.documents('api::quiz-result.quiz-result').findMany({
        status: 'published',
      });

      const userResults = allResults.filter((result: any) => result.userId === parseInt(id));

      for (const result of userResults) {
        await strapi.documents('api::quiz-result.quiz-result').delete({
          documentId: result.documentId,
        });
      }

      // Delete the user
      await strapi.plugins['users-permissions'].services.user.remove({ id });

      console.log(`Admin (ID: ${tokenUser.id}) deleted user ID ${id} and ${userResults.length} quiz results`);

      ctx.body = {
        message: 'User deleted successfully',
        deletedQuizResults: userResults.length,
      };
    } catch (error) {
      console.error('Delete user error:', error);
      ctx.throw(500, 'Failed to delete user');
    }
  },

  async requestPasswordReset(ctx) {
    const { email } = ctx.request.body;

    if (!email) {
      return ctx.badRequest('Please provide an email address');
    }

    try {
      // Find user by email
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        filters: { email: email.toLowerCase() },
      }) as any[];

      // Always return success even if user doesn't exist (security best practice)
      if (!users || users.length === 0) {
        console.log('Password reset requested for non-existent email:', email);
        return ctx.send({ message: 'If the email exists, a reset PIN has been sent' });
      }

      const user = users[0];

      // Generate 6-digit PIN
      const resetPin = Math.floor(100000 + Math.random() * 900000).toString();

      // Set PIN expiration (15 minutes from now)
      const pinExpiration = new Date(Date.now() + 15 * 60 * 1000);

      // Store PIN and expiration in user document
      const documentId = user.documentId;
      if (!documentId) {
        console.error('No documentId found for user:', user);
        return ctx.badRequest('User document ID not found');
      }

      await strapi.db.query('plugin::users-permissions.user').update({
        where: { documentId: documentId },
        data: {
          resetPasswordToken: resetPin,
          resetPasswordExpires: pinExpiration,
        },
      });

      // Send email with PIN
      try {
        await strapi.plugins['email'].services.email.send({
          to: email,
          from: 'noreply@rpesgc.local',
          subject: 'Password Reset PIN - RP ESGC',
          text: `Your password reset PIN is: ${resetPin}\n\nThis PIN will expire in 15 minutes.\n\nIf you did not request a password reset, please ignore this email.`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #2c5282;">Password Reset Request</h2>
              <p>You have requested to reset your password for your RP ESGC account.</p>
              <div style="background-color: #f7fafc; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p style="margin: 0; font-size: 14px; color: #4a5568;">Your password reset PIN is:</p>
                <h1 style="margin: 10px 0; font-size: 32px; color: #2c5282; letter-spacing: 4px;">${resetPin}</h1>
              </div>
              <p style="color: #e53e3e; font-weight: bold;">This PIN will expire in 15 minutes.</p>
              <p style="color: #718096; font-size: 14px;">If you did not request a password reset, please ignore this email and your password will remain unchanged.</p>
              <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 20px 0;">
              <p style="color: #a0aec0; font-size: 12px;">Republic Polytechnic ESGC Platform</p>
            </div>
          `,
        });
        console.log(`Password reset PIN sent to ${email}`);
      } catch (emailError) {
        console.error('Failed to send reset email:', emailError);
        return ctx.internalServerError('Failed to send reset email');
      }

      ctx.send({ message: 'If the email exists, a reset PIN has been sent' });
    } catch (error) {
      console.error('Request password reset error:', error);
      ctx.throw(500, 'Failed to process password reset request');
    }
  },

  async resetPasswordWithPin(ctx) {
    const { email, pin, newPassword } = ctx.request.body;

    if (!email || !pin || !newPassword) {
      return ctx.badRequest('Please provide email, PIN, and new password');
    }

    if (newPassword.length < 6) {
      return ctx.badRequest('Password must be at least 6 characters long');
    }

    try {
      // Find user by email
      const users = await strapi.entityService.findMany('plugin::users-permissions.user', {
        filters: { email: email.toLowerCase() },
      }) as any[];

      if (!users || users.length === 0) {
        return ctx.badRequest('Invalid email or PIN');
      }

      const user = users[0];

      // Check if PIN matches
      if (user.resetPasswordToken !== pin) {
        console.log('Invalid PIN attempt for email:', email);
        return ctx.badRequest('Invalid email or PIN');
      }

      // Check if PIN has expired
      const now = new Date();
      const expirationDate = new Date(user.resetPasswordExpires);

      console.log('Password reset debug:', {
        email,
        now: now.toISOString(),
        expirationDate: expirationDate.toISOString(),
        resetPasswordExpires: user.resetPasswordExpires,
        expired: now > expirationDate
      });

      if (!user.resetPasswordExpires || now.getTime() > expirationDate.getTime()) {
        console.log('Expired PIN used for email:', email);
        return ctx.badRequest('PIN has expired. Please request a new one.');
      }

      // Hash the new password
      const bcrypt = require('bcryptjs');
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update password and clear reset token
      const documentId = user.documentId;
      if (!documentId) {
        console.error('No documentId found for user:', user);
        return ctx.badRequest('User document ID not found');
      }

      await strapi.db.query('plugin::users-permissions.user').update({
        where: { documentId: documentId },
        data: {
          password: hashedPassword,
          resetPasswordToken: null,
          resetPasswordExpires: null,
        },
      });

      console.log(`Password successfully reset for user: ${email}`);

      ctx.send({ message: 'Password has been reset successfully' });
    } catch (error) {
      console.error('Reset password with PIN error:', error);
      ctx.throw(500, 'Failed to reset password');
    }
  },
});
