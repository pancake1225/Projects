import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::tag.tag' as any, ({ strapi }) => ({
  async find(ctx) {
    // Use db query to directly fetch tags with categories
    const tags = await strapi.db.query('api::tag.tag').findMany({
      populate: {
        category: true,
      },
    });

    return { data: tags };
  },

  async delete(ctx) {
    const { id } = ctx.params;

    try {
      console.log('Attempting to delete tag with ID:', id);

      // Use db query to delete directly
      const deletedTag = await strapi.db.query('api::tag.tag').delete({
        where: { id: parseInt(id) },
      });

      console.log('Tag deleted successfully:', deletedTag);

      return { data: deletedTag };
    } catch (error) {
      console.error('Error deleting tag:', error);
      ctx.throw(500, 'Failed to delete tag');
    }
  },
}));
