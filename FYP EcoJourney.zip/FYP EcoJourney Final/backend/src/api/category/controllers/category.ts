/**
 * category controller
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::category.category', ({ strapi }) => ({
  async update(ctx) {
    const { id } = ctx.params;
    const { data } = ctx.request.body;

    try {
      console.log('Updating category with ID:', id);
      console.log('Update data:', data);

      // Update the category (no draft/publish, direct update)
      const updatedCategory = await strapi.documents('api::category.category').update({
        documentId: id,
        data: {
          name: data.name,
          icon: data.icon,
        },
        populate: ['tags'],
      });

      console.log('Category updated successfully:', updatedCategory);

      // Return in the same format as default controller
      return this.transformResponse(updatedCategory);
    } catch (error) {
      console.error('Error updating category:', error);
      ctx.throw(500, 'Failed to update category');
    }
  },

  async delete(ctx) {
    const { id } = ctx.params;

    try {
      console.log('Attempting to delete category with ID:', id);

      // Use db query to delete directly
      const deletedCategory = await strapi.db.query('api::category.category').delete({
        where: { id: parseInt(id) },
      });

      console.log('Category deleted successfully:', deletedCategory);

      return { data: deletedCategory };
    } catch (error) {
      console.error('Error deleting category:', error);
      ctx.throw(500, 'Failed to delete category');
    }
  },
}));
