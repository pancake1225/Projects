/**
 * Server Session Controller
 *
 * This controller provides an endpoint to check the current server session ID.
 * The session ID changes every time the server restarts, which allows the frontend
 * to detect server restarts and log out users accordingly.
 *
 * This is useful for:
 * - Invalidating client sessions after server restart
 * - Ensuring users re-authenticate after deployments
 * - Security measure to prevent stale sessions
 */

import { serverSessionId } from '../../../index';

export default {
  /**
   * Get Server Session ID
   *
   * Returns the current server session ID. This ID is generated when the server
   * starts and remains constant until the server is restarted.
   *
   * Endpoint: GET /api/server-session
   * Authentication: Not required (public access)
   *
   * Response:
   * {
   *   sessionId: string  // UUID that changes on each server restart
   * }
   */
  async getSessionId(ctx) {
    return {
      sessionId: serverSessionId,
    };
  },
};
