/**
 * Server Session Routes
 *
 * Defines the route for the server session endpoint.
 * This endpoint is public (no authentication required) so the frontend
 * can check the session ID even before the user is logged in.
 */

export default {
  routes: [
    {
      method: 'GET',
      path: '/server-session',
      handler: 'server-session.getSessionId',
      config: {
        auth: false,  // Public endpoint - no authentication required
        policies: [],
        middlewares: [],
      },
    },
  ],
};
