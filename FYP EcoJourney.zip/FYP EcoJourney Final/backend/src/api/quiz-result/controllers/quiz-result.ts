/**
 * Quiz Result Controller
 *
 * This controller handles all quiz result operations including:
 * - Submitting quiz results (authenticated users only)
 * - Retrieving user's own quiz results (authenticated users only)
 * - Fetching aggregated leaderboard data (public access)
 *
 * The controller extends Strapi's core controller factory to add custom methods
 * while maintaining access to default CRUD operations if needed.
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::quiz-result.quiz-result', ({ strapi }) => ({

  /**
   * Submit Quiz Result
   *
   * This method allows authenticated users to submit their quiz results.
   * It automatically associates the result with the logged-in user.
   *
   * Endpoint: POST /api/quiz-results/submit
   * Authentication: Required (Bearer token)
   *
   * Request Body:
   * {
   *   data: {
   *     score: number,           // Number of correct answers
   *     totalQuestions: number,  // Total questions in the quiz
   *     percentage: number,      // Score percentage (0-100)
   *     points: number,          // Points earned (based on difficulty multiplier)
   *     maxPoints: number,       // Maximum possible points
   *     difficulty: string,      // 'easy', 'medium', or 'hard'
   *     quiz: number,            // Quiz ID (foreign key)
   *     completedAt: string      // ISO timestamp of completion
   *   }
   * }
   *
   * Why custom endpoint instead of default POST /quiz-results?
   * - Ensures user ID is set server-side (prevents spoofing)
   * - Automatically links to authenticated user
   * - Better permission control
   */
  async submitResult(ctx) {
    try {
      // AUTHENTICATION CHECK
      // ctx.state.user is populated by Strapi's JWT middleware when a valid token is provided
      // If no user is found, the request is not authenticated
      if (!ctx.state.user) {
        return ctx.unauthorized('You must be logged in to submit quiz results');
      }

      // EXTRACT REQUEST DATA
      // The frontend sends data wrapped in a 'data' object (Strapi convention)
      const { data } = ctx.request.body;

      // VALIDATION
      // Ensure required data is present
      if (!data) {
        return ctx.badRequest('Missing data in request body');
      }

      // Log incoming data for debugging
      console.log('[SubmitResult] Received:', {
        quizId: data.quiz,
        difficulty: data.difficulty,
        userId: ctx.state.user.id,
      });

      // CHECK FOR EXISTING RESULT
      // If user has already completed this quiz at the same difficulty, update instead of creating new
      // Different difficulty levels are tracked separately (user can have one score per difficulty)
      // This prevents "point farming" by retaking the same quiz at the same difficulty
      const existingResults = await strapi.entityService.findMany('api::quiz-result.quiz-result', {
        filters: {
          userId: ctx.state.user.id,
          difficulty: data.difficulty,
        },
        populate: { quiz: true },
      });

      // Filter by quiz documentId in JavaScript since Strapi relation filters can be tricky
      const matchingResults = (existingResults || []).filter((r: any) =>
        r.quiz?.documentId === data.quiz || r.quiz?.id?.toString() === data.quiz?.toString()
      );

      console.log('[SubmitResult] Found existing results:', matchingResults.length);

      const existingResult = matchingResults.length > 0 ? matchingResults[0] : null;

      let result;

      if (existingResult) {
        // UPDATE EXISTING RESULT
        // Replace previous score with new attempt (latest score wins)
        console.log('[SubmitResult] Updating existing result ID:', existingResult.id);

        result = await strapi.entityService.update('api::quiz-result.quiz-result', existingResult.id, {
          data: {
            score: data.score,
            totalQuestions: data.totalQuestions,
            percentage: data.percentage,
            points: data.points,
            maxPoints: data.maxPoints,
            difficulty: data.difficulty,
            completedAt: data.completedAt || new Date().toISOString(),
          },
          populate: { quiz: true },
        });

        console.log('[SubmitResult] Updated result with quiz:', (result as any).quiz?.id, (result as any).quiz?.slug);
      } else {
        // CREATE NEW QUIZ RESULT ENTRY
        // First time user is completing this quiz
        console.log('[SubmitResult] Creating new result for user:', ctx.state.user.id);

        result = await strapi.entityService.create('api::quiz-result.quiz-result', {
          data: {
            score: data.score,
            totalQuestions: data.totalQuestions,
            percentage: data.percentage,
            points: data.points,
            maxPoints: data.maxPoints,
            difficulty: data.difficulty,
            quiz: data.quiz,
            userId: ctx.state.user.id,
            username: ctx.state.user.username,
            completedAt: data.completedAt || new Date().toISOString(),
            users_permissions_user: ctx.state.user.id,
          },
          populate: { quiz: true },
        });

        console.log('[SubmitResult] Created result with quiz:', (result as any).quiz?.id, (result as any).quiz?.slug);
      }

      // Return the result (created or updated)
      return { data: result };
    } catch (error) {
      // Log error for debugging (visible in Strapi console)
      strapi.log.error('Error submitting quiz result:', error);
      return ctx.internalServerError('Failed to submit quiz result');
    }
  },

  /**
   * Get My Results
   *
   * Retrieves all quiz results for the currently authenticated user.
   * Results are sorted by completion date (newest first).
   *
   * Endpoint: GET /api/quiz-results/my-results
   * Authentication: Required (Bearer token)
   *
   * Response:
   * {
   *   data: [
   *     {
   *       id, score, totalQuestions, percentage, points,
   *       difficulty, completedAt, quiz: { id, title, slug }
   *     },
   *     ...
   *   ]
   * }
   *
   * Why custom endpoint instead of filtering default GET /quiz-results?
   * - Ensures users can only see their own results
   * - No need to expose userId filtering to frontend
   * - Simpler frontend code
   */
  async getMyResults(ctx) {
    try {
      // AUTHENTICATION CHECK
      if (!ctx.state.user) {
        return ctx.unauthorized('You must be logged in to view your results');
      }

      // FETCH USER'S RESULTS
      // Using entityService.findMany with filters and populate
      const results = await strapi.entityService.findMany('api::quiz-result.quiz-result', {
        // Filter by the authenticated user's ID
        filters: {
          userId: ctx.state.user.id,
        },
        // Populate the quiz relation to get quiz details (title, slug)
        populate: { quiz: true },
        // Sort by completion date, newest first
        sort: { completedAt: 'desc' },
      });

      return { data: results };
    } catch (error) {
      strapi.log.error('Error fetching quiz results:', error);
      return ctx.internalServerError('Failed to fetch quiz results');
    }
  },

  /**
   * Get Leaderboard
   *
   * Fetches and aggregates all quiz results to create a leaderboard.
   * This is a PUBLIC endpoint - no authentication required.
   *
   * Endpoint: GET /api/quiz-results/leaderboard
   * Authentication: Not required (public access)
   *
   * Response:
   * {
   *   data: [
   *     { id, username, points, quizzesTaken, rank },
   *     ...
   *   ],
   *   rawResults: [...] // Raw quiz results for filtering on frontend
   * }
   *
   * How aggregation works:
   * 1. Fetch ALL quiz results from database
   * 2. Group results by userId
   * 3. Sum up points and count quizzes for each user
   * 4. Sort by total points (descending)
   * 5. Assign ranks (1st, 2nd, 3rd, etc.)
   */
  async getLeaderboard(ctx) {
    try {
      // FETCH ALL QUIZ RESULTS
      // No filters - we need all results to calculate totals
      const results = await strapi.entityService.findMany('api::quiz-result.quiz-result', {
        populate: ['quiz'],  // Include quiz data for filtering on frontend
        sort: { createdAt: 'desc' },
      });

      // AGGREGATE SCORES BY USER
      // Using a Record (object) to group results by userId
      // Key: userId, Value: { id, username, points, quizzesTaken }
      const userScores: Record<number, { id: number; username: string; points: number; quizzesTaken: number }> = {};

      // Loop through each quiz result
      results.forEach((result: any) => {
        const userId = result.userId;
        const username = result.username;
        // Use points if available, fallback to score
        const pointsValue = result.points || result.score || 0;

        // Only process results with valid user data
        if (userId && username) {
          // Initialize user entry if first result for this user
          if (!userScores[userId]) {
            userScores[userId] = {
              id: userId,
              username: username,
              points: 0,
              quizzesTaken: 0,
            };
          }

          // Add this result's points to user's total
          userScores[userId].points += pointsValue;
          // Increment quiz count
          userScores[userId].quizzesTaken += 1;
        }
      });

      // CONVERT TO SORTED ARRAY WITH RANKS (handling ties)
      const sortedUsers = Object.values(userScores)
        // Remove users with 0 points
        .filter((u) => u.points > 0)
        // Sort by points (highest first)
        .sort((a, b) => b.points - a.points);

      // Assign ranks with tie handling (standard competition ranking)
      // Users with same points get the same rank
      // Example: T-1, T-1, 3rd (not 1st, 2nd, 3rd)
      let currentRank = 1;
      const leaderboard = sortedUsers.map((u, index) => {
        // If not first user and has different points than previous, update rank
        if (index > 0 && u.points < sortedUsers[index - 1].points) {
          currentRank = index + 1;  // Rank equals position (skips tied positions)
        }

        // Check if this position is tied (same points as previous or next user)
        const hasSamePointsAsPrev = index > 0 && u.points === sortedUsers[index - 1].points;
        const hasSamePointsAsNext = index < sortedUsers.length - 1 && u.points === sortedUsers[index + 1].points;
        const isTied = hasSamePointsAsPrev || hasSamePointsAsNext;

        return {
          ...u,
          rank: currentRank,
          isTied,  // Flag to indicate if this rank is shared
        };
      });

      // Return both aggregated leaderboard and raw results
      // rawResults allows frontend to re-aggregate when filtering by quiz/category
      return { data: leaderboard, rawResults: results };
    } catch (error) {
      strapi.log.error('Error fetching leaderboard:', error);
      return ctx.internalServerError('Failed to fetch leaderboard');
    }
  },
}));
