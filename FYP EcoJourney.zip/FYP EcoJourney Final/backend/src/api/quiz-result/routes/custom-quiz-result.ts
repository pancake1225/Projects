/**
 * Custom Routes for Quiz Results API
 *
 * This file defines custom routes for the quiz-result content-type.
 * These routes map HTTP endpoints to controller methods.
 *
 * Why Custom Routes?
 * ------------------
 * Strapi automatically generates CRUD routes (GET, POST, PUT, DELETE) for content-types,
 * but we need custom endpoints for specific functionality:
 *
 * 1. /submit - Ensures user ID is set server-side (prevents spoofing)
 * 2. /my-results - Returns only the authenticated user's results
 * 3. /leaderboard - Aggregates all results into a ranked leaderboard
 *
 * Route Structure:
 * ----------------
 * Each route object contains:
 * - method: HTTP method (GET, POST, PUT, DELETE)
 * - path: URL path (relative to /api)
 * - handler: Controller method to handle the request (format: 'controller-name.methodName')
 * - config: Optional configuration for policies and middlewares
 *
 * Permission Configuration:
 * -------------------------
 * Permissions for these routes are set in the bootstrap function (src/index.ts)
 * - submitResult: Authenticated users only
 * - getMyResults: Authenticated users only
 * - getLeaderboard: Public access (both authenticated and unauthenticated)
 *
 * How Strapi Routes Work:
 * -----------------------
 * 1. Request comes in to /api/quiz-results/submit
 * 2. Strapi matches it to this route configuration
 * 3. Strapi calls quiz-result.submitResult controller method
 * 4. Controller processes request and returns response
 */

export default {
  routes: [
    /**
     * Submit Quiz Result
     *
     * POST /api/quiz-results/submit
     *
     * Allows authenticated users to submit their quiz results.
     * The controller automatically sets the user ID from the JWT token.
     *
     * Request Body:
     * {
     *   data: {
     *     score: number,
     *     totalQuestions: number,
     *     percentage: number,
     *     points: number,
     *     maxPoints: number,
     *     difficulty: string,
     *     quiz: number (Quiz ID),
     *     completedAt: string (ISO date)
     *   }
     * }
     */
    {
      method: 'POST',
      path: '/quiz-results/submit',
      handler: 'quiz-result.submitResult',
      config: {
        policies: [],      // No additional policies (auth handled in controller)
        middlewares: [],   // No additional middlewares
      },
    },

    /**
     * Get My Results
     *
     * GET /api/quiz-results/my-results
     *
     * Returns all quiz results for the authenticated user.
     * Results are sorted by completion date (newest first).
     *
     * Response:
     * {
     *   data: [
     *     { id, score, totalQuestions, percentage, points, difficulty, completedAt, quiz: {...} },
     *     ...
     *   ]
     * }
     */
    {
      method: 'GET',
      path: '/quiz-results/my-results',
      handler: 'quiz-result.getMyResults',
      config: {
        policies: [],
        middlewares: [],
      },
    },

    /**
     * Get Leaderboard
     *
     * GET /api/quiz-results/leaderboard
     *
     * Returns aggregated leaderboard data (public endpoint).
     * Sums up points for each user and ranks them.
     *
     * Response:
     * {
     *   data: [
     *     { id, username, points, quizzesTaken, rank },
     *     ...
     *   ],
     *   rawResults: [...] // Raw results for frontend filtering
     * }
     */
    {
      method: 'GET',
      path: '/quiz-results/leaderboard',
      handler: 'quiz-result.getLeaderboard',
      config: {
        policies: [],
        middlewares: [],
      },
    },
  ],
};
