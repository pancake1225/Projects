/**
 * Article Lifecycle Hooks
 *
 * Sends email notifications to all admins when articles are published, updated, or deleted.
 * Distinguishes between newly created articles and updated articles.
 */

// Store to capture article data before deletion
const deletedArticleData = new Map<string, any>();

// Track sent delete emails to prevent duplicates (Strapi triggers delete twice for draft/published)
const sentDeleteEmails = new Set<string>();

// Track documentIds that had a version deleted recently (to detect update vs new in afterCreate)
const recentlyDeletedDocIds = new Set<string>();

export default {
  // afterCreate triggers for both new articles AND updates (Strapi v5 deletes old draft + creates new record)
  async afterCreate(event) {
    const { result } = event;
    console.log('[Article] afterCreate triggered:', result.documentId);

    if (result.publishedAt) {
      const isUpdate = recentlyDeletedDocIds.has(result.documentId);
      if (isUpdate) {
        recentlyDeletedDocIds.delete(result.documentId);
      }
      console.log('[Article] afterCreate - isUpdate:', isUpdate);
      await sendArticleEmail(result, !isUpdate);
    }
  },

  // afterUpdate triggers when updating an existing record in-place
  async afterUpdate(event) {
    const { result } = event;
    console.log('[Article] afterUpdate triggered:', result.documentId);

    if (result.publishedAt) {
      await sendArticleEmail(result, false);
    }
  },

  // Capture article data before deletion
  async beforeDelete(event) {
    const { params } = event;
    const internalId = params.where?.id;
    console.log('[Article] beforeDelete id:', internalId);

    if (internalId) {
      try {
        let deletedByEmail = 'Unknown';
        try {
          const ctx = strapi.requestContext.get();
          if (ctx?.state?.user?.email) {
            deletedByEmail = ctx.state.user.email;
          }
        } catch (e) {}

        const article: any = await strapi.db.query('api::article.article').findOne({
          where: { id: internalId },
          populate: ['category'],
        });

        if (article) {
          // Track this documentId so afterCreate can detect updates vs new
          recentlyDeletedDocIds.add(article.documentId);
          setTimeout(() => recentlyDeletedDocIds.delete(article.documentId), 10000);

          // Look up tag names
          let tagNames = 'None';
          if (article.tags) {
            try {
              const tagIds = article.tags.split(',').map((id: string) => parseInt(id.trim())).filter(Boolean);
              if (tagIds.length > 0) {
                const tags = await strapi.db.query('api::tag.tag').findMany({
                  where: { id: { $in: tagIds } },
                });
                tagNames = tags.map((t: any) => t.name).join(', ') || 'None';
              }
            } catch (e) {
              tagNames = article.tags;
            }
          }

          deletedArticleData.set(String(internalId), {
            title: article.title,
            slug: article.slug,
            description: article.description,
            documentId: article.documentId,
            categoryName: article.category?.name || 'Uncategorized',
            tagNames,
            authorEmail: article.authorEmail || 'Unknown',
            deletedByEmail,
          });
        }
      } catch (error) {
        console.error('Error capturing article data before delete:', error);
      }
    }
  },

  // Send notification after article is deleted (with delayed check to avoid false triggers during updates)
  async afterDelete(event) {
    const { params } = event;
    const internalId = params.where?.id;
    console.log('[Article] afterDelete id:', internalId);

    if (internalId) {
      const articleData = deletedArticleData.get(String(internalId));
      deletedArticleData.delete(String(internalId));

      if (articleData?.documentId) {
        // Wait briefly then check if document still exists (update = still exists, real delete = gone)
        setTimeout(async () => {
          try {
            const stillExists = await strapi.db.query('api::article.article').findOne({
              where: { documentId: articleData.documentId },
            });

            if (stillExists) {
              console.log('[Article] Document still exists after delete - this was an update, skipping delete email');
              return;
            }

            // Document is truly gone - send delete email (but prevent duplicates)
            const emailKey = articleData.slug || articleData.title;
            if (sentDeleteEmails.has(emailKey)) {
              console.log('[Article] Skipping duplicate delete email for:', emailKey);
              return;
            }

            sentDeleteEmails.add(emailKey);
            console.log('[Article] Document fully deleted, sending delete email for:', articleData.title);
            await sendArticleDeleteEmail(articleData);
            setTimeout(() => sentDeleteEmails.delete(emailKey), 5000);
          } catch (error) {
            console.error('[Article] Error in delayed delete check:', error);
          }
        }, 1500);
      }
    }
  },
};

/**
 * Send email notification to all admins about article publish/update
 */
async function sendArticleEmail(article: any, isNew: boolean) {
  console.log('[Article] Attempting to send email for:', article.title, isNew ? '(NEW)' : '(UPDATED)');

  try {
    const adminRole = await strapi.db.query('plugin::users-permissions.role').findOne({
      where: { type: 'admin' },
    });

    if (!adminRole) {
      console.log('No admin role found');
      return;
    }

    const adminUsers = await strapi.db.query('plugin::users-permissions.user').findMany({
      where: { role: adminRole.id },
    });

    if (adminUsers.length === 0) {
      console.log('No admin users found');
      return;
    }

    const adminEmails = adminUsers.map((user: any) => user.email).filter(Boolean);
    console.log('Sending to admins:', adminEmails);

    // Fetch full article with relations
    const fullArticle: any = await strapi.documents('api::article.article').findFirst({
      filters: { documentId: article.documentId },
      populate: ['category'],
      status: 'published',
    });

    const categoryName = fullArticle?.category?.name || 'Uncategorized';

    // Tags is a string field storing IDs like "153, 155" - look up actual names
    let tagNames = 'None';
    if (fullArticle?.tags) {
      try {
        const tagIds = fullArticle.tags.split(',').map((id: string) => parseInt(id.trim())).filter(Boolean);
        if (tagIds.length > 0) {
          const tags = await strapi.db.query('api::tag.tag').findMany({
            where: { id: { $in: tagIds } },
          });
          tagNames = tags.map((t: any) => t.name).join(', ') || 'None';
        }
      } catch (e) {
        console.log('Could not fetch tag names:', e);
        tagNames = fullArticle.tags;
      }
    }

    const creatorEmail = fullArticle?.authorEmail || 'Unknown';
    const updaterEmail = fullArticle?.lastUpdatedByEmail || creatorEmail;

    const statusText = isNew ? 'NEW ARTICLE PUBLISHED' : 'ARTICLE UPDATED';
    const statusColor = isNew ? '#059669' : '#0284c7';

    const emailService = strapi.plugin('email').service('email');

    for (const adminEmail of adminEmails) {
      await emailService.send({
        to: adminEmail,
        from: process.env.SMTP_DEFAULT_FROM || process.env.SMTP_USERNAME,
        subject: `${statusText}: ${article.title}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, ${statusColor} 0%, #52b788 100%); padding: 30px; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0;">${statusText}</h1>
            </div>
            <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px;">
              <div style="background: ${isNew ? '#d1fae5' : '#dbeafe'}; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                <strong style="color: ${statusColor};">${isNew ? 'This is a brand new article' : 'This article has been updated'}</strong>
              </div>

              <h2 style="color: #1b4332; margin-top: 0;">Article Details</h2>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666; width: 120px;"><strong>Title:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${article.title}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Category:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${categoryName}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Tags:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${tagNames}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Slug:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937; font-family: monospace; background: #f3f4f6; padding: 4px 8px; border-radius: 4px;">${article.slug}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>${isNew ? 'Created by:' : 'Updated by:'}</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${isNew ? creatorEmail : updaterEmail}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Date:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${new Date().toLocaleString()}</td>
                </tr>
              </table>

              <div style="margin-top: 20px; padding: 16px; background: white; border: 1px solid #e5e7eb; border-radius: 8px;">
                <strong style="color: #374151;">Description:</strong>
                <p style="margin: 8px 0 0; color: #4b5563;">${article.description || 'No description provided'}</p>
              </div>

            </div>
            <div style="text-align: center; margin-top: 20px; color: #999; font-size: 12px;">
              <p>EcoJourney - RP ESG Centre Sustainability Awareness Platform</p>
            </div>
          </div>
        `,
      });
    }

    console.log(`[Article] Admin emails sent successfully for: ${article.title} (${isNew ? 'NEW' : 'UPDATED'})`);
  } catch (error) {
    console.error('[Article] Failed to send admin email:', error);
    console.error('Error details:', error.message);
  }
}

/**
 * Send email notification to all admins about article deletion
 */
async function sendArticleDeleteEmail(articleData: any) {
  console.log('[Article] Attempting to send delete notification for:', articleData.title);

  try {
    const adminRole = await strapi.db.query('plugin::users-permissions.role').findOne({
      where: { type: 'admin' },
    });

    if (!adminRole) {
      console.log('No admin role found');
      return;
    }

    const adminUsers = await strapi.db.query('plugin::users-permissions.user').findMany({
      where: { role: adminRole.id },
    });

    if (adminUsers.length === 0) {
      console.log('No admin users found');
      return;
    }

    const adminEmails = adminUsers.map((user: any) => user.email).filter(Boolean);

    const emailService = strapi.plugin('email').service('email');

    for (const adminEmail of adminEmails) {
      await emailService.send({
        to: adminEmail,
        from: process.env.SMTP_DEFAULT_FROM || process.env.SMTP_USERNAME,
        subject: `ARTICLE DELETED: ${articleData.title}`,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="background: linear-gradient(135deg, #dc2626 0%, #ef4444 100%); padding: 30px; border-radius: 10px 10px 0 0;">
              <h1 style="color: white; margin: 0;">ARTICLE DELETED</h1>
            </div>
            <div style="background: #f8f9fa; padding: 30px; border-radius: 0 0 10px 10px;">
              <div style="background: #fee2e2; padding: 12px 16px; border-radius: 8px; margin-bottom: 20px;">
                <strong style="color: #dc2626;">This article has been permanently deleted</strong>
              </div>

              <h2 style="color: #1b4332; margin-top: 0;">Deleted Article Details</h2>
              <table style="width: 100%; border-collapse: collapse;">
                <tr>
                  <td style="padding: 8px 0; color: #666; width: 120px;"><strong>Title:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${articleData.title}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Category:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${articleData.categoryName}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Tags:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${articleData.tagNames}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Slug:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937; font-family: monospace; background: #f3f4f6; padding: 4px 8px; border-radius: 4px;">${articleData.slug}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Author:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${articleData.authorEmail}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Deleted by:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${articleData.deletedByEmail || 'Unknown'}</td>
                </tr>
                <tr>
                  <td style="padding: 8px 0; color: #666;"><strong>Deleted at:</strong></td>
                  <td style="padding: 8px 0; color: #1f2937;">${new Date().toLocaleString()}</td>
                </tr>
              </table>

              <div style="margin-top: 20px; padding: 16px; background: white; border: 1px solid #e5e7eb; border-radius: 8px;">
                <strong style="color: #374151;">Description:</strong>
                <p style="margin: 8px 0 0; color: #4b5563;">${articleData.description || 'No description provided'}</p>
              </div>
            </div>
            <div style="text-align: center; margin-top: 20px; color: #999; font-size: 12px;">
              <p>EcoJourney - RP ESG Centre Sustainability Awareness Platform</p>
            </div>
          </div>
        `,
      });
    }

    console.log(`[Article] Delete notification sent successfully for: ${articleData.title}`);
  } catch (error) {
    console.error('[Article] Failed to send delete notification:', error);
    console.error('Error details:', error.message);
  }
}
