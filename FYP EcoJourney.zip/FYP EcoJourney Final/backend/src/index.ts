/**
 * Strapi Application Bootstrap & Registration
 *
 * This is the main entry point for Strapi lifecycle hooks.
 * It contains two key functions:
 *
 * 1. register() - Runs BEFORE the application is initialized
 *    - Used to extend Strapi's functionality
 *    - Good for registering custom plugins, fields, or middleware
 *
 * 2. bootstrap() - Runs AFTER the application is initialized but BEFORE it starts
 *    - Used for setup tasks like seeding data, configuring permissions
 *    - The database is available at this point
 *
 * This file handles:
 * - Windows EPERM error suppression (Sharp image library file locking issues)
 * - Auto-granting permissions for custom quiz-result endpoints
 */

import type { Core } from '@strapi/strapi';
import crypto from 'crypto';

// Generate a unique server session ID on startup
// This changes every time the server restarts
export const serverSessionId = crypto.randomUUID();

export default {
  /**
   * Register Function
   *
   * Runs before the application is initialized.
   * This gives you an opportunity to extend Strapi's code.
   *
   * In this case, we're setting up a global error handler to suppress
   * EPERM (permission) errors that occur on Windows when the Sharp
   * image processing library tries to delete temporary files that
   * are still locked by the system.
   *
   * Why is this needed?
   * -------------------
   * On Windows, files can be "locked" while in use. When Sharp processes
   * images, it creates temporary files. Sometimes Windows keeps these
   * files locked even after Sharp is done with them. When Sharp tries
   * to delete them, it gets an EPERM error. This is harmless - the OS
   * will eventually clean up these temp files - but it causes ugly
   * errors in the console.
   *
   * @param strapi - The Strapi instance (not used here but available)
   */
  register({ strapi }: { strapi: Core.Strapi }) {
    // Set up a global handler for unhandled promise rejections
    // This catches errors that bubble up without being caught
    process.on('unhandledRejection', (reason: any, promise) => {
      // Check if this is an EPERM error from file deletion
      // reason.code === 'EPERM' means "Operation not permitted"
      // reason.syscall === 'unlink' means the operation was file deletion
      if (reason?.code === 'EPERM' && reason?.syscall === 'unlink') {
        // Log a friendly message instead of an ugly error stack trace
        // The files will be cleaned up by the OS temp directory cleaner
        console.log('Suppressed EPERM error during file cleanup (Windows file locking)');
        return; // Don't throw - just suppress this error
      }
      // For any other unhandled rejections, re-throw them
      // so they can be handled normally (or crash the app if truly fatal)
      throw reason;
    });
  },

  /**
   * Bootstrap Function
   *
   * Runs before the application gets started, but after initialization.
   * The database is available at this point.
   *
   * This function does two things:
   * 1. Patches the Sharp image manipulation service to handle Windows file locking
   * 2. Auto-grants permissions for our custom quiz-result API endpoints
   *
   * @param strapi - The Strapi instance
   */
  async bootstrap({ strapi }: { strapi: Core.Strapi }) {
    // =========================================================================
    // PART 1: PATCH IMAGE MANIPULATION SERVICE
    // =========================================================================
    // Get reference to Strapi's upload plugin (handles file uploads and images)
    const uploadPlugin = strapi.plugin('upload');

    if (uploadPlugin) {
      // Get the image manipulation service (processes images with Sharp library)
      const imageManipulation = uploadPlugin.service('image-manipulation');

      if (imageManipulation) {
        // -----------------------------------------------------------------
        // Patch the optimize() method
        // -----------------------------------------------------------------
        // This method compresses/optimizes uploaded images
        // We wrap it to catch and suppress EPERM errors
        const originalOptimize = imageManipulation.optimize;
        if (originalOptimize) {
          imageManipulation.optimize = async function(...args: any[]) {
            try {
              // Try to run the original optimize function
              return await originalOptimize.apply(this, args);
            } catch (err: any) {
              // If it's an EPERM error (Windows file locking), suppress it
              if (err?.code === 'EPERM') {
                console.log('Suppressed EPERM error during image optimization');
                return args[0]; // Return the original file without optimization
              }
              // For other errors, re-throw them
              throw err;
            }
          };
        }

        // -----------------------------------------------------------------
        // Disable thumbnail generation
        // -----------------------------------------------------------------
        // Thumbnail generation causes many file operations and can trigger
        // EPERM errors. For this project, we don't need thumbnails.
        imageManipulation.generateThumbnail = async () => null;

        // -----------------------------------------------------------------
        // Disable responsive image formats
        // -----------------------------------------------------------------
        // Responsive formats (multiple sizes for different devices) also
        // cause many file operations. Disabled to prevent EPERM errors.
        imageManipulation.generateResponsiveFormats = async () => [];
      }
    }

    // =========================================================================
    // PART 2: AUTO-GRANT PERMISSIONS FOR CUSTOM QUIZ-RESULT ENDPOINTS
    // =========================================================================
    // Why auto-grant permissions?
    // ---------------------------
    // Strapi's permission system requires explicit permission grants for
    // custom endpoints. Without this, users would get "Forbidden" errors
    // even when logged in. By auto-granting in bootstrap, permissions are
    // set up automatically whenever the server starts.
    //
    // Permission Types:
    // - submitResult: Only authenticated users (logged in) can submit results
    // - getMyResults: Only authenticated users can view their own results
    // - getLeaderboard: Both public (not logged in) and authenticated users
    //   can view the leaderboard

    try {
      // -----------------------------------------------------------------
      // Find the "authenticated" role
      // -----------------------------------------------------------------
      // Strapi has built-in roles: 'public' (not logged in) and 'authenticated' (logged in)
      // We need to grant permissions to these roles
      const authenticatedRole = await strapi
        .query('plugin::users-permissions.role')
        .findOne({ where: { type: 'authenticated' } });

      if (authenticatedRole) {
        // -----------------------------------------------------------------
        // Grant submitResult permission to authenticated users
        // -----------------------------------------------------------------
        // Check if permission already exists (avoid duplicates)
        const submitPermission = await strapi
          .query('plugin::users-permissions.permission')
          .findOne({
            where: {
              role: authenticatedRole.id,
              // Action format: 'api::<content-type>.<controller>.<method>'
              action: 'api::quiz-result.quiz-result.submitResult',
            },
          });

        // Only create permission if it doesn't exist
        if (!submitPermission) {
          await strapi.query('plugin::users-permissions.permission').create({
            data: {
              action: 'api::quiz-result.quiz-result.submitResult',
              role: authenticatedRole.id,
            },
          });
          console.log('Added submitResult permission for authenticated users');
        }

        // -----------------------------------------------------------------
        // Grant getMyResults permission to authenticated users
        // -----------------------------------------------------------------
        const getMyResultsPermission = await strapi
          .query('plugin::users-permissions.permission')
          .findOne({
            where: {
              role: authenticatedRole.id,
              action: 'api::quiz-result.quiz-result.getMyResults',
            },
          });

        if (!getMyResultsPermission) {
          await strapi.query('plugin::users-permissions.permission').create({
            data: {
              action: 'api::quiz-result.quiz-result.getMyResults',
              role: authenticatedRole.id,
            },
          });
          console.log('Added getMyResults permission for authenticated users');
        }
      }

      // -----------------------------------------------------------------
      // Grant getLeaderboard permission to BOTH public and authenticated
      // -----------------------------------------------------------------
      // The leaderboard should be visible to everyone, even users who
      // are not logged in. So we grant to both roles.
      const publicRole = await strapi
        .query('plugin::users-permissions.role')
        .findOne({ where: { type: 'public' } });

      // Create array of roles to grant leaderboard permission to
      // filter(Boolean) removes any null/undefined values
      const roles = [authenticatedRole, publicRole].filter(Boolean);

      // Loop through each role and grant permission
      for (const role of roles) {
        const leaderboardPermission = await strapi
          .query('plugin::users-permissions.permission')
          .findOne({
            where: {
              role: role.id,
              action: 'api::quiz-result.quiz-result.getLeaderboard',
            },
          });

        if (!leaderboardPermission) {
          await strapi.query('plugin::users-permissions.permission').create({
            data: {
              action: 'api::quiz-result.quiz-result.getLeaderboard',
              role: role.id,
            },
          });
          console.log(`Added getLeaderboard permission for ${role.type} users`);
        }
      }
    } catch (err) {
      // Log error but don't crash the server
      // Permissions might already exist, or there could be a DB issue
      console.error('Error setting up quiz-result permissions:', err);
    }
  },
};
