'use strict';

module.exports = async (policyContext, config, { strapi }) => {
  // Check if user is authenticated
  if (!policyContext.state.user) {
    return false;
  }

  const userId = policyContext.state.user.id;

  // Fetch user with role populated
  const user = await strapi.entityService.findOne('plugin::users-permissions.user', userId, {
    populate: ['role'],
  });

  if (!user || !user.role) {
    return false;
  }

  // Check if user has admin role (by type or name)
  const isAdmin = user.role.type === 'admin' || user.role.name === 'Admin';

  return isAdmin;
};
