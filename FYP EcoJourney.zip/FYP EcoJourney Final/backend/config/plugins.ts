export default ({ env }) => ({
  email: {
    config: {
      provider: 'nodemailer',
      providerOptions: {
        host: env('SMTP_HOST', 'localhost'),
        port: parseInt(env('SMTP_PORT', '1025')),
        secure: env('SMTP_HOST') !== 'localhost' && parseInt(env('SMTP_PORT', '1025')) === 465,
        auth: env('SMTP_HOST') === 'localhost' ? null : {
          user: env('SMTP_USERNAME'),
          pass: env('SMTP_PASSWORD'),
        },
      },
      settings: {
        defaultFrom: env('SMTP_DEFAULT_FROM', 'noreply@rpesgc.local'),
        defaultReplyTo: env('SMTP_DEFAULT_REPLY_TO', 'noreply@rpesgc.local'),
      },
    },
  },
  upload: {
    config: {
      sizeLimit: 200 * 1024 * 1024, // 200MB
      // Completely disable image optimization to prevent Windows file permission errors
      // Sharp tries to optimize images and create responsive sizes, but on Windows
      // it cannot delete temporary files, causing EPERM errors
      breakpoints: {},
      // Disable image optimization
      sizeOptimization: false,
      responsiveDimensions: false,
    },
  },
});