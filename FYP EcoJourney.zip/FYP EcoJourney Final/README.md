# EcoJourney

A sustainability education platform built for the RP ESG Centre. Features articles, quizzes, a leaderboard, and an AI-powered chatbot to promote environmental awareness.

## Tech Stack

- **Frontend:** React 18
- **Backend/CMS:** Strapi v5
- **Database:** SQLite
- **AI Chatbot:** Groq API (Llama 3.3 70B) with RAG
- **Auth:** JWT
- **Email:** SMTP
