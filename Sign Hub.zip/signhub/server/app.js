const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const os = require('os');
const initSqlJs = require('sql.js');
const sharp = require('sharp');
const { v4: uuidv4 } = require('uuid');
const { Bonjour } = require('bonjour-service');

const app = express();
const PORT = process.env.PORT || 3000;
const UPLOAD_DIR = path.join(__dirname, '../public/uploads');
const THUMB_DIR = path.join(__dirname, '../public/thumbnails');
const DB_PATH = path.join(__dirname, 'signage.db');

// Ensure directories exist
[UPLOAD_DIR, THUMB_DIR].forEach(dir => {
    if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
    }
});

let rawDb;

const db = {
    exec(sql) {
        rawDb.run(sql);
        this._save();
    },
    prepare(sql) {
        return {
            get(...params) {
                const stmt = rawDb.prepare(sql);
                stmt.bind(params);
                let row = null;
                if (stmt.step()) {
                    const cols = stmt.getColumnNames();
                    const vals = stmt.get();
                    row = {};
                    cols.forEach((c, i) => row[c] = vals[i]);
                }
                stmt.free();
                return row;
            },
            all(...params) {
                const stmt = rawDb.prepare(sql);
                stmt.bind(params);
                const rows = [];
                while (stmt.step()) {
                    const cols = stmt.getColumnNames();
                    const vals = stmt.get();
                    const row = {};
                    cols.forEach((c, i) => row[c] = vals[i]);
                    rows.push(row);
                }
                stmt.free();
                return rows;
            },
            run(...params) {
                rawDb.run(sql, params);
                db._save();
            }
        };
    },
    _save() {
        const data = rawDb.export();
        fs.writeFileSync(DB_PATH, Buffer.from(data));
    }
};

async function main() {
    const SQL = await initSqlJs();

    if (fs.existsSync(DB_PATH)) {
        const fileBuffer = fs.readFileSync(DB_PATH);
        rawDb = new SQL.Database(fileBuffer);
    } else {
        rawDb = new SQL.Database();
    }

    // Create tables
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS displays (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            group_id TEXT DEFAULT 'default',
            status TEXT DEFAULT 'offline',
            last_seen INTEGER,
            ip_address TEXT,
            resolution TEXT,
            current_media_id TEXT,
            scale INTEGER DEFAULT 100,
            volume INTEGER DEFAULT 100,
            cpu_temp REAL,
            uptime INTEGER,
            created_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS groups (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            created_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS media (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            original_name TEXT NOT NULL,
            mime_type TEXT NOT NULL,
            size INTEGER,
            duration INTEGER DEFAULT 10,
            thumbnail TEXT,
            created_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS playlists (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT,
            is_default INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT (strftime('%s', 'now'))
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS playlist_items (
            id TEXT PRIMARY KEY,
            playlist_id TEXT NOT NULL,
            media_id TEXT NOT NULL,
            position INTEGER NOT NULL,
            duration INTEGER DEFAULT 10,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
            FOREIGN KEY (media_id) REFERENCES media(id) ON DELETE CASCADE
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS display_assignments (
            display_id TEXT PRIMARY KEY,
            playlist_id TEXT,
            updated_at INTEGER DEFAULT (strftime('%s', 'now')),
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE SET NULL
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS commands (
            id TEXT PRIMARY KEY,
            display_id TEXT NOT NULL,
            command TEXT NOT NULL,
            payload TEXT,
            created_at INTEGER DEFAULT (strftime('%s', 'now')),
            executed INTEGER DEFAULT 0
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS schedules (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            playlist_id TEXT NOT NULL,
            target_type TEXT NOT NULL,
            target_id TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            days_of_week TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            priority INTEGER DEFAULT 0,
            created_at INTEGER DEFAULT (strftime('%s', 'now')),
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE
        )
    `);
    rawDb.run(`
        CREATE TABLE IF NOT EXISTS group_assignments (
            id TEXT PRIMARY KEY,
            group_id TEXT NOT NULL,
            playlist_id TEXT,
            updated_at INTEGER DEFAULT (strftime('%s', 'now')),
            FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE,
            FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE SET NULL
        )
    `);

    // Migrations for new columns
    try { rawDb.run('ALTER TABLE displays ADD COLUMN scale INTEGER DEFAULT 100'); } catch (e) {}
    try { rawDb.run('ALTER TABLE displays ADD COLUMN volume INTEGER DEFAULT 100'); } catch (e) {}
    try { rawDb.run('ALTER TABLE displays ADD COLUMN cpu_temp REAL'); } catch (e) {}
    try { rawDb.run('ALTER TABLE displays ADD COLUMN uptime INTEGER'); } catch (e) {}

    db._save();

    // Insert default group if not exists
    const defaultGroup = db.prepare('SELECT * FROM groups WHERE id = ?').get('default');
    if (!defaultGroup) {
        db.prepare('INSERT INTO groups (id, name, description) VALUES (?, ?, ?)')
            .run('default', 'All Displays', 'Default group for all displays');
    }

    // ============================================
    // Middleware
    // ============================================

    app.use(express.json());
    app.use(express.static(path.join(__dirname, '../public')));

    app.use((req, res, next) => {
        res.header('Access-Control-Allow-Origin', '*');
        res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
        res.header('Access-Control-Allow-Headers', 'Content-Type');
        next();
    });

    // Configure multer for file uploads
    const storage = multer.diskStorage({
        destination: (req, file, cb) => cb(null, UPLOAD_DIR),
        filename: (req, file, cb) => {
            const ext = path.extname(file.originalname);
            cb(null, `${uuidv4()}${ext}`);
        }
    });

    const upload = multer({
        storage,
        limits: { fileSize: 500 * 1024 * 1024 },
        fileFilter: (req, file, cb) => {
            const allowedTypes = /jpeg|jpg|png|gif|webp|mp4|webm|mov|avi/;
            const ext = allowedTypes.test(path.extname(file.originalname).toLowerCase());
            const mime = file.mimetype.startsWith('image/') || file.mimetype.startsWith('video/');
            cb(null, ext && mime);
        }
    });

    // ============================================
    // PLAYER API - Simple HTTP Polling
    // ============================================

    app.post('/api/player/heartbeat', (req, res) => {
        const { display_id, name, resolution, ip_address, current_media, cpu_temp, uptime } = req.body;

        if (!display_id) {
            return res.status(400).json({ error: 'display_id required' });
        }

        const now = Date.now();

        let display = db.prepare('SELECT * FROM displays WHERE id = ?').get(display_id);

        if (!display) {
            db.prepare(`
                INSERT INTO displays (id, name, group_id, status, ip_address, resolution, last_seen, scale, volume, cpu_temp, uptime)
                VALUES (?, ?, 'default', 'online', ?, ?, ?, 100, 100, ?, ?)
            `).run(display_id, name || `Display-${display_id.slice(0, 8)}`, ip_address, resolution, now, cpu_temp, uptime);

            display = db.prepare('SELECT * FROM displays WHERE id = ?').get(display_id);
            console.log(`New display registered: ${display_id}`);
        } else {
            db.prepare(`
                UPDATE displays
                SET status = 'online', last_seen = ?, ip_address = ?, resolution = ?, current_media_id = ?, cpu_temp = ?, uptime = ?
                WHERE id = ?
            `).run(now, ip_address || display.ip_address, resolution || display.resolution, current_media, cpu_temp, uptime, display_id);
        }

        const assignment = db.prepare('SELECT playlist_id FROM display_assignments WHERE display_id = ?').get(display_id);
        let playlist = null;

        const activeSchedule = getActiveScheduleForDisplay(display_id, display.group_id || 'default');

        if (activeSchedule) {
            playlist = getPlaylistWithMedia(activeSchedule.playlist_id);
            if (playlist) {
                console.log(`Schedule "${activeSchedule.name}" active for display ${display_id} -> playlist "${playlist.name}"`);
            }
        } else if (assignment && assignment.playlist_id) {
            playlist = getPlaylistWithMedia(assignment.playlist_id);
        } else {
            const groupAssignment = db.prepare('SELECT playlist_id FROM group_assignments WHERE group_id = ?').get(display.group_id);
            if (groupAssignment && groupAssignment.playlist_id) {
                playlist = getPlaylistWithMedia(groupAssignment.playlist_id);
            } else {
                const defaultPlaylist = db.prepare('SELECT * FROM playlists WHERE is_default = 1').get();
                if (defaultPlaylist) {
                    playlist = getPlaylistWithMedia(defaultPlaylist.id);
                }
            }
        }

        const commands = db.prepare('SELECT * FROM commands WHERE display_id = ? AND executed = 0 ORDER BY created_at').all(display_id);

        if (commands.length > 0) {
            db.prepare('UPDATE commands SET executed = 1 WHERE display_id = ? AND executed = 0').run(display_id);
        }

        res.json({
            success: true,
            playlist: playlist,
            scale: display.scale || 100,
            volume: display.volume || 100,
            commands: commands.map(c => ({ command: c.command, payload: c.payload ? JSON.parse(c.payload) : null }))
        });
    });

    // ============================================
    // ADMIN API - Display Management
    // ============================================

    app.get('/api/displays', (req, res) => {
        const displays = db.prepare(`
            SELECT d.*, g.name as group_name
            FROM displays d
            LEFT JOIN groups g ON d.group_id = g.id
            ORDER BY d.name
        `).all();

        const now = Date.now();
        displays.forEach(d => {
            d.status = (now - d.last_seen) < 15000 ? 'online' : 'offline';
        });

        res.json(displays);
    });

    app.get('/api/displays/:id', (req, res) => {
        const display = db.prepare('SELECT * FROM displays WHERE id = ?').get(req.params.id);
        if (!display) return res.status(404).json({ error: 'Display not found' });

        const now = Date.now();
        display.status = (now - display.last_seen) < 15000 ? 'online' : 'offline';
        res.json(display);
    });

    app.put('/api/displays/:id', (req, res) => {
        const { name, group_id, scale, volume } = req.body;

        const display = db.prepare('SELECT * FROM displays WHERE id = ?').get(req.params.id);
        if (!display) return res.status(404).json({ error: 'Display not found' });

        const updates = [];
        const values = [];

        if (name !== undefined) { updates.push('name = ?'); values.push(name); }
        if (group_id !== undefined) { updates.push('group_id = ?'); values.push(group_id); }
        if (scale !== undefined) { updates.push('scale = ?'); values.push(scale); }
        if (volume !== undefined) { updates.push('volume = ?'); values.push(volume); }

        if (updates.length > 0) {
            values.push(req.params.id);
            db.prepare(`UPDATE displays SET ${updates.join(', ')} WHERE id = ?`).run(...values);
        }

        res.json({ success: true });
    });

    app.delete('/api/displays/:id', (req, res) => {
        db.prepare('DELETE FROM displays WHERE id = ?').run(req.params.id);
        db.prepare('DELETE FROM display_assignments WHERE display_id = ?').run(req.params.id);
        db.prepare('DELETE FROM commands WHERE display_id = ?').run(req.params.id);
        res.json({ success: true });
    });

    app.post('/api/displays/:id/command', (req, res) => {
        const { command, payload } = req.body;
        const id = uuidv4();

        db.prepare('INSERT INTO commands (id, display_id, command, payload) VALUES (?, ?, ?, ?)')
            .run(id, req.params.id, command, payload ? JSON.stringify(payload) : null);

        res.json({ success: true });
    });

    app.post('/api/displays/:id/playlist', (req, res) => {
        const { playlist_id } = req.body;

        db.prepare(`
            INSERT INTO display_assignments (display_id, playlist_id, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(display_id) DO UPDATE SET playlist_id = ?, updated_at = ?
        `).run(req.params.id, playlist_id, Date.now(), playlist_id, Date.now());

        res.json({ success: true });
    });

    // Stop playback - remove playlist assignment and send stop command
    app.post('/api/displays/:id/stop', (req, res) => {
        const displayId = req.params.id;

        // Remove the display's playlist assignment
        db.prepare('DELETE FROM display_assignments WHERE display_id = ?').run(displayId);

        // Queue a stop command so the player clears its screen on next poll
        const id = uuidv4();
        db.prepare('INSERT INTO commands (id, display_id, command, payload) VALUES (?, ?, ?, ?)')
            .run(id, displayId, 'stop', null);

        res.json({ success: true });
    });

    // ============================================
    // ADMIN API - Groups
    // ============================================

    app.get('/api/groups', (req, res) => {
        const groups = db.prepare(`
            SELECT g.*, ga.playlist_id, p.name as playlist_name
            FROM groups g
            LEFT JOIN group_assignments ga ON g.id = ga.group_id
            LEFT JOIN playlists p ON ga.playlist_id = p.id
            ORDER BY g.name
        `).all();
        res.json(groups);
    });

    app.post('/api/groups', (req, res) => {
        const { name, description } = req.body;
        const id = uuidv4();
        db.prepare('INSERT INTO groups (id, name, description) VALUES (?, ?, ?)')
            .run(id, name, description || '');
        res.json({ id, name, description });
    });

    app.put('/api/groups/:id', (req, res) => {
        const { name, description } = req.body;
        db.prepare('UPDATE groups SET name = ?, description = ? WHERE id = ?')
            .run(name, description, req.params.id);
        res.json({ success: true });
    });

    app.delete('/api/groups/:id', (req, res) => {
        if (req.params.id === 'default') {
            return res.status(400).json({ error: 'Cannot delete default group' });
        }
        db.prepare('UPDATE displays SET group_id = ? WHERE group_id = ?').run('default', req.params.id);
        db.prepare('DELETE FROM groups WHERE id = ?').run(req.params.id);
        res.json({ success: true });
    });

    app.post('/api/groups/:id/playlist', (req, res) => {
        const { playlist_id } = req.body;
        const groupId = req.params.id;
        const now = Date.now();

        // Store the group-level assignment so new displays joining this group get it too
        const existing = db.prepare('SELECT id FROM group_assignments WHERE group_id = ?').get(groupId);
        if (existing) {
            db.prepare('UPDATE group_assignments SET playlist_id = ?, updated_at = ? WHERE group_id = ?')
                .run(playlist_id, now, groupId);
        } else {
            const id = uuidv4();
            db.prepare('INSERT INTO group_assignments (id, group_id, playlist_id, updated_at) VALUES (?, ?, ?, ?)')
                .run(id, groupId, playlist_id, now);
        }

        // Also assign to all current displays in the group
        const groupDisplays = db.prepare('SELECT id FROM displays WHERE group_id = ?').all(groupId);
        groupDisplays.forEach(d => {
            db.prepare(`
                INSERT INTO display_assignments (display_id, playlist_id, updated_at)
                VALUES (?, ?, ?)
                ON CONFLICT(display_id) DO UPDATE SET playlist_id = ?, updated_at = ?
            `).run(d.id, playlist_id, now, playlist_id, now);
        });

        res.json({ success: true, updated: groupDisplays.length });
    });

    // ============================================
    // ADMIN API - Schedules
    // ============================================

    app.get('/api/schedules', (req, res) => {
        const schedules = db.prepare(`
            SELECT s.*, p.name as playlist_name
            FROM schedules s
            LEFT JOIN playlists p ON s.playlist_id = p.id
            ORDER BY s.priority DESC, s.created_at DESC
        `).all();
        res.json(schedules);
    });

    app.post('/api/schedules', (req, res) => {
        const { name, playlist_id, target_type, target_id, start_time, end_time, days_of_week, priority } = req.body;
        const id = uuidv4();

        db.prepare(`
            INSERT INTO schedules (id, name, playlist_id, target_type, target_id, start_time, end_time, days_of_week, priority)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(id, name, playlist_id, target_type, target_id, start_time, end_time, JSON.stringify(days_of_week), priority || 0);

        res.json({ success: true, id });
    });

    app.put('/api/schedules/:id', (req, res) => {
        const { name, playlist_id, start_time, end_time, days_of_week, enabled, priority } = req.body;

        const updates = [];
        const values = [];

        if (name !== undefined) { updates.push('name = ?'); values.push(name); }
        if (playlist_id !== undefined) { updates.push('playlist_id = ?'); values.push(playlist_id); }
        if (start_time !== undefined) { updates.push('start_time = ?'); values.push(start_time); }
        if (end_time !== undefined) { updates.push('end_time = ?'); values.push(end_time); }
        if (days_of_week !== undefined) { updates.push('days_of_week = ?'); values.push(JSON.stringify(days_of_week)); }
        if (enabled !== undefined) { updates.push('enabled = ?'); values.push(enabled ? 1 : 0); }
        if (priority !== undefined) { updates.push('priority = ?'); values.push(priority); }

        if (updates.length > 0) {
            values.push(req.params.id);
            db.prepare(`UPDATE schedules SET ${updates.join(', ')} WHERE id = ?`).run(...values);
        }

        res.json({ success: true });
    });

    app.delete('/api/schedules/:id', (req, res) => {
        db.prepare('DELETE FROM schedules WHERE id = ?').run(req.params.id);
        res.json({ success: true });
    });

    // Debug endpoint: check what schedule is active for a display right now
    app.get('/api/schedules/check/:displayId', (req, res) => {
        const display = db.prepare('SELECT * FROM displays WHERE id = ?').get(req.params.displayId);
        if (!display) return res.status(404).json({ error: 'Display not found' });

        const now = new Date();
        const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        const dayOfWeek = now.getDay();
        const activeSchedule = getActiveScheduleForDisplay(display.id, display.group_id);

        const allSchedules = db.prepare('SELECT * FROM schedules WHERE enabled = 1').all();

        res.json({
            display_id: display.id,
            display_name: display.name,
            group_id: display.group_id,
            current_time: currentTime,
            day_of_week: dayOfWeek,
            active_schedule: activeSchedule,
            all_enabled_schedules: allSchedules
        });
    });

    // ============================================
    // ADMIN API - Display Preview
    // ============================================

    app.get('/api/displays/:id/preview', (req, res) => {
        const display = db.prepare('SELECT * FROM displays WHERE id = ?').get(req.params.id);
        if (!display) return res.status(404).json({ error: 'Display not found' });

        const assignment = db.prepare('SELECT playlist_id FROM display_assignments WHERE display_id = ?').get(req.params.id);
        let playlist = null;
        let currentMedia = null;

        if (assignment && assignment.playlist_id) {
            playlist = getPlaylistWithMedia(assignment.playlist_id);
            if (playlist && playlist.items && playlist.items.length > 0) {
                if (display.current_media_id) {
                    currentMedia = playlist.items.find(item => item.media_id === display.current_media_id);
                }
                if (!currentMedia) {
                    currentMedia = playlist.items[0];
                }
            }
        }

        res.json({
            display: display,
            playlist: playlist,
            currentMedia: currentMedia,
            status: (Date.now() - display.last_seen) < 15000 ? 'online' : 'offline'
        });
    });

    // ============================================
    // ADMIN API - Bulk Operations
    // ============================================

    app.post('/api/displays/bulk/volume', (req, res) => {
        const { display_ids, volume } = req.body;

        if (!Array.isArray(display_ids) || volume === undefined) {
            return res.status(400).json({ error: 'display_ids (array) and volume required' });
        }

        display_ids.forEach(id => {
            db.prepare('UPDATE displays SET volume = ? WHERE id = ?').run(volume, id);
        });

        res.json({ success: true, updated: display_ids.length });
    });

    app.post('/api/displays/bulk/command', (req, res) => {
        const { display_ids, command, payload } = req.body;

        if (!Array.isArray(display_ids) || !command) {
            return res.status(400).json({ error: 'display_ids (array) and command required' });
        }

        display_ids.forEach(display_id => {
            const id = uuidv4();
            db.prepare('INSERT INTO commands (id, display_id, command, payload) VALUES (?, ?, ?, ?)')
                .run(id, display_id, command, payload ? JSON.stringify(payload) : null);
        });

        res.json({ success: true, sent: display_ids.length });
    });

    app.post('/api/groups/:id/volume', (req, res) => {
        const { volume } = req.body;
        const displays = db.prepare('SELECT id FROM displays WHERE group_id = ?').all(req.params.id);

        displays.forEach(d => {
            db.prepare('UPDATE displays SET volume = ? WHERE id = ?').run(volume, d.id);
        });

        res.json({ success: true, updated: displays.length });
    });

    // ============================================
    // ADMIN API - Media
    // ============================================

    app.get('/api/media', (req, res) => {
        const media = db.prepare('SELECT * FROM media ORDER BY created_at DESC').all();
        res.json(media);
    });

    app.post('/api/media/upload', upload.array('files', 20), async (req, res) => {
        try {
            const uploaded = [];

            for (const file of req.files) {
                const id = uuidv4();
                let thumbnail = null;

                if (file.mimetype.startsWith('image/')) {
                    try {
                        const thumbFilename = `thumb_${id}.jpg`;
                        await sharp(file.path)
                            .resize(300, 200, { fit: 'cover' })
                            .jpeg({ quality: 80 })
                            .toFile(path.join(THUMB_DIR, thumbFilename));
                        thumbnail = thumbFilename;
                    } catch (e) {
                        console.error('Thumbnail generation failed:', e.message);
                    }
                }

                db.prepare(`
                    INSERT INTO media (id, filename, original_name, mime_type, size, thumbnail)
                    VALUES (?, ?, ?, ?, ?, ?)
                `).run(id, file.filename, file.originalname, file.mimetype, file.size, thumbnail);

                uploaded.push({ id, filename: file.filename, original_name: file.originalname });
            }

            res.json({ success: true, uploaded });
        } catch (err) {
            res.status(500).json({ error: err.message });
        }
    });

    app.delete('/api/media/:id', (req, res) => {
        const media = db.prepare('SELECT * FROM media WHERE id = ?').get(req.params.id);
        if (media) {
            const filePath = path.join(UPLOAD_DIR, media.filename);
            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

            if (media.thumbnail) {
                const thumbPath = path.join(THUMB_DIR, media.thumbnail);
                if (fs.existsSync(thumbPath)) fs.unlinkSync(thumbPath);
            }

            db.prepare('DELETE FROM media WHERE id = ?').run(req.params.id);
            db.prepare('DELETE FROM playlist_items WHERE media_id = ?').run(req.params.id);
        }
        res.json({ success: true });
    });

    // ============================================
    // ADMIN API - Playlists
    // ============================================

    app.get('/api/playlists', (req, res) => {
        const playlists = db.prepare('SELECT * FROM playlists ORDER BY name').all();
        res.json(playlists);
    });

    app.get('/api/playlists/:id', (req, res) => {
        const playlist = getPlaylistWithMedia(req.params.id);
        if (!playlist) return res.status(404).json({ error: 'Playlist not found' });
        res.json(playlist);
    });

    app.post('/api/playlists', (req, res) => {
        const { name, description } = req.body;
        const id = uuidv4();
        db.prepare('INSERT INTO playlists (id, name, description) VALUES (?, ?, ?)')
            .run(id, name, description || '');
        res.json({ id, name, description });
    });

    app.put('/api/playlists/:id', (req, res) => {
        const { name, description, is_default } = req.body;

        if (is_default) {
            db.prepare('UPDATE playlists SET is_default = 0').run();
        }

        db.prepare('UPDATE playlists SET name = ?, description = ?, is_default = ? WHERE id = ?')
            .run(name, description, is_default ? 1 : 0, req.params.id);
        res.json({ success: true });
    });

    app.delete('/api/playlists/:id', (req, res) => {
        db.prepare('DELETE FROM playlist_items WHERE playlist_id = ?').run(req.params.id);
        db.prepare('DELETE FROM playlists WHERE id = ?').run(req.params.id);
        res.json({ success: true });
    });

    app.post('/api/playlists/:id/items', (req, res) => {
        const { media_id, duration } = req.body;
        const id = uuidv4();

        const maxPos = db.prepare('SELECT MAX(position) as max FROM playlist_items WHERE playlist_id = ?')
            .get(req.params.id);
        const position = ((maxPos && maxPos.max) || 0) + 1;

        db.prepare('INSERT INTO playlist_items (id, playlist_id, media_id, position, duration) VALUES (?, ?, ?, ?, ?)')
            .run(id, req.params.id, media_id, position, duration || 10);

        res.json({ id, position });
    });

    app.delete('/api/playlists/:playlistId/items/:itemId', (req, res) => {
        db.prepare('DELETE FROM playlist_items WHERE id = ? AND playlist_id = ?')
            .run(req.params.itemId, req.params.playlistId);
        res.json({ success: true });
    });

    // ============================================
    // ADMIN API - Stats
    // ============================================

    app.get('/api/stats', (req, res) => {
        const totalDisplays = db.prepare('SELECT COUNT(*) as count FROM displays').get();
        const now = Date.now();
        const onlineDisplays = db.prepare('SELECT COUNT(*) as count FROM displays WHERE ? - last_seen < 15000').get(now);
        const totalMedia = db.prepare('SELECT COUNT(*) as count FROM media').get();
        const totalPlaylists = db.prepare('SELECT COUNT(*) as count FROM playlists').get();

        res.json({
            total_displays: totalDisplays ? totalDisplays.count : 0,
            online_displays: onlineDisplays ? onlineDisplays.count : 0,
            offline_displays: (totalDisplays ? totalDisplays.count : 0) - (onlineDisplays ? onlineDisplays.count : 0),
            total_media: totalMedia ? totalMedia.count : 0,
            total_playlists: totalPlaylists ? totalPlaylists.count : 0
        });
    });

    // ============================================
    // Helper Functions
    // ============================================

    function getPlaylistWithMedia(playlist_id) {
        const playlist = db.prepare('SELECT * FROM playlists WHERE id = ?').get(playlist_id);
        if (!playlist) return null;

        playlist.items = db.prepare(`
            SELECT pi.id, pi.duration, pi.position,
                   m.id as media_id, m.filename, m.mime_type, m.original_name
            FROM playlist_items pi
            JOIN media m ON pi.media_id = m.id
            WHERE pi.playlist_id = ?
            ORDER BY pi.position
        `).all(playlist_id);

        return playlist;
    }

    // Normalize time to HH:MM (strip seconds if present, e.g. "06:00:00" -> "06:00")
    function normalizeTime(t) {
        if (!t) return '00:00';
        return t.substring(0, 5);
    }

    function getActiveScheduleForDisplay(display_id, group_id) {
        const now = new Date();
        const currentTime = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
        const dayOfWeek = now.getDay();

        // Query schedules targeting this display directly
        let schedules = db.prepare(`
            SELECT * FROM schedules
            WHERE enabled = 1 AND target_type = 'display' AND target_id = ?
            ORDER BY priority DESC, created_at DESC
        `).all(display_id);

        // Also query schedules targeting the display's group (if it has one)
        if (group_id) {
            const groupSchedules = db.prepare(`
                SELECT * FROM schedules
                WHERE enabled = 1 AND target_type = 'group' AND target_id = ?
                ORDER BY priority DESC, created_at DESC
            `).all(group_id);
            schedules = schedules.concat(groupSchedules);
        }

        // Sort combined results by priority descending
        schedules.sort((a, b) => (b.priority || 0) - (a.priority || 0));

        for (const schedule of schedules) {
            let daysArray;
            try {
                daysArray = JSON.parse(schedule.days_of_week);
            } catch (e) {
                continue;
            }
            if (!Array.isArray(daysArray) || !daysArray.includes(dayOfWeek)) continue;

            const start = normalizeTime(schedule.start_time);
            const end = normalizeTime(schedule.end_time);

            // Handle schedules that cross midnight (e.g. 22:00 - 06:00)
            let inWindow;
            if (start <= end) {
                inWindow = currentTime >= start && currentTime <= end;
            } else {
                inWindow = currentTime >= start || currentTime <= end;
            }

            if (inWindow) {
                return schedule;
            }
        }

        return null;
    }

    // ============================================
    // Start Server
    // ============================================

    app.listen(PORT, '0.0.0.0', () => {
        console.log(`SignageHub Server
Admin Panel: http://localhost:${PORT}
Player API: http://localhost:${PORT}/api/player
`);

        try {
            const bonjour = new Bonjour();
            const hostname = os.hostname();

            bonjour.publish({
                name: `SignageHub-${hostname}`,
                type: 'signage-server',
                port: PORT,
                txt: {
                    version: '2.0',
                    api: '/api/player/heartbeat'
                }
            });

            console.log('Broadcasting via mDNS');
            console.log(`Service: SignageHub-${hostname}\n`);
        } catch (err) {
            console.warn('mDNS broadcasting failed:', err.message);
            console.warn('Players must manually configure server IP in config.json\n');
        }
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.error(`\nPort ${PORT} is already in use!`);
            process.exit(1);
        }
        throw err;
    });
}

main().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
});

module.exports = app;
