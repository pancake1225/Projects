#!/bin/bash

# SignageHub Display Setup Script
# This script helps configure a display Pi to connect to the server

echo "================================"
echo "SignageHub Display Setup"
echo "================================"
echo ""

# Check if config.json exists
CONFIG_FILE="player/config.json"

if [ ! -f "$CONFIG_FILE" ]; then
    echo "Error: player/config.json not found!"
    echo "Please run this script from the signage directory."
    exit 1
fi

# Get server IP from user
echo "Enter the Server Pi's IP address:"
echo "(Example: 192.168.1.100)"
read -p "Server IP: " SERVER_IP

if [ -z "$SERVER_IP" ]; then
    echo "Error: Server IP cannot be empty"
    exit 1
fi

# Optional: Set display name
read -p "Enter a name for this display (optional, press Enter to skip): " DISPLAY_NAME

# Generate a unique display ID if not exists
DISPLAY_ID=$(cat /dev/urandom | tr -dc 'a-z0-9' | fold -w 12 | head -n 1)

# Get current resolution (try to detect, default to 1920x1080)
RESOLUTION="1920x1080"
if command -v xrandr &> /dev/null; then
    DETECTED_RES=$(xrandr | grep '*' | awk '{print $1}' | head -n 1)
    if [ ! -z "$DETECTED_RES" ]; then
        RESOLUTION=$DETECTED_RES
        echo "Detected resolution: $RESOLUTION"
    fi
fi

# Create config.json
cat > "$CONFIG_FILE" << EOF
{
  "server": "http://${SERVER_IP}:3000",
  "player_port": 8080,
  "poll_interval": 5000,
  "display_id": "${DISPLAY_ID}",
  "display_name": "${DISPLAY_NAME:-Display-${DISPLAY_ID:0:8}}",
  "resolution": "${RESOLUTION}"
}
EOF

echo ""
echo "✓ Configuration saved!"
echo ""
echo "Config details:"
echo "  Server: http://${SERVER_IP}:3000"
echo "  Display ID: ${DISPLAY_ID}"
echo "  Display Name: ${DISPLAY_NAME:-Display-${DISPLAY_ID:0:8}}"
echo "  Resolution: ${RESOLUTION}"
echo ""

# Test connection to server
echo "Testing connection to server..."
if curl -s --connect-timeout 5 "http://${SERVER_IP}:3000" > /dev/null; then
    echo "✓ Server is reachable!"
else
    echo "✗ Warning: Cannot reach server at http://${SERVER_IP}:3000"
    echo "  Please check:"
    echo "  - Server is running (npm start)"
    echo "  - Both devices are on the same network"
    echo "  - Firewall is not blocking port 3000"
fi

echo ""
echo "================================"
echo "Setup Complete!"
echo "================================"
echo ""
echo "Next steps:"
echo "1. Start the player:"
echo "   npm run player"
echo ""
echo "2. Open browser to:"
echo "   http://localhost:8080"
echo ""
echo "3. The display should appear in the control panel at:"
echo "   http://${SERVER_IP}:3000"
echo ""
