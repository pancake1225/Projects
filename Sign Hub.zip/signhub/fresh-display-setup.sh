#!/bin/bash

# SignageHub - Fresh Display Setup
# Run this script on each NEW display Pi to ensure it gets a unique ID

echo "================================================"
echo "SignageHub - Fresh Display Setup"
echo "================================================"
echo ""

cd "$(dirname "$0")"

# Check if we're in the signage directory
if [ ! -d "player" ]; then
    echo "Error: Please run this from the signage directory"
    exit 1
fi

# Remove old config to force generation of new display ID
if [ -f "player/config.json" ]; then
    echo "⚠️  Found existing config.json"
    read -p "Delete it and create fresh config? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        rm player/config.json
        echo "✓ Removed old config"
    else
        echo "Keeping existing config. Display ID will NOT change."
        exit 0
    fi
fi

# Clear cache
if [ -d "player/cache" ]; then
    rm -rf player/cache/*
    echo "✓ Cleared cache"
fi

# Prompt for display name
echo ""
echo "Give this display a meaningful name (optional)"
echo "Examples: 'Lobby TV', 'Conference Room 1', 'Cafeteria Display'"
read -p "Display name (press Enter to skip): " DISPLAY_NAME

# Create fresh config
cat > player/config.json << EOF
{
  "server": "auto",
  "player_port": 8080,
  "poll_interval": 5000,
  "display_name": "${DISPLAY_NAME:-My Display}",
  "resolution": "1920x1080",
  "auto_discover": true
}
EOF

echo ""
echo "================================================"
echo "✓ Fresh configuration created!"
echo "================================================"
echo ""
echo "Display will get a unique ID based on this Pi's MAC address"
echo "when you start the player."
echo ""
echo "To start the player:"
echo "  npm run player"
echo ""
echo "The display will automatically:"
echo "  1. Generate a unique ID"
echo "  2. Find the server on WiFi"
echo "  3. Register itself in the control panel"
echo ""
