const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const os = require('os');
const express = require('express');
const { Bonjour } = require('bonjour-service');

const CONFIG_FILE = path.join(__dirname, 'config.json');
const CACHE_DIR = path.join(__dirname, 'cache');

let config = {
    server: process.env.SERVER_URL || 'auto', // 'auto' for auto-discovery
    player_port: process.env.PLAYER_PORT || 8080,
    poll_interval: 5000, // 5 seconds
    display_id: null,
    display_name: null,
    resolution: '1920x1080',
    auto_discover: true // Enable auto-discovery by default
};

// Load config
if (fs.existsSync(CONFIG_FILE)) {
    try {
        config = { ...config, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
        console.log('Config loaded');
    } catch (e) {
        console.error('Config load error:', e.message);
    }
}

// Generate display ID if needed
if (!config.display_id) {
    config.display_id = generateDisplayId();
    saveConfig();
}

// Ensure cache directory
if (!fs.existsSync(CACHE_DIR)) {
    fs.mkdirSync(CACHE_DIR, { recursive: true });
}

let currentPlaylist = null;
let currentIndex = 0;
let playTimer = null;
let isConnected = false;
let currentScale = 100;
let currentVolume = 100;
let isPlayingVideo = false;

function poll() {
    const data = JSON.stringify({
        display_id: config.display_id,
        name: config.display_name || `Display-${config.display_id.slice(0, 8)}`,
        resolution: config.resolution,
        ip_address: getIPAddress(),
        current_media: currentPlaylist?.items?.[currentIndex]?.media_id || null,
        cpu_temp: getCPUTemp(),
        uptime: getUptime()
    });
    
    const url = new URL(config.server + '/api/player/heartbeat');
    
    const options = {
        hostname: url.hostname,
        port: url.port || 3000,
        path: url.pathname,
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Content-Length': data.length
        },
        timeout: 10000
    };
    
    const proto = url.protocol === 'https:' ? https : http;
    
    const req = proto.request(options, (res) => {
        let body = '';
        res.on('data', chunk => body += chunk);
        res.on('end', () => {
            try {
                const response = JSON.parse(body);
                
                if (!isConnected) {
                    isConnected = true;
                    console.log('Connected to server');
                }
                
                // Handle scale change
                if (response.scale !== undefined && response.scale !== currentScale) {
                    currentScale = response.scale;
                    console.log(`Scale changed to ${currentScale}%`);
                    broadcastToDisplay({ type: 'scale', scale: currentScale });
                }
                
                // Handle volume change
                if (response.volume !== undefined && response.volume !== currentVolume) {
                    currentVolume = response.volume;
                    console.log(`Volume changed to ${currentVolume}%`);
                    broadcastToDisplay({ type: 'volume', volume: currentVolume });
                }
                
                // Handle playlist update
                if (response.playlist) {
                    const newPlaylistId = response.playlist.id;
                    const currentPlaylistId = currentPlaylist?.id;
                    
                    // Check if playlist changed
                    const playlistChanged = newPlaylistId !== currentPlaylistId;
                    const itemsChanged = JSON.stringify(response.playlist.items) !== JSON.stringify(currentPlaylist?.items);
                    
                    if (playlistChanged || itemsChanged) {
                        console.log('New playlist:', response.playlist.name);
                        setPlaylist(response.playlist);
                    }
                }
                
                // Handle commands
                if (response.commands && response.commands.length > 0) {
                    response.commands.forEach(cmd => {
                        console.log('Command:', cmd.command);
                        handleCommand(cmd.command, cmd.payload);
                    });
                }
                
            } catch (e) {
                console.error('Parse error:', e.message);
            }
        });
    });
    
    req.on('error', (e) => {
        if (isConnected) {
            isConnected = false;
            console.log('Connection lost:', e.message);
        }
    });
    
    req.on('timeout', () => {
        req.destroy();
        if (isConnected) {
            isConnected = false;
            console.log('Request timeout');
        }
    });
    
    req.write(data);
    req.end();
}

// Start polling loop
function startPolling() {
    console.log(`Polling server every ${config.poll_interval / 1000} seconds`);
    console.log(`   Server: ${config.server}\n`);
    
    // Initial poll
    poll();
    
    // Continue polling
    setInterval(poll, config.poll_interval);
}

function setPlaylist(playlist) {
    if (!playlist || !playlist.items || playlist.items.length === 0) {
        console.log('Empty playlist');
        currentPlaylist = null;
        stopPlayback();
        broadcastToDisplay({ type: 'stop' });
        return;
    }
    
    currentPlaylist = playlist;
    currentIndex = 0;
    startPlayback();
}

function startPlayback() {
    if (!currentPlaylist || currentPlaylist.items.length === 0) return;
    playCurrentItem();
}

function stopPlayback() {
    if (playTimer) {
        clearTimeout(playTimer);
        playTimer = null;
    }
}

function playCurrentItem() {
    if (!currentPlaylist) return;
    
    const item = currentPlaylist.items[currentIndex];
    if (!item) {
        currentIndex = 0;
        playCurrentItem();
        return;
    }
    
    const isVideo = item.mime_type?.startsWith('video/');
    
    console.log(`Playing ${currentIndex + 1}/${currentPlaylist.items.length}: ${item.original_name || item.filename} ${isVideo ? '(video)' : '(image)'}`);
    
    broadcastToDisplay({
        type: 'play',
        item: {
            filename: item.filename,
            mime_type: item.mime_type,
            url: `${config.server}/uploads/${item.filename}`,
            duration: item.duration
        },
        scale: currentScale,
        volume: currentVolume
    });
    
    if (isVideo) {
        // For videos, wait for the browser to report when it ends
        // The browser will send 'video-ended' event via SSE
        isPlayingVideo = true;
        console.log('   Waiting for video to finish...');
    } else {
        // For images, use the configured duration (default 5 seconds for images)
        isPlayingVideo = false;
        const duration = (item.duration || 5) * 1000;
        playTimer = setTimeout(() => {
            nextItem();
        }, duration);
    }
}

function nextItem() {
    currentIndex = (currentIndex + 1) % currentPlaylist.items.length;
    playCurrentItem();
}

function onVideoEnded() {
    if (isPlayingVideo && currentPlaylist) {
        console.log('   Video finished, moving to next item');
        isPlayingVideo = false;
        nextItem();
    }
}

function handleCommand(command, payload) {
    switch (command) {
        case 'refresh':
            poll();
            break;
        case 'reboot':
            console.log('Rebooting...');
            exec('sudo reboot');
            break;
        case 'clear-cache':
            clearCache();
            break;
        case 'stop':
            console.log('Stopping playback');
            currentPlaylist = null;
            currentIndex = 0;
            stopPlayback();
            broadcastToDisplay({ type: 'stop' });
            break;
        case 'volume':
            if (payload && payload.volume !== undefined) {
                currentVolume = payload.volume;
                console.log(`Volume set to ${currentVolume}%`);
                broadcastToDisplay({ type: 'volume', volume: currentVolume });
            }
            break;
        default:
            console.log('Unknown command:', command);
    }
}

function clearCache() {
    try {
        const files = fs.readdirSync(CACHE_DIR);
        files.forEach(f => fs.unlinkSync(path.join(CACHE_DIR, f)));
        console.log(`Cleared ${files.length} cached files`);
    } catch (e) {
        console.error('Clear cache error:', e.message);
    }
}

const app = express();
const server = http.createServer(app);
const clients = new Set();

// SSE endpoint for browser
app.get('/events', (req, res) => {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();
    
    clients.add(res);
    console.log('Display browser connected');
    
    // Send current state
    if (currentPlaylist && currentPlaylist.items[currentIndex]) {
        const item = currentPlaylist.items[currentIndex];
        res.write(`data: ${JSON.stringify({
            type: 'play',
            item: {
                filename: item.filename,
                mime_type: item.mime_type,
                url: `${config.server}/uploads/${item.filename}`,
                duration: item.duration
            },
            scale: currentScale,
            volume: currentVolume
        })}\n\n`);
    }
    
    // Send current scale
    res.write(`data: ${JSON.stringify({ type: 'scale', scale: currentScale })}\n\n`);
    
    req.on('close', () => {
        clients.delete(res);
        console.log('Display browser disconnected');
    });
});

// Endpoint for browser to report video ended
app.post('/video-ended', (req, res) => {
    onVideoEnded();
    res.json({ success: true });
});

function broadcastToDisplay(data) {
    const message = `data: ${JSON.stringify(data)}\n\n`;
    clients.forEach(client => {
        client.write(message);
    });
}

// Serve display page
app.get('/', (req, res) => {
    res.send(`<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Digital Signage Display</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html, body { 
            width: 100vw; 
            height: 100vh; 
            overflow: hidden;
            background: #000;
            font-family: system-ui, sans-serif;
        }
        #display {
            width: 100%;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        #display img, #display video {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 0.3s ease;
        }
        .standby {
            color: #333;
            font-size: 2rem;
            text-align: center;
        }
        .standby .id {
            font-size: 0.8rem;
            font-family: monospace;
            color: #222;
            margin-top: 1rem;
        }
        .status {
            position: fixed;
            top: 10px;
            right: 10px;
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: #f00;
        }
        .status.connected { background: #0f0; }
    </style>
</head>
<body>
    <div class="status" id="status"></div>
    <div id="display">
        <div class="standby">
            <div>Display ${config.display_id.slice(0, 8)}</div>
            <div class="id">Ready</div>
        </div>
    </div>
    
    <script>
        const display = document.getElementById('display');
        const status = document.getElementById('status');
        let currentScale = 100;
        let currentVolume = 100;
        
        function applyScale() {
            const media = display.querySelector('img, video');
            if (media) {
                media.style.transform = 'scale(' + (currentScale / 100) + ')';
            }
        }
        
        function applyVolume() {
            const video = display.querySelector('video');
            if (video) {
                video.volume = currentVolume / 100;
                console.log('Volume set to', currentVolume + '%');
            }
        }
        
        function connect() {
            const events = new EventSource('/events');
            
            events.onopen = () => {
                console.log('Connected');
                status.classList.add('connected');
            };
            
            events.onmessage = (e) => {
                try {
                    const data = JSON.parse(e.data);
                    
                    if (data.type === 'scale') {
                        currentScale = data.scale || 100;
                        applyScale();
                    }
                    
                    if (data.type === 'volume') {
                        currentVolume = data.volume || 100;
                        applyVolume();
                    }
                    
                    if (data.type === 'play' && data.item) {
                        const item = data.item;
                        const isVideo = item.mime_type?.startsWith('video/');
                        
                        if (data.scale) {
                            currentScale = data.scale;
                        }
                        
                        if (data.volume !== undefined) {
                            currentVolume = data.volume;
                        }
                        
                        if (isVideo) {
                            display.innerHTML = '<video autoplay playsinline><source src="' + item.url + '" type="' + item.mime_type + '"></video>';
                            const video = display.querySelector('video');
                            video.style.transform = 'scale(' + (currentScale / 100) + ')';
                            video.volume = currentVolume / 100;
                            
                            // When video ends, notify the server
                            video.onended = () => {
                                console.log('Video ended, notifying server');
                                fetch('/video-ended', { method: 'POST' });
                            };
                            
                            video.onerror = () => {
                                console.log('Video error, skipping');
                                fetch('/video-ended', { method: 'POST' });
                            };
                            
                            video.play().catch(e => {
                                console.log('Autoplay blocked, trying muted');
                                video.muted = true;
                                video.play();
                            });
                        } else {
                            display.innerHTML = '<img src="' + item.url + '">';
                            const img = display.querySelector('img');
                            img.style.transform = 'scale(' + (currentScale / 100) + ')';
                        }
                    } else if (data.type === 'stop') {
                        display.innerHTML = '<div class="standby"><div>Ready</div></div>';
                    }
                } catch (e) {
                    console.error('Parse error:', e);
                }
            };
            
            events.onerror = () => {
                status.classList.remove('connected');
                events.close();
                setTimeout(connect, 2000);
            };
        }
        
        connect();
        document.addEventListener('contextmenu', e => e.preventDefault());
    </script>
</body>
</html>`);
});

function generateDisplayId() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (!iface.internal && iface.mac !== '00:00:00:00:00:00') {
                return iface.mac.replace(/:/g, '').toLowerCase();
            }
        }
    }
    return 'pi-' + Math.random().toString(36).substring(2, 15);
}

function getIPAddress() {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
        for (const iface of interfaces[name]) {
            if (!iface.internal && iface.family === 'IPv4') {
                return iface.address;
            }
        }
    }
    return '127.0.0.1';
}

function getCPUTemp() {
    try {
        // Try to read from thermal zone (works on Raspberry Pi)
        if (fs.existsSync('/sys/class/thermal/thermal_zone0/temp')) {
            const temp = fs.readFileSync('/sys/class/thermal/thermal_zone0/temp', 'utf8');
            return parseFloat(temp) / 1000; // Convert from millidegrees to degrees
        }
    } catch (e) {
        // Silently fail
    }
    return null;
}

function getUptime() {
    try {
        // Get uptime in seconds
        return Math.floor(os.uptime());
    } catch (e) {
        return null;
    }
}

function saveConfig() {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

function discoverServer() {
    return new Promise((resolve, reject) => {
        console.log('Searching for server on network...');
        
        const bonjour = new Bonjour();
        const browser = bonjour.find({ type: 'signage-server' });
        
        let timeout = setTimeout(() => {
            browser.stop();
            reject(new Error('Server not found after 10 seconds'));
        }, 10000);
        
        browser.on('up', (service) => {
            clearTimeout(timeout);
            browser.stop();
            
            const serverUrl = `http://${service.addresses[0] || service.host}:${service.port}`;
            console.log(`Found server: ${serverUrl}`);
            
            // Update config
            config.server = serverUrl;
            saveConfig();
            
            resolve(serverUrl);
        });
    });
}

async function ensureServerConnection() {
    // If server is set to 'auto' or auto_discover is enabled, find server
    if (config.server === 'auto' || config.auto_discover) {
        try {
            await discoverServer();
        } catch (err) {
            console.error('Auto-discovery failed:', err.message);
            console.error('   Make sure the server is running and on the same network');
            console.error('   Or manually set server in player/config.json');
            process.exit(1);
        }
    }
}

async function startPlayer() {
    console.log(`SignageHub Player
Display ID: ${config.display_id}
Player Port: ${config.player_port}
`);

    // Auto-discover server if needed
    await ensureServerConnection();
    
    console.log(`   Server:       ${config.server.padEnd(34)}`);
    console.log();

    // Start local display server
    server.listen(config.player_port, '0.0.0.0', () => {
        console.log(`Display server: http://localhost:${config.player_port}`);
        
        // Start polling after server is ready
        startPolling();
        
    }).on('error', (err) => {
        if (err.code === 'EADDRINUSE') {
            console.error(`Port ${config.player_port} in use`);
            process.exit(1);
        }
        throw err;
    });
}

// Handle exit
process.on('SIGINT', () => {
    console.log('\nShutting down...');
    process.exit(0);
});

// Start the player
startPlayer().catch(err => {
    console.error('Failed to start player:', err);
    process.exit(1);
});
