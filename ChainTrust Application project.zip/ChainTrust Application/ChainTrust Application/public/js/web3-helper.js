// ============================================================
// ChainTrust - Global Web3 Helper
// ============================================================

const CT = (() => {
  const SGD_PER_ETH = 3000;

  // Order status labels and badge classes
  const STATUS_MAP = {
    0: { label: 'Created',   badge: 'badge-created' },
    1: { label: 'Paid',      badge: 'badge-paid' },
    2: { label: 'Shipped',   badge: 'badge-shipped' },
    3: { label: 'Delivered', badge: 'badge-delivered' },
    4: { label: 'Disputed',  badge: 'badge-disputed' },
    5: { label: 'Resolved',  badge: 'badge-resolved' },
    6: { label: 'Cancelled', badge: 'badge-cancelled' },
    7: { label: 'Refunded',  badge: 'badge-refunded' },
  };

  let _provider = null;
  let _signer = null;
  let _contract = null;
  let _abi = null;
  let _account = null;

  // ---- Helpers ----
  function shortAddr(addr) {
    if (!addr) return '-';
    return addr.slice(0, 6) + '...' + addr.slice(-4);
  }

  function weiToEth(wei) {
    return ethers.utils.formatEther(wei);
  }

  function ethToWei(eth) {
    return ethers.utils.parseEther(eth.toString());
  }

  function sgdToEth(sgd) {
    return sgd / SGD_PER_ETH;
  }

  function ethToSgd(eth) {
    return eth * SGD_PER_ETH;
  }

  function statusBadge(statusNum) {
    const s = STATUS_MAP[statusNum] || { label: 'Unknown', badge: '' };
    return `<span class="badge-status ${s.badge}">${s.label}</span>`;
  }

  function starsHtml(rating, max = 5) {
    let html = '';
    for (let i = 1; i <= max; i++) {
      html += i <= rating
        ? '<i class="bi bi-star-fill"></i>'
        : '<i class="bi bi-star empty"></i>';
    }
    return html;
  }

  function formatDate(timestamp) {
    if (!timestamp || timestamp == 0) return '-';
    const d = new Date(Number(timestamp) * 1000);
    return d.toLocaleDateString('en-SG', {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit'
    });
  }

  // ---- ABI Loading ----
  async function loadABI() {
    if (_abi) return _abi;
    const res = await fetch('/build/contracts/Marketplace.json');
    if (!res.ok) throw new Error('Cannot load Marketplace ABI from /build/contracts/Marketplace.json');
    const artifact = await res.json();
    _abi = artifact.abi;
    return _abi;
  }

  // ---- Wallet Connection ----
  async function connect(forcePicker = false) {
    if (!window.ethereum) throw new Error('MetaMask not detected. Please install MetaMask.');

    if (forcePicker) {
      await window.ethereum.request({
        method: 'wallet_requestPermissions',
        params: [{ eth_accounts: {} }]
      });
    }

    await window.ethereum.request({ method: 'eth_requestAccounts' });
    _provider = new ethers.providers.Web3Provider(window.ethereum);
    _signer = _provider.getSigner();
    _account = await _signer.getAddress();
    localStorage.setItem('mm_connected', '1');
    return _account;
  }

  function disconnect() {
    localStorage.removeItem('mm_connected');
    _provider = null;
    _signer = null;
    _contract = null;
    _account = null;
  }

  async function getAccount() {
    if (_account) return _account;
    if (!window.ethereum) return null;
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const accounts = await provider.listAccounts();
    _account = accounts[0] || null;
    return _account;
  }

  async function getWalletInfo() {
    if (!window.ethereum) return { connected: false };
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const accounts = await provider.listAccounts();
    if (!accounts.length) return { connected: false };
    const network = await provider.getNetwork();
    const balance = await provider.getBalance(accounts[0]);
    return {
      connected: true,
      account: accounts[0],
      balance: Number(ethers.utils.formatEther(balance)).toFixed(4),
      chainId: network.chainId
    };
  }

  // ---- Contract ----
  async function getContract(contractAddress) {
    if (!contractAddress) {
      contractAddress = localStorage.getItem('ct_contract_address');
    }
    if (!contractAddress) throw new Error('No contract address set. Please enter it in Settings.');
    localStorage.setItem('ct_contract_address', contractAddress);

    const abi = await loadABI();
    if (!_signer) {
      if (!window.ethereum) throw new Error('MetaMask not detected.');
      _provider = new ethers.providers.Web3Provider(window.ethereum);
      _signer = _provider.getSigner();
    }
    _contract = new ethers.Contract(contractAddress, abi, _signer);
    return _contract;
  }

  function getSavedContractAddress() {
    return localStorage.getItem('ct_contract_address') || '';
  }

  // ---- Navbar Wallet Status Update ----
  async function updateNavWallet() {
    const dot = document.getElementById('navWalletDot');
    const text = document.getElementById('navWalletText');
    if (!dot || !text) return;

    try {
      const info = await getWalletInfo();
      if (info.connected) {
        dot.classList.add('connected');
        text.textContent = shortAddr(info.account);
      } else {
        dot.classList.remove('connected');
        text.textContent = 'Connect Wallet';
      }
    } catch {
      dot.classList.remove('connected');
      text.textContent = 'Connect Wallet';
    }
  }

  // ---- Listen for account/chain changes ----
  if (typeof window !== 'undefined' && window.ethereum) {
    window.ethereum.on('accountsChanged', () => {
      _account = null;
      _signer = null;
      _contract = null;
      updateNavWallet();
    });
    window.ethereum.on('chainChanged', () => window.location.reload());
  }

  // Auto-update navbar on load
  if (typeof window !== 'undefined') {
    window.addEventListener('DOMContentLoaded', updateNavWallet);
  }

  return {
    SGD_PER_ETH,
    STATUS_MAP,
    shortAddr,
    weiToEth,
    ethToWei,
    sgdToEth,
    ethToSgd,
    statusBadge,
    starsHtml,
    formatDate,
    loadABI,
    connect,
    disconnect,
    getAccount,
    getWalletInfo,
    getContract,
    getSavedContractAddress,
    updateNavWallet,
  };
})();
