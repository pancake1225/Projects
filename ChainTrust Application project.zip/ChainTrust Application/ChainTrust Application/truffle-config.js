// Load environment variables (for Sepolia, optional)
require("dotenv").config();

// Required for resolving build output path
const path = require("path");

module.exports = {
  // ============================================================
  // Contract directories
  // ============================================================
  contracts_directory: "./contracts",

  // IMPORTANT:
  // Output contract ABI JSON here so the frontend (MetaMask/Web3)
  // can fetch it from /public/build/contracts/*.json
  contracts_build_directory: path.join(__dirname, "public/build/contracts"),

  // ============================================================
  // Network configuration
  // ============================================================
  networks: {
    // Ganache GUI (MetaMask custom network)
    development: {
      host: "127.0.0.1",
      port: 7545,
      network_id: "*",
      from: "0x2aed4397E676Af419D14fdC2F9f4Adf9bD8E2531",
    },

    // OPTIONAL: Ganache CLI / truffle develop
    ganache_cli: {
      host: "127.0.0.1",
      port: 8545,
      network_id: "*",
    },

    // OPTIONAL: Sepolia testnet (use later if needed)
    sepolia: {
      provider: () => {
        const HDWalletProvider = require("@truffle/hdwallet-provider");
        return new HDWalletProvider(
          process.env.PRIVATE_KEY,
          process.env.SEPOLIA_RPC_URL
        );
      },
      network_id: 11155111,
      confirmations: 2,
      timeoutBlocks: 200,
      skipDryRun: true,
    },
  },

  // ============================================================
  // Solidity compiler
  // ============================================================
  compilers: {
    solc: {
      version: "0.8.19",
      settings: {
        optimizer: {
          enabled: true,
          runs: 200,
        },
      },
    },
  },
};
