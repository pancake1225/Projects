const Marketplace = artifacts.require("Marketplace");

module.exports = async function (deployer, network) {
  // Deploy the Marketplace contract
  await deployer.deploy(Marketplace);
  const marketplace = await Marketplace.deployed();

  console.log("Marketplace deployed at:", marketplace.address);

  // Enable test mode for local networks
  if (network === "ganache" || network === "development") {
    await marketplace.enableTestMode();
    console.log("Test mode enabled");

    // Set shorter time periods for testing (5 minutes)
    const shortPeriod = 5 * 60;
    await marketplace.setAutoReleasePeriod(shortPeriod);
    await marketplace.setDisputeWindow(shortPeriod);
    console.log("Auto-release period: 5 minutes");
    console.log("Dispute window: 5 minutes");
  }
};
