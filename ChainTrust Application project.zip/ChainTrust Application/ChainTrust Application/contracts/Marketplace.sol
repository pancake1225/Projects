// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/*
I declare that this code was written by me.
I will not copy or allow others to copy my code.
I understand that copying code is considered as plagiarism.

Student Name: [Your Name]
Student ID: [Your ID]
Class: C373
Date created: 2026-01-12
*/

contract Marketplace {

    // ============================================================
    // CONSTANTS
    // ============================================================
    
    uint256 private constant _NOT_ENTERED = 1;
    uint256 private constant _ENTERED = 2;
    
    // Time constants (can be overridden in test mode)
    uint256 public constant PRODUCTION_AUTO_RELEASE_PERIOD = 7 days;
    uint256 public constant PRODUCTION_DISPUTE_WINDOW = 3 days;
    
    // ============================================================
    // STATE VARIABLES
    // ============================================================
    
    // Owner and reentrancy guard
    address private _owner;
    uint256 private _status;
    bool public paused;
    
    // Test mode variables (for Ganache testing)
    bool public testMode;
    uint256 public testTimestamp;
    uint256 public autoReleasePeriod;
    uint256 public disputeWindow;

    // Enums
    enum OrderStatus { Created, Paid, Shipped, Delivered, Disputed, Resolved, Cancelled, Refunded }
    enum UserRole { Buyer, Seller }

    // Structs
    struct Order {
        uint256 orderId;
        address payable buyer;
        address payable seller;
        uint256 amount;
        string productName;
        string trackingId;
        OrderStatus status;
        uint256 createdAt;
        uint256 shippedAt;
        uint256 deliveredAt;
        bool fundsReleased;
        bool disputed;
        string disputeReason;
    }

    struct ShippingUpdate {
        string location;
        string status;
        uint256 timestamp;
    }

    struct SellerReputation {
        uint256 totalSales;
        uint256 successfulDeliveries;
        uint256 totalRating;
        uint256 ratingCount;
        uint256 disputeCount;
        uint256 cancelledOrders;
        bool isActive;
    }

    struct Rating {
        address buyer;
        uint256 orderId;
        uint256 rating;
        string comment;
        uint256 timestamp;
    }

    // State variables
    uint256 public orderCounter;
    uint256 public platformFeePercent = 2; // 2% platform fee
    uint256 public accumulatedPlatformFees;

    mapping(uint256 => Order) public orders;
    mapping(uint256 => ShippingUpdate[]) public shippingUpdates;
    mapping(address => SellerReputation) public sellerReputations;
    mapping(address => uint256[]) public buyerOrders;
    mapping(address => uint256[]) public sellerOrders;
    mapping(uint256 => Rating) public orderRatings;
    mapping(address => bool) public registeredSellers;
    mapping(address => bool) public registeredBuyers;
    mapping(address => uint256) public userBalances;

    // ============================================================
    // EVENTS
    // ============================================================
    
    event OrderCreated(uint256 indexed orderId, address indexed buyer, address indexed seller, uint256 amount, string productName);
    event PaymentReceived(uint256 indexed orderId, address indexed buyer, uint256 amount);
    event OrderShipped(uint256 indexed orderId, string trackingId, uint256 shippedAt);
    event ShippingUpdated(uint256 indexed orderId, string location, string status);
    event OrderDelivered(uint256 indexed orderId, uint256 deliveredAt);
    event FundsReleased(uint256 indexed orderId, address indexed seller, uint256 amount, uint256 platformFee);
    event DisputeRaised(uint256 indexed orderId, address indexed buyer, string reason, uint256 timestamp);
    event DisputeResolved(uint256 indexed orderId, address winner, uint256 amount, bool refundedToBuyer);
    event OrderCancelled(uint256 indexed orderId, address indexed cancelledBy, string reason);
    event OrderAutoReleased(uint256 indexed orderId, uint256 releasedAt);
    event OrderRated(uint256 indexed orderId, address indexed buyer, uint256 rating, string comment);
    event SellerRegistered(address indexed seller);
    event BuyerRegistered(address indexed buyer);
    event BalanceDeposited(address indexed user, uint256 amount, uint256 newBalance);
    event BalanceWithdrawn(address indexed user, uint256 amount, uint256 newBalance);
    event PlatformFeeUpdated(uint256 oldFee, uint256 newFee);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event ContractPaused(address indexed by);
    event ContractUnpaused(address indexed by);
    event TestModeEnabled(address indexed by);
    event TestModeDisabled(address indexed by);
    event TestTimestampSet(uint256 newTimestamp);

    // ============================================================
    // CUSTOM ERRORS (Gas efficient)
    // ============================================================
    
    error NotOwner();
    error NotBuyer();
    error NotSeller();
    error OrderNotFound();
    error InsufficientBalance();
    error ContractIsPaused();
    error ReentrantCall();
    error InvalidAmount();
    error AlreadyRegistered();
    error NotRegistered();
    error InvalidOrderStatus();
    error FundsAlreadyReleased();
    error AlreadyDisputed();
    error DisputeWindowExpired();
    error DisputeWindowNotExpired();
    error AutoReleaseNotReady();
    error OrderAlreadyRated();
    error InvalidRating();
    error CannotBuyFromSelf();
    error ZeroAddress();
    error TestModeNotEnabled();

    // ============================================================
    // CONSTRUCTOR
    // ============================================================
    
    constructor() {
        _owner = msg.sender;
        _status = _NOT_ENTERED;
        paused = false;
        testMode = false;
        autoReleasePeriod = PRODUCTION_AUTO_RELEASE_PERIOD;
        disputeWindow = PRODUCTION_DISPUTE_WINDOW;
    }

    // ============================================================
    // MODIFIERS
    // ============================================================
    
    modifier nonReentrant() {
        if (_status == _ENTERED) revert ReentrantCall();
        _status = _ENTERED;
        _;
        _status = _NOT_ENTERED;
    }

    modifier onlyOwner() {
        if (msg.sender != _owner) revert NotOwner();
        _;
    }

    modifier whenNotPaused() {
        if (paused) revert ContractIsPaused();
        _;
    }

    modifier onlyBuyer(uint256 _orderId) {
        if (orders[_orderId].buyer != msg.sender) revert NotBuyer();
        _;
    }

    modifier onlySeller(uint256 _orderId) {
        if (orders[_orderId].seller != msg.sender) revert NotSeller();
        _;
    }

    modifier orderExists(uint256 _orderId) {
        if (_orderId == 0 || _orderId > orderCounter) revert OrderNotFound();
        _;
    }

    // ============================================================
    // HELPER FUNCTIONS
    // ============================================================
    
    /// @notice Returns the current timestamp (test mode aware)
    function getCurrentTimestamp() public view returns (uint256) {
        if (testMode && testTimestamp > 0) {
            return testTimestamp;
        }
        return block.timestamp;
    }

    // ============================================================
    // OWNER FUNCTIONS
    // ============================================================
    
    function owner() public view returns (address) {
        return _owner;
    }

    function transferOwnership(address newOwner) public onlyOwner {
        if (newOwner == address(0)) revert ZeroAddress();
        address oldOwner = _owner;
        _owner = newOwner;
        emit OwnershipTransferred(oldOwner, newOwner);
    }

    function renounceOwnership() public onlyOwner {
        address oldOwner = _owner;
        _owner = address(0);
        emit OwnershipTransferred(oldOwner, address(0));
    }

    function pause() external onlyOwner {
        paused = true;
        emit ContractPaused(msg.sender);
    }

    function unpause() external onlyOwner {
        paused = false;
        emit ContractUnpaused(msg.sender);
    }

    // ============================================================
    // TEST MODE FUNCTIONS (For Ganache Testing)
    // ============================================================
    
    /// @notice Enable test mode (allows time manipulation)
    function enableTestMode() external onlyOwner {
        testMode = true;
        testTimestamp = block.timestamp;
        emit TestModeEnabled(msg.sender);
    }

    /// @notice Disable test mode
    function disableTestMode() external onlyOwner {
        testMode = false;
        testTimestamp = 0;
        emit TestModeDisabled(msg.sender);
    }

    /// @notice Set custom timestamp for testing
    /// @param _timestamp The timestamp to set
    function setTestTimestamp(uint256 _timestamp) external onlyOwner {
        if (!testMode) revert TestModeNotEnabled();
        testTimestamp = _timestamp;
        emit TestTimestampSet(_timestamp);
    }

    /// @notice Advance time by specified seconds
    /// @param _seconds Number of seconds to advance
    function advanceTime(uint256 _seconds) external onlyOwner {
        if (!testMode) revert TestModeNotEnabled();
        if (testTimestamp == 0) {
            testTimestamp = block.timestamp;
        }
        testTimestamp += _seconds;
        emit TestTimestampSet(testTimestamp);
    }

    /// @notice Set custom auto-release period (for testing)
    /// @param _period New auto-release period in seconds
    function setAutoReleasePeriod(uint256 _period) external onlyOwner {
        autoReleasePeriod = _period;
    }

    /// @notice Set custom dispute window (for testing)
    /// @param _window New dispute window in seconds
    function setDisputeWindow(uint256 _window) external onlyOwner {
        disputeWindow = _window;
    }

    /// @notice Reset time settings to production values
    function resetTimeSettings() external onlyOwner {
        autoReleasePeriod = PRODUCTION_AUTO_RELEASE_PERIOD;
        disputeWindow = PRODUCTION_DISPUTE_WINDOW;
    }

    // ============================================================
    // REGISTRATION FUNCTIONS
    // ============================================================
    
    function registerAsSeller() external whenNotPaused {
        if (registeredSellers[msg.sender]) revert AlreadyRegistered();
        registeredSellers[msg.sender] = true;
        sellerReputations[msg.sender].isActive = true;
        emit SellerRegistered(msg.sender);
    }

    function registerAsBuyer() external whenNotPaused {
        if (registeredBuyers[msg.sender]) revert AlreadyRegistered();
        registeredBuyers[msg.sender] = true;
        emit BuyerRegistered(msg.sender);
    }

    /// @notice Register as both buyer and seller
    function registerAsBoth() external whenNotPaused {
        if (!registeredBuyers[msg.sender]) {
            registeredBuyers[msg.sender] = true;
            emit BuyerRegistered(msg.sender);
        }
        if (!registeredSellers[msg.sender]) {
            registeredSellers[msg.sender] = true;
            sellerReputations[msg.sender].isActive = true;
            emit SellerRegistered(msg.sender);
        }
    }

    // ============================================================
    // BALANCE MANAGEMENT
    // ============================================================
    
    // ============================================================
// BALANCE MANAGEMENT (Buyer-only registration)
// ============================================================

function depositBalance() external payable nonReentrant whenNotPaused {
    if (msg.value == 0) revert InvalidAmount();

    // ✅ Only require buyer registration (seller registration not needed)
    if (!registeredBuyers[msg.sender]) revert NotRegistered();

    userBalances[msg.sender] += msg.value;
    emit BalanceDeposited(msg.sender, msg.value, userBalances[msg.sender]);
}

function withdrawBalance(uint256 _amount) external nonReentrant whenNotPaused {
    if (_amount == 0) revert InvalidAmount();

    // ✅ Only buyers can withdraw their deposited balance
    if (!registeredBuyers[msg.sender]) revert NotRegistered();

    if (userBalances[msg.sender] < _amount) revert InsufficientBalance();

    userBalances[msg.sender] -= _amount;

    (bool success, ) = payable(msg.sender).call{value: _amount}("");
    require(success, "Withdrawal failed");

    emit BalanceWithdrawn(msg.sender, _amount, userBalances[msg.sender]);
}

function getBalance(address _user) external view returns (uint256) {
    return userBalances[_user];
}

    // ============================================================
    // ORDER CREATION
    // ============================================================
    
  function createOrder(
    address payable _seller,
    string memory _productName,
    uint256 _amount
) external nonReentrant whenNotPaused {
    if (_amount == 0) revert InvalidAmount();

    // ✅ Only buyer must be registered
    if (!registeredBuyers[msg.sender]) revert NotRegistered();

    // ✅ Seller does NOT need to be registered
    if (_seller == address(0)) revert ZeroAddress();
    if (_seller == msg.sender) revert CannotBuyFromSelf();

    if (userBalances[msg.sender] < _amount) revert InsufficientBalance();
    require(bytes(_productName).length > 0, "Product name required");
    require(bytes(_productName).length <= 256, "Product name too long");

    // Deduct buyer's deposited balance (escrow)
    userBalances[msg.sender] -= _amount;

    orderCounter++;

    orders[orderCounter] = Order({
        orderId: orderCounter,
        buyer: payable(msg.sender),
        seller: _seller,
        amount: _amount,
        productName: _productName,
        trackingId: "",
        status: OrderStatus.Paid,
        createdAt: getCurrentTimestamp(),
        shippedAt: 0,
        deliveredAt: 0,
        fundsReleased: false,
        disputed: false,
        disputeReason: ""
    });

    buyerOrders[msg.sender].push(orderCounter);
    sellerOrders[_seller].push(orderCounter);

    emit OrderCreated(orderCounter, msg.sender, _seller, _amount, _productName);
    emit PaymentReceived(orderCounter, msg.sender, _amount);
}


    // ============================================================
    // ORDER CANCELLATION
    // ============================================================
    
    /// @notice Buyer cancels order before shipping
    function buyerCancelOrder(uint256 _orderId) 
        external 
        orderExists(_orderId) 
        onlyBuyer(_orderId) 
        nonReentrant 
        whenNotPaused 
    {
        Order storage order = orders[_orderId];
        if (order.status != OrderStatus.Paid) revert InvalidOrderStatus();
        if (order.fundsReleased) revert FundsAlreadyReleased();

        order.status = OrderStatus.Cancelled;
        userBalances[order.buyer] += order.amount;

        emit OrderCancelled(_orderId, msg.sender, "Cancelled by buyer before shipping");
    }

    /// @notice Seller cancels order (can't fulfill)
    function sellerCancelOrder(uint256 _orderId, string memory _reason) 
        external 
        orderExists(_orderId) 
        onlySeller(_orderId) 
        nonReentrant 
        whenNotPaused 
    {
        Order storage order = orders[_orderId];
        if (order.status != OrderStatus.Paid) revert InvalidOrderStatus();
        if (order.fundsReleased) revert FundsAlreadyReleased();

        order.status = OrderStatus.Cancelled;
        userBalances[order.buyer] += order.amount;

        // Track seller cancellations
        sellerReputations[order.seller].cancelledOrders++;

        emit OrderCancelled(_orderId, msg.sender, _reason);
    }

    // ============================================================
    // SHIPPING FUNCTIONS
    // ============================================================
    
    function shipOrder(uint256 _orderId, string memory _trackingId)
        external
        orderExists(_orderId)
        onlySeller(_orderId)
        whenNotPaused
    {
        Order storage order = orders[_orderId];
        if (order.status != OrderStatus.Paid) revert InvalidOrderStatus();
        require(bytes(_trackingId).length > 0, "Tracking ID required");

        order.status = OrderStatus.Shipped;
        order.trackingId = _trackingId;
        order.shippedAt = getCurrentTimestamp();

        shippingUpdates[_orderId].push(ShippingUpdate({
            location: "Warehouse",
            status: "Shipped",
            timestamp: getCurrentTimestamp()
        }));

        emit OrderShipped(_orderId, _trackingId, order.shippedAt);
    }

    function updateShipping(
        uint256 _orderId,
        string memory _location,
        string memory _shippingStatus
    ) external orderExists(_orderId) onlySeller(_orderId) whenNotPaused {
        if (orders[_orderId].status != OrderStatus.Shipped) revert InvalidOrderStatus();

        shippingUpdates[_orderId].push(ShippingUpdate({
            location: _location,
            status: _shippingStatus,
            timestamp: getCurrentTimestamp()
        }));

        emit ShippingUpdated(_orderId, _location, _shippingStatus);
    }

    // ============================================================
    // DELIVERY & FUND RELEASE
    // ============================================================
    
    function confirmDelivery(uint256 _orderId)
        external
        orderExists(_orderId)
        onlyBuyer(_orderId)
        nonReentrant
        whenNotPaused
    {
        Order storage order = orders[_orderId];
        if (order.status != OrderStatus.Shipped) revert InvalidOrderStatus();
        if (order.fundsReleased) revert FundsAlreadyReleased();
        if (order.disputed) revert AlreadyDisputed();

        order.status = OrderStatus.Delivered;
        order.deliveredAt = getCurrentTimestamp();

        _releaseFunds(_orderId);

        emit OrderDelivered(_orderId, order.deliveredAt);
    }

    /// @notice Auto-release funds after timeout (can be called by anyone)
    function autoReleaseFunds(uint256 _orderId) 
        external 
        orderExists(_orderId) 
        nonReentrant 
        whenNotPaused 
    {
        Order storage order = orders[_orderId];
        if (order.status != OrderStatus.Shipped) revert InvalidOrderStatus();
        if (order.disputed) revert AlreadyDisputed();
        if (order.fundsReleased) revert FundsAlreadyReleased();
        
        uint256 currentTime = getCurrentTimestamp();
        if (currentTime < order.shippedAt + autoReleasePeriod) revert AutoReleaseNotReady();

        order.status = OrderStatus.Delivered;
        order.deliveredAt = currentTime;

        _releaseFunds(_orderId);

        emit OrderAutoReleased(_orderId, currentTime);
    }

    /// @notice Check if auto-release is available for an order
    function canAutoRelease(uint256 _orderId) external view orderExists(_orderId) returns (bool, uint256) {
        Order storage order = orders[_orderId];
        
        if (order.status != OrderStatus.Shipped || order.disputed || order.fundsReleased) {
            return (false, 0);
        }
        
        uint256 releaseTime = order.shippedAt + autoReleasePeriod;
        uint256 currentTime = getCurrentTimestamp();
        
        if (currentTime >= releaseTime) {
            return (true, 0);
        } else {
            return (false, releaseTime - currentTime);
        }
    }

    function _releaseFunds(uint256 _orderId) internal {
        Order storage order = orders[_orderId];

        uint256 platformFee = (order.amount * platformFeePercent) / 100;
        uint256 sellerAmount = order.amount - platformFee;

        order.fundsReleased = true;

        accumulatedPlatformFees += platformFee;

        SellerReputation storage reputation = sellerReputations[order.seller];
        reputation.totalSales++;
        reputation.successfulDeliveries++;

        userBalances[order.seller] += sellerAmount;

        emit FundsReleased(_orderId, order.seller, sellerAmount, platformFee);
    }

    // ============================================================
    // DISPUTE FUNCTIONS
    // ============================================================
    
    function raiseDispute(uint256 _orderId, string memory _reason)
        external
        orderExists(_orderId)
        onlyBuyer(_orderId)
        whenNotPaused
    {
        Order storage order = orders[_orderId];
        if (order.status != OrderStatus.Shipped) revert InvalidOrderStatus();
        if (order.fundsReleased) revert FundsAlreadyReleased();
        if (order.disputed) revert AlreadyDisputed();
        
        // Check dispute window
        uint256 currentTime = getCurrentTimestamp();
        if (currentTime > order.shippedAt + disputeWindow) revert DisputeWindowExpired();

        order.disputed = true;
        order.status = OrderStatus.Disputed;
        order.disputeReason = _reason;

        sellerReputations[order.seller].disputeCount++;

        emit DisputeRaised(_orderId, msg.sender, _reason, currentTime);
    }

    /// @notice Check if dispute window is still open
    function canDispute(uint256 _orderId) external view orderExists(_orderId) returns (bool, uint256) {
        Order storage order = orders[_orderId];
        
        if (order.status != OrderStatus.Shipped || order.disputed || order.fundsReleased) {
            return (false, 0);
        }
        
        uint256 disputeDeadline = order.shippedAt + disputeWindow;
        uint256 currentTime = getCurrentTimestamp();
        
        if (currentTime <= disputeDeadline) {
            return (true, disputeDeadline - currentTime);
        } else {
            return (false, 0);
        }
    }

    function resolveDispute(uint256 _orderId, bool _refundBuyer)
        external
        onlyOwner
        orderExists(_orderId)
        nonReentrant
    {
        Order storage order = orders[_orderId];
        if (!order.disputed) revert InvalidOrderStatus();
        if (order.fundsReleased) revert FundsAlreadyReleased();

        order.status = OrderStatus.Resolved;
        order.fundsReleased = true;

        if (_refundBuyer) {
            userBalances[order.buyer] += order.amount;
            emit DisputeResolved(_orderId, order.buyer, order.amount, true);
        } else {
            uint256 platformFee = (order.amount * platformFeePercent) / 100;
            uint256 sellerAmount = order.amount - platformFee;

            accumulatedPlatformFees += platformFee;
            sellerReputations[order.seller].successfulDeliveries++;

            userBalances[order.seller] += sellerAmount;
            emit DisputeResolved(_orderId, order.seller, sellerAmount, false);
        }
    }

    // ============================================================
    // RATING FUNCTIONS
    // ============================================================
    
    function rateOrder(uint256 _orderId, uint256 _rating, string memory _comment)
        external
        orderExists(_orderId)
        onlyBuyer(_orderId)
        whenNotPaused
    {
        Order storage order = orders[_orderId];
        
        // Can only rate delivered orders (not refunded disputes)
        if (order.status != OrderStatus.Delivered) revert InvalidOrderStatus();
        if (_rating < 1 || _rating > 5) revert InvalidRating();
        if (orderRatings[_orderId].buyer != address(0)) revert OrderAlreadyRated();

        orderRatings[_orderId] = Rating({
            buyer: msg.sender,
            orderId: _orderId,
            rating: _rating,
            comment: _comment,
            timestamp: getCurrentTimestamp()
        });

        SellerReputation storage reputation = sellerReputations[order.seller];
        reputation.totalRating += _rating;
        reputation.ratingCount++;

        emit OrderRated(_orderId, msg.sender, _rating, _comment);
    }

    // ============================================================
    // VIEW FUNCTIONS
    // ============================================================
    
    function getOrder(uint256 _orderId)
        external
        view
        orderExists(_orderId)
        returns (Order memory)
    {
        return orders[_orderId];
    }

    function getShippingUpdates(uint256 _orderId)
        external
        view
        orderExists(_orderId)
        returns (ShippingUpdate[] memory)
    {
        return shippingUpdates[_orderId];
    }

    function getSellerReputation(address _seller)
        external
        view
        returns (SellerReputation memory)
    {
        return sellerReputations[_seller];
    }

    function getSellerAverageRating(address _seller)
        external
        view
        returns (uint256)
    {
        SellerReputation memory reputation = sellerReputations[_seller];
        if (reputation.ratingCount == 0) return 0;
        return (reputation.totalRating * 100) / reputation.ratingCount;
    }

    function getBuyerOrders(address _buyer)
        external
        view
        returns (uint256[] memory)
    {
        return buyerOrders[_buyer];
    }

    function getSellerOrders(address _seller)
        external
        view
        returns (uint256[] memory)
    {
        return sellerOrders[_seller];
    }

    function getOrderRating(uint256 _orderId)
        external
        view
        orderExists(_orderId)
        returns (Rating memory)
    {
        return orderRatings[_orderId];
    }

    /// @notice Get multiple orders by IDs (batch query for frontend)
    function getOrdersBatch(uint256[] calldata _orderIds) 
        external 
        view 
        returns (Order[] memory) 
    {
        Order[] memory result = new Order[](_orderIds.length);
        for (uint256 i = 0; i < _orderIds.length; i++) {
            if (_orderIds[i] > 0 && _orderIds[i] <= orderCounter) {
                result[i] = orders[_orderIds[i]];
            }
        }
        return result;
    }

    /// @notice Get contract statistics
    function getContractStats() external view returns (
        uint256 totalOrders,
        uint256 totalPlatformFees,
        uint256 currentFeePercent,
        bool isPaused,
        bool isTestMode
    ) {
        return (
            orderCounter,
            accumulatedPlatformFees,
            platformFeePercent,
            paused,
            testMode
        );
    }

    // ============================================================
    // ADMIN FUNCTIONS
    // ============================================================
    
    function updatePlatformFee(uint256 _newFeePercent) external onlyOwner {
        require(_newFeePercent <= 10, "Fee cannot exceed 10%");
        uint256 oldFee = platformFeePercent;
        platformFeePercent = _newFeePercent;
        emit PlatformFeeUpdated(oldFee, _newFeePercent);
    }

    function withdrawPlatformFees() external onlyOwner nonReentrant {
        require(accumulatedPlatformFees > 0, "No fees to withdraw");

        uint256 amount = accumulatedPlatformFees;
        accumulatedPlatformFees = 0;

        (bool success, ) = owner().call{value: amount}("");
        require(success, "Withdrawal failed");
    }

    // ============================================================
    // FALLBACK FUNCTIONS
    // ============================================================
    
    receive() external payable {}
    fallback() external payable {}
}
