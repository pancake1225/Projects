const Marketplace = artifacts.require("Marketplace");
const { expect } = require("chai");
const BN = web3.utils.BN;

// Helper to assert a transaction reverts
async function expectRevert(promise) {
  try {
    await promise;
    assert.fail("Expected revert not received");
  } catch (error) {
    expect(error.message).to.include("revert");
  }
}

contract("Marketplace", (accounts) => {
  const [owner, seller1, buyer1, seller2, buyer2] = accounts;

  const ONE_ETH = web3.utils.toWei("1", "ether");
  const HALF_ETH = web3.utils.toWei("0.5", "ether");
  const FIVE_ETH = web3.utils.toWei("5", "ether");

  let marketplace;

  beforeEach(async () => {
    marketplace = await Marketplace.new({ from: owner });
    await marketplace.enableTestMode({ from: owner });
    await marketplace.setAutoReleasePeriod(60, { from: owner });
    await marketplace.setDisputeWindow(60, { from: owner });
  });

  describe("Deployment", () => {
    it("Should set the correct owner", async () => {
      const contractOwner = await marketplace.owner();
      expect(contractOwner).to.equal(owner);
    });

    it("Should initialize with correct default values", async () => {
      const paused = await marketplace.paused();
      const orderCounter = await marketplace.orderCounter();
      const fee = await marketplace.platformFeePercent();

      expect(paused).to.equal(false);
      expect(Number(orderCounter)).to.equal(0);
      expect(Number(fee)).to.equal(2);
    });

    it("Should have test mode enabled", async () => {
      const testMode = await marketplace.testMode();
      expect(testMode).to.equal(true);
    });
  });

  describe("Registration", () => {
    it("Should allow user to register as seller", async () => {
      const tx = await marketplace.registerAsSeller({ from: seller1 });

      expect(tx.logs[0].event).to.equal("SellerRegistered");
      expect(tx.logs[0].args.seller).to.equal(seller1);

      const isRegistered = await marketplace.registeredSellers(seller1);
      expect(isRegistered).to.equal(true);
    });

    it("Should allow user to register as buyer", async () => {
      const tx = await marketplace.registerAsBuyer({ from: buyer1 });

      expect(tx.logs[0].event).to.equal("BuyerRegistered");
      expect(tx.logs[0].args.buyer).to.equal(buyer1);

      const isRegistered = await marketplace.registeredBuyers(buyer1);
      expect(isRegistered).to.equal(true);
    });

    it("Should allow user to register as both", async () => {
      await marketplace.registerAsBoth({ from: seller2 });

      const isSeller = await marketplace.registeredSellers(seller2);
      const isBuyer = await marketplace.registeredBuyers(seller2);
      expect(isSeller).to.equal(true);
      expect(isBuyer).to.equal(true);
    });

    it("Should revert if already registered", async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await expectRevert(marketplace.registerAsSeller({ from: seller1 }));
    });
  });

  describe("Balance Management", () => {
    beforeEach(async () => {
      await marketplace.registerAsBuyer({ from: buyer1 });
    });

    it("Should allow registered user to deposit", async () => {
      const tx = await marketplace.depositBalance({ from: buyer1, value: ONE_ETH });

      expect(tx.logs[0].event).to.equal("BalanceDeposited");

      const balance = await marketplace.getBalance(buyer1);
      expect(balance.toString()).to.equal(ONE_ETH);
    });

    it("Should allow user to withdraw", async () => {
      await marketplace.depositBalance({ from: buyer1, value: ONE_ETH });

      const tx = await marketplace.withdrawBalance(HALF_ETH, { from: buyer1 });
      expect(tx.logs[0].event).to.equal("BalanceWithdrawn");

      const balance = await marketplace.getBalance(buyer1);
      expect(balance.toString()).to.equal(HALF_ETH);
    });

    it("Should revert withdrawal if insufficient balance", async () => {
      await marketplace.depositBalance({ from: buyer1, value: HALF_ETH });
      await expectRevert(marketplace.withdrawBalance(ONE_ETH, { from: buyer1 }));
    });

    it("Should revert deposit from unregistered user", async () => {
      await expectRevert(marketplace.depositBalance({ from: seller2, value: ONE_ETH }));
    });
  });

  describe("Order Creation", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
    });

    it("Should create order successfully", async () => {
      const tx = await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });

      expect(tx.logs[0].event).to.equal("OrderCreated");

      const order = await marketplace.getOrder(1);
      expect(order.buyer).to.equal(buyer1);
      expect(order.seller).to.equal(seller1);
      expect(order.amount.toString()).to.equal(ONE_ETH);
      expect(Number(order.status)).to.equal(1); // Paid
    });

    it("Should deduct amount from buyer balance", async () => {
      const balanceBefore = await marketplace.getBalance(buyer1);
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
      const balanceAfter = await marketplace.getBalance(buyer1);

      const diff = new BN(balanceBefore).sub(new BN(balanceAfter));
      expect(diff.toString()).to.equal(ONE_ETH);
    });

    it("Should revert if buyer has insufficient balance", async () => {
      await expectRevert(
        marketplace.createOrder(seller1, "Expensive Item", web3.utils.toWei("10", "ether"), { from: buyer1 })
      );
    });

    it("Should revert if buying from self", async () => {
      await marketplace.registerAsBuyer({ from: seller1 });
      await marketplace.depositBalance({ from: seller1, value: FIVE_ETH });
      await expectRevert(marketplace.createOrder(seller1, "Test", ONE_ETH, { from: seller1 }));
    });
  });

  describe("Order Shipping", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
    });

    it("Should allow seller to ship order", async () => {
      const tx = await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
      expect(tx.logs[0].event).to.equal("OrderShipped");

      const order = await marketplace.getOrder(1);
      expect(Number(order.status)).to.equal(2); // Shipped
      expect(order.trackingId).to.equal("TRACK-123");
    });

    it("Should allow seller to update shipping", async () => {
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });

      const tx = await marketplace.updateShipping(1, "Hub", "In Transit", { from: seller1 });
      expect(tx.logs[0].event).to.equal("ShippingUpdated");
    });

    it("Should revert if non-seller tries to ship", async () => {
      await expectRevert(marketplace.shipOrder(1, "TRACK-123", { from: buyer1 }));
    });
  });

  describe("Order Delivery & Fund Release", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
    });

    it("Should allow buyer to confirm delivery", async () => {
      const tx = await marketplace.confirmDelivery(1, { from: buyer1 });

      const eventNames = tx.logs.map((l) => l.event);
      expect(eventNames).to.include("OrderDelivered");
      expect(eventNames).to.include("FundsReleased");

      const order = await marketplace.getOrder(1);
      expect(Number(order.status)).to.equal(3); // Delivered
      expect(order.fundsReleased).to.equal(true);
    });

    it("Should release funds to seller minus platform fee", async () => {
      await marketplace.confirmDelivery(1, { from: buyer1 });

      const sellerBalance = await marketplace.getBalance(seller1);
      const oneEthBN = new BN(ONE_ETH);
      const fee = oneEthBN.mul(new BN(2)).div(new BN(100)); // 2% fee
      const expected = oneEthBN.sub(fee);

      expect(sellerBalance.toString()).to.equal(expected.toString());
    });

    it("Should update seller reputation", async () => {
      await marketplace.confirmDelivery(1, { from: buyer1 });

      const rep = await marketplace.getSellerReputation(seller1);
      expect(Number(rep.totalSales)).to.equal(1);
      expect(Number(rep.successfulDeliveries)).to.equal(1);
    });
  });

  describe("Order Cancellation", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
    });

    it("Should allow buyer to cancel before shipping", async () => {
      const balanceBefore = await marketplace.getBalance(buyer1);

      const tx = await marketplace.buyerCancelOrder(1, { from: buyer1 });
      expect(tx.logs[0].event).to.equal("OrderCancelled");

      const balanceAfter = await marketplace.getBalance(buyer1);
      const diff = new BN(balanceAfter).sub(new BN(balanceBefore));
      expect(diff.toString()).to.equal(ONE_ETH);

      const order = await marketplace.getOrder(1);
      expect(Number(order.status)).to.equal(6); // Cancelled
    });

    it("Should allow seller to cancel before shipping", async () => {
      const tx = await marketplace.sellerCancelOrder(1, "Out of stock", { from: seller1 });
      expect(tx.logs[0].event).to.equal("OrderCancelled");

      const rep = await marketplace.getSellerReputation(seller1);
      expect(Number(rep.cancelledOrders)).to.equal(1);
    });

    it("Should revert if trying to cancel after shipping", async () => {
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
      await expectRevert(marketplace.buyerCancelOrder(1, { from: buyer1 }));
    });
  });

  describe("Dispute System", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
    });

    it("Should allow buyer to raise dispute within window", async () => {
      const tx = await marketplace.raiseDispute(1, "Item damaged", { from: buyer1 });
      expect(tx.logs[0].event).to.equal("DisputeRaised");

      const order = await marketplace.getOrder(1);
      expect(Number(order.status)).to.equal(4); // Disputed
      expect(order.disputed).to.equal(true);
    });

    it("Should revert dispute after window expires", async () => {
      await marketplace.advanceTime(120, { from: owner });
      await expectRevert(marketplace.raiseDispute(1, "Item damaged", { from: buyer1 }));
    });

    it("Should allow owner to resolve dispute in buyer's favor", async () => {
      await marketplace.raiseDispute(1, "Item damaged", { from: buyer1 });

      const balanceBefore = await marketplace.getBalance(buyer1);

      const tx = await marketplace.resolveDispute(1, true, { from: owner });
      const eventNames = tx.logs.map((l) => l.event);
      expect(eventNames).to.include("DisputeResolved");

      const balanceAfter = await marketplace.getBalance(buyer1);
      const diff = new BN(balanceAfter).sub(new BN(balanceBefore));
      expect(diff.toString()).to.equal(ONE_ETH);
    });

    it("Should allow owner to resolve dispute in seller's favor", async () => {
      await marketplace.raiseDispute(1, "Item damaged", { from: buyer1 });

      const tx = await marketplace.resolveDispute(1, false, { from: owner });
      const eventNames = tx.logs.map((l) => l.event);
      expect(eventNames).to.include("DisputeResolved");

      const sellerBalance = await marketplace.getBalance(seller1);
      expect(new BN(sellerBalance).gt(new BN(0))).to.equal(true);
    });
  });

  describe("Auto-Release", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
    });

    it("Should not auto-release before timeout", async () => {
      const result = await marketplace.canAutoRelease(1);
      expect(result[0]).to.equal(false);
      await expectRevert(marketplace.autoReleaseFunds(1, { from: owner }));
    });

    it("Should auto-release after timeout", async () => {
      await marketplace.advanceTime(120, { from: owner });

      const result = await marketplace.canAutoRelease(1);
      expect(result[0]).to.equal(true);

      const tx = await marketplace.autoReleaseFunds(1, { from: owner });
      const eventNames = tx.logs.map((l) => l.event);
      expect(eventNames).to.include("OrderAutoReleased");

      const sellerBalance = await marketplace.getBalance(seller1);
      expect(new BN(sellerBalance).gt(new BN(0))).to.equal(true);
    });

    it("Should not auto-release if disputed", async () => {
      await marketplace.createOrder(seller1, "Another Product", ONE_ETH, { from: buyer1 });
      await marketplace.shipOrder(2, "TRACK-456", { from: seller1 });

      await marketplace.raiseDispute(2, "Problem", { from: buyer1 });
      await marketplace.advanceTime(120, { from: owner });

      await expectRevert(marketplace.autoReleaseFunds(2, { from: owner }));
    });
  });

  describe("Rating System", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test Product", ONE_ETH, { from: buyer1 });
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
      await marketplace.confirmDelivery(1, { from: buyer1 });
    });

    it("Should allow buyer to rate delivered order", async () => {
      const tx = await marketplace.rateOrder(1, 5, "Great!", { from: buyer1 });
      expect(tx.logs[0].event).to.equal("OrderRated");

      const rating = await marketplace.getOrderRating(1);
      expect(Number(rating.rating)).to.equal(5);
    });

    it("Should update seller average rating", async () => {
      await marketplace.rateOrder(1, 4, "Good", { from: buyer1 });

      const avgRating = await marketplace.getSellerAverageRating(seller1);
      expect(Number(avgRating)).to.equal(400); // 4.00 * 100
    });

    it("Should revert invalid rating", async () => {
      await expectRevert(marketplace.rateOrder(1, 0, "Bad", { from: buyer1 }));
      await expectRevert(marketplace.rateOrder(1, 6, "Too good", { from: buyer1 }));
    });

    it("Should revert double rating", async () => {
      await marketplace.rateOrder(1, 5, "Great!", { from: buyer1 });
      await expectRevert(marketplace.rateOrder(1, 4, "Changed mind", { from: buyer1 }));
    });
  });

  describe("Admin Functions", () => {
    it("Should allow owner to pause contract", async () => {
      await marketplace.pause({ from: owner });
      const paused = await marketplace.paused();
      expect(paused).to.equal(true);
    });

    it("Should revert operations when paused", async () => {
      await marketplace.pause({ from: owner });
      await expectRevert(marketplace.registerAsBuyer({ from: buyer1 }));
    });

    it("Should allow owner to update platform fee", async () => {
      const tx = await marketplace.updatePlatformFee(5, { from: owner });
      expect(tx.logs[0].event).to.equal("PlatformFeeUpdated");

      const fee = await marketplace.platformFeePercent();
      expect(Number(fee)).to.equal(5);
    });

    it("Should revert fee update over 10%", async () => {
      await expectRevert(marketplace.updatePlatformFee(15, { from: owner }));
    });

    it("Should allow owner to withdraw platform fees", async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Test", ONE_ETH, { from: buyer1 });
      await marketplace.shipOrder(1, "TRACK-123", { from: seller1 });
      await marketplace.confirmDelivery(1, { from: buyer1 });

      const feesBefore = await marketplace.accumulatedPlatformFees();
      expect(new BN(feesBefore).gt(new BN(0))).to.equal(true);

      await marketplace.withdrawPlatformFees({ from: owner });

      const feesAfter = await marketplace.accumulatedPlatformFees();
      expect(Number(feesAfter)).to.equal(0);
    });

    it("Should allow ownership transfer", async () => {
      const tx = await marketplace.transferOwnership(buyer1, { from: owner });
      expect(tx.logs[0].event).to.equal("OwnershipTransferred");

      const newOwner = await marketplace.owner();
      expect(newOwner).to.equal(buyer1);
    });
  });

  describe("Test Mode Functions", () => {
    it("Should allow time advancement in test mode", async () => {
      const timeBefore = await marketplace.getCurrentTimestamp();
      await marketplace.advanceTime(1000, { from: owner });
      const timeAfter = await marketplace.getCurrentTimestamp();

      const diff = new BN(timeAfter).sub(new BN(timeBefore));
      expect(diff.toNumber()).to.equal(1000);
    });

    it("Should revert time manipulation when test mode disabled", async () => {
      await marketplace.disableTestMode({ from: owner });
      await expectRevert(marketplace.advanceTime(1000, { from: owner }));
    });

    it("Should allow setting custom timestamp", async () => {
      const customTime = 1700000000;
      await marketplace.setTestTimestamp(customTime, { from: owner });

      const timestamp = await marketplace.getCurrentTimestamp();
      expect(Number(timestamp)).to.equal(customTime);
    });
  });

  describe("View Functions", () => {
    beforeEach(async () => {
      await marketplace.registerAsSeller({ from: seller1 });
      await marketplace.registerAsBuyer({ from: buyer1 });
      await marketplace.depositBalance({ from: buyer1, value: FIVE_ETH });
      await marketplace.createOrder(seller1, "Product 1", ONE_ETH, { from: buyer1 });
      await marketplace.createOrder(seller1, "Product 2", HALF_ETH, { from: buyer1 });
    });

    it("Should return buyer orders", async () => {
      const orders = await marketplace.getBuyerOrders(buyer1);
      expect(orders.length).to.equal(2);
      expect(Number(orders[0])).to.equal(1);
      expect(Number(orders[1])).to.equal(2);
    });

    it("Should return seller orders", async () => {
      const orders = await marketplace.getSellerOrders(seller1);
      expect(orders.length).to.equal(2);
    });

    it("Should return batch orders", async () => {
      const orders = await marketplace.getOrdersBatch([1, 2]);
      expect(orders.length).to.equal(2);
      expect(orders[0].productName).to.equal("Product 1");
      expect(orders[1].productName).to.equal("Product 2");
    });

    it("Should return contract stats", async () => {
      const stats = await marketplace.getContractStats();
      expect(Number(stats.totalOrders)).to.equal(2);
      expect(stats.isTestMode).to.equal(true);
    });
  });
});
