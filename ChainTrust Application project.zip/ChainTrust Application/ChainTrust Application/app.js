// app.js
const express = require("express");
const path = require("path");
const session = require("express-session");

const app = express();

// ---------------- Admin Configuration ----------------
// Set this to the wallet address that should have admin access.
// You can change this at any time and restart the server.
// Leave empty ("") to disable admin restriction (everyone can access /admin).
const ADMIN_ADDRESS = "0x2aed4397E676Af419D14fdC2F9f4Adf9bD8E2531"
// ---------------- View engine ----------------
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// ---------------- Middleware ----------------
app.use(express.static("public"));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use(
  session({
    secret: "chaintrust-secret",
    resave: false,
    saveUninitialized: true
  })
);

// Make common variables available to all views
app.use((req, res, next) => {
  res.locals.shopName = "ChainTrust Marketplace";
  res.locals.cartCount = (req.session.cart || []).reduce((sum, i) => sum + i.quantity, 0);
  res.locals.activePage = "";
  res.locals.wallet = req.session.wallet || null;
  res.locals.role = req.session.role || null;
  res.locals.isAdmin = req.session.isAdmin || false;
  next();
});

// ---------------- Auth Gate Middleware ----------------
// Routes that don't require wallet connection
const publicPaths = ["/connect", "/api/connect"];

app.use((req, res, next) => {
  // Allow static files and public paths
  if (publicPaths.includes(req.path)) return next();

  // Check if wallet is connected in session
  if (!req.session.wallet) {
    return res.redirect("/connect");
  }

  next();
});

// ---------------- Connect / Disconnect Routes ----------------

// Connect page (gate)
app.get("/connect", (req, res) => {
  // If already connected, redirect to home
  if (req.session.wallet) return res.redirect("/");
  res.render("connect");
});

// API: Save wallet + role to session
app.post("/api/connect", (req, res) => {
  const { walletAddress, role } = req.body;

  if (!walletAddress || !role) {
    return res.json({ success: false, message: "Wallet address and role are required." });
  }

  if (!["buyer", "seller"].includes(role)) {
    return res.json({ success: false, message: "Invalid role. Choose buyer or seller." });
  }

  req.session.wallet = walletAddress.toLowerCase();
  req.session.role = role;

  // Check admin
  const isAdmin = ADMIN_ADDRESS
    ? walletAddress.toLowerCase() === ADMIN_ADDRESS.toLowerCase()
    : false;
  req.session.isAdmin = isAdmin;

  // Update user profile address
  userProfile.address = walletAddress;

  res.json({ success: true, isAdmin });
});

// API: Disconnect (clear session)
app.post("/api/disconnect", (req, res) => {
  req.session.destroy(() => {
    res.redirect("/connect");
  });
});

// API: Switch role
app.post("/api/switch-role", (req, res) => {
  const { role } = req.body;
  if (role === "buyer" || role === "seller") {
    req.session.role = role;
  }
  res.redirect(req.get("Referer") || "/");
});

// ---------------- In-memory dummy data ----------------
let products = [];

let userProfile = {
  username: "bob.eth",
  email: "bob@example.com",
  address: "0x1234...abcd",
  bio: "Web3 builder",
  avatar: "avatar.png"
};

// ---------------- Data helpers ----------------
function getAllProducts() {
  return products;
}

function getProductById(id) {
  return products.find(p => p.id === id);
}

function createProduct(data, sellerAddress) {
  const id = products.length ? products[products.length - 1].id + 1 : 1;
  const product = {
    id,
    sku: data.sku,
    name: data.name,
    price: Number(data.price),
    stock: Number(data.stock),
    image: data.image || "placeholder.jpg",
    category: data.category,
    description: data.description,
    sellerAddress: sellerAddress || ""
  };
  products.push(product);
  return product;
}

// ---------------- Routes ----------------

// Home
app.get("/", (req, res) => {
  res.render("index", {
    products: getAllProducts(),
    activePage: "home",
    pageTitle: "Shop"
  });
});

// Product detail
app.get("/product/:id", (req, res) => {
  const product = getProductById(Number(req.params.id));
  if (!product) return res.status(404).send("Product not found");

  res.render("product", {
    product,
    pageTitle: product.name
  });
});

// Add product (seller)
app.get("/addProduct", (req, res) => {
  res.render("addProduct", {
    activePage: "addProduct",
    pageTitle: "Sell"
  });
});

app.post("/addProduct", (req, res) => {
  createProduct(req.body, req.session.wallet || "");
  res.redirect("/");
});

// Delete product (only the seller who listed it can delete)
app.post("/deleteProduct/:id", (req, res) => {
  const product = getProductById(Number(req.params.id));
  if (!product) return res.status(404).send("Product not found");

  const wallet = (req.session.wallet || "").toLowerCase();
  if (product.sellerAddress.toLowerCase() !== wallet) {
    return res.status(403).send("You can only delete your own listings.");
  }

  products = products.filter(p => p.id !== product.id);
  res.redirect("/");
});

// User profile
app.get("/user", (req, res) => {
  res.render("user", {
    user: userProfile,
    pageTitle: "Profile"
  });
});

app.post("/user", (req, res) => {
  const body = req.body || {};
  if (body.username) userProfile.username = body.username;
  if (body.email) userProfile.email = body.email;
  if (body.bio !== undefined) userProfile.bio = body.bio;
  res.redirect("/user");
});

// Orders (on-chain - loaded client-side)
app.get("/orders", (req, res) => {
  res.render("orders", {
    activePage: "orders",
    pageTitle: "Orders"
  });
});

// Order detail (on-chain - loaded client-side)
app.get("/order/:id", (req, res) => {
  res.render("order-detail", {
    orderId: Number(req.params.id),
    pageTitle: "Order #" + req.params.id
  });
});

// Admin dashboard - restricted to admin wallet
app.get("/admin", (req, res) => {
  // If ADMIN_ADDRESS is set, enforce it
  if (ADMIN_ADDRESS && !req.session.isAdmin) {
    return res.status(403).render("forbidden", {
      pageTitle: "Access Denied"
    });
  }

  res.render("admin", {
    activePage: "admin",
    pageTitle: "Admin"
  });
});

// ---------------- CART ----------------

// Add to cart
app.post("/addToCart", (req, res) => {
  const product = getProductById(Number(req.body.productId));
  if (!product) return res.redirect("/");

  if (!req.session.cart) {
    req.session.cart = [];
  }

  const cart = req.session.cart;
  const existing = cart.find(item => item.id === product.id);

  if (existing) {
    existing.quantity += 1;
  } else {
    cart.push({
      id: product.id,
      name: product.name,
      price: product.price,
      image: product.image,
      quantity: 1,
      sellerAddress: product.sellerAddress || ""
    });
  }

  res.redirect("/cart");
});

// View cart
app.get("/cart", (req, res) => {
  if (!req.session.cart) req.session.cart = [];

  res.render("cart", {
    cartItems: req.session.cart,
    pageTitle: "Cart"
  });
});

// Update quantity
app.post("/updateCart", (req, res) => {
  const { productId, quantity } = req.body;

  const item = (req.session.cart || []).find(
    p => p.id == productId
  );

  if (item && quantity > 0) {
    item.quantity = parseInt(quantity);
  }

  res.redirect("/cart");
});

// Remove item
app.post("/removeFromCart", (req, res) => {
  req.session.cart = (req.session.cart || []).filter(
    item => item.id != req.body.productId
  );

  res.redirect("/cart");
});

// Checkout
app.get("/checkout", (req, res) => {
  const cart = req.session.cart || [];
  if (cart.length === 0) return res.redirect("/cart");

  const total = cart.reduce(
    (sum, item) => sum + item.price * item.quantity,
    0
  );

  res.render("checkout", {
    cartItems: cart,
    total,
    pageTitle: "Checkout"
  });
});

// ---------------- Server ----------------
const PORT = process.env.PORT || 3001;
app.listen(PORT, () =>
  console.log(`ChainTrust Marketplace running on port ${PORT}`)
);
